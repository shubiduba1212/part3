package com.beanions.restapipractice.section01;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/response")
public class RestApiController {

  @GetMapping("/hello")
  public String hello() {
    return "Hello World";
  }

  @GetMapping("/message")
  public Message getMessage(){
    return new Message(200, "정상작동");
  }

  @GetMapping("/list")
  public List<String> getList(){
    return List.of(new String[] {"사과", "바나나", "포토"});
  }

  @GetMapping("/map")
  public Map<Integer, Message> getMap(){
    Map<Integer, Message> map = new HashMap<>();

    map.put(1, new Message(200, "정상작동"));
    map.put(2, new Message(404, "페이지를 찾을 수 없음"));
    map.put(3, new Message(500, "개발자 잘못"));

    return map;
  }

  @GetMapping(value = "/image", produces = MediaType.IMAGE_GIF_VALUE)
  public byte[] getImage() throws IOException {
    return getClass().getResourceAsStream("/images/chunsik06.gif").readAllBytes();
  }

  @GetMapping("/entity")
  public ResponseEntity<Message> getEntity(){
    return ResponseEntity.ok(new Message(123, "Hello World"));
  }

}
