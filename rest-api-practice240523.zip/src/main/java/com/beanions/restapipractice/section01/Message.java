package com.beanions.restapipractice.section01;

public class Message {
  private int httpResponseCode;
  private String message;

  public Message(){}

  public Message(int httpResponseCode, String message) {
    this.httpResponseCode = httpResponseCode;
    this.message = message;
  }

  public int getHttpResponseCode() {
    return httpResponseCode;
  }

  public void setHttpResponseCode(int httpResponseCode) {
    this.httpResponseCode = httpResponseCode;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  @Override
  public String toString() {
    return "Message{" +
            "httpResponseCode=" + httpResponseCode +
            ", message='" + message + '\'' +
            '}';
  }
}
