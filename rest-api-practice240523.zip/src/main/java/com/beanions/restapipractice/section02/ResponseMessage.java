package com.beanions.restapipractice.section02;

import java.util.Map;

public class ResponseMessage {
  private int httpResponseCode;
  private String message;
  private Map<String, Object> results;

  public ResponseMessage(){}

  public ResponseMessage(int httpResponseCode, String message, Map<String, Object> results) {
    this.httpResponseCode = httpResponseCode;
    this.message = message;
    this.results = results;
  }

  public int getHttpResponseCode() {
    return httpResponseCode;
  }

  public void setHttpResponseCode(int httpResponseCode) {
    this.httpResponseCode = httpResponseCode;
  }

  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public Map<String, Object> getResults() {
    return results;
  }

  public void setResults(Map<String, Object> results) {
    this.results = results;
  }

  @Override
  public String toString() {
    return "Message{" +
            "httpResponseCode=" + httpResponseCode +
            ", message='" + message + '\'' +
            ", results=" + results +
            '}';
  }
}
