package com.ohgiraffers.jwtsecurity.auth.filter;

import com.ohgiraffers.jwtsecurity.auth.model.DetailsUser;
import com.ohgiraffers.jwtsecurity.common.AuthConstants;
import com.ohgiraffers.jwtsecurity.common.UserRole;
import com.ohgiraffers.jwtsecurity.common.utils.TokenUtils;
import com.ohgiraffers.jwtsecurity.user.dto.LoginUserDTO;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.SignatureException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.json.simple.JSONObject;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class JwtAuthorizationFilter extends BasicAuthenticationFilter {
  //부모 클래스에 기본생성자가 없기에 생성자를 만들어줘야한다.
  public JwtAuthorizationFilter(AuthenticationManager authenticationManager){
    super(authenticationManager);
  }
  @Override
  protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
    List<String> roleLessList = Arrays.asList("/signup");

    if (roleLessList.contains((request.getRequestURI()))) {
      chain.doFilter(request, response);
    }

    // token이 유효한지 확인하기 위해 header 정보 가져오기
    String header = request.getHeader(AuthConstants.AUTH_HEADER); // 상수로 저장
    try {
      if (header != null && !header.equalsIgnoreCase("")) {
        String token = TokenUtils.splitHeader(header);

        if (TokenUtils.isValidToken(token)) { // 유효한 토큰인지 여부
          Claims claims = TokenUtils.getClaimsFromToken(token); // claims = 데이터의 작은 단위

          // 유저 정보
          DetailsUser authentication = new DetailsUser();
          LoginUserDTO user = new LoginUserDTO();
          user.setUserName(claims.get("userName").toString()); // get메소드 반환타입이 object이기에 toString()사용해서 string타입으로 바꿔줌
          user.setUserRole(UserRole.valueOf(claims.get("userRole").toString()));
          authentication.setUser(user);

          AbstractAuthenticationToken authenticationToken = UsernamePasswordAuthenticationToken.authenticated(authentication, token, authentication.getAuthorities());
          SecurityContextHolder.getContext().setAuthentication(authenticationToken); // 인증된 내용을
          chain.doFilter(request, response);

        } else {
          throw new RuntimeException("token이 유효하지 않습니다😖. - from TokenUtils.isValidToken(token)");
        }
      } else {
        throw new RuntimeException("token이 유효하지 않습니다😫. - from header != null && !header.equalsIgnoreCase(\"\")");
      }

      //super.doFilterInternal(request, response, chain);
    } catch (Exception e) {
      response.setContentType("application/jason");
      PrintWriter printWriter = response.getWriter();
      JSONObject jsonObject = jsonResponseWrapper(e);
      printWriter.print(jsonObject);
      printWriter.flush();
      printWriter.close();
    }
  }

  /* 토큰 관련 exception 발생 시 예외 내용을 담은 객체 반환하는 메소드 */
  private JSONObject jsonResponseWrapper(Exception e) {
    String resultMsg = "";

    if (e instanceof ExpiredJwtException) {
      resultMsg = "Token Expried😮";
    } else if (e instanceof SignatureException) {
      resultMsg = "Token SignatureException🤐";
    } else {
      resultMsg = "other Token Error😢";
    }

    HashMap<String, Object> jsonMap = new HashMap<>();
    jsonMap.put("status", 401);
    jsonMap.put("message", resultMsg);
    jsonMap.put("reason", e.getMessage());

    return new JSONObject(jsonMap);

  }
}
