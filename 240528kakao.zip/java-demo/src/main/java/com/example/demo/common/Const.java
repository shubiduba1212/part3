package com.example.demo.common;

public class Const {
	public static final String POST = "POST";
	public static final String GET = "GET";
	
	public static final String EMPTY = "";
}
