import 'package:chap04_flutter_api/const/colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(Sample());
}

class Sample extends StatelessWidget {
  const Sample({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Container(
        decoration: BoxDecoration(color: mainGreen),
        child: Center(
          child: Column(
            children: [
              Text(
                '샘플링 ABCDSOOPCHIVEabcd1234',
                style: TextStyle(
                    fontFamily: 'Monggle', fontSize: 50, color: white),
              ),
              Text(
                '샘플링 ABCDSOOPCHIVEabcd1234',
                style: TextStyle(
                    fontFamily: 'beomseok',
                    fontSize: 50,
                    fontWeight: FontWeight.w400,
                    color: white),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
