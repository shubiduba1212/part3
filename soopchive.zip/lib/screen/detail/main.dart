import 'package:chap04_flutter_api/screen/detail/detailMain.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(DetailMain());
}
