package com.beanions.common.uploadfiles;

import com.beanions.common.dto.FilesDTO;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UploadService {

  private final UploadMapper uploadMapper;

  public UploadService(UploadMapper uploadMapper) {this.uploadMapper = uploadMapper;}

  public List<FilesDTO> registerFileSelected() {return uploadMapper.registerFileSelected();}
}