package com.beanions.common.uploadfiles;

import com.beanions.common.dto.FilesDTO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface UploadMapper {

  List<FilesDTO> registerFileSelected();
}
