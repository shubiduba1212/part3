package com.beanions.common.dao.user;

public interface UserMapper {
}
