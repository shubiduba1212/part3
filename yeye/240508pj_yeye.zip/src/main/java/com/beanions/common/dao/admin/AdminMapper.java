package com.beanions.common.dao.admin;

public interface AdminMapper {
}
