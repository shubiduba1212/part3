package com.beanions.auth.controller;

import org.springframework.stereotype.Controller;

@Controller
public class authControllerTemp {
}
