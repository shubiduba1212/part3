package com.beanions.auth.model.service;

import org.springframework.stereotype.Service;

@Service
public class authServiceTemp {
}
