package com.beanions.user.controller;

import org.springframework.stereotype.Controller;

@Controller
public class userControllerTemp {

}
