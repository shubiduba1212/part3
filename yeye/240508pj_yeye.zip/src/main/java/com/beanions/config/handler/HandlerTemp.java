package com.beanions.config.handler;

public class HandlerTemp {
}
