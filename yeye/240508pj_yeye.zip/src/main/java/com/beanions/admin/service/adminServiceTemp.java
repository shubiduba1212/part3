package com.beanions.admin.service;

import org.springframework.stereotype.Service;

@Service
public class adminServiceTemp {
}
