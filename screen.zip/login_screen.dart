import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController _usernameController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login Screen'),
      ),
      body: Container(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextFormField(
              controller: _usernameController,
              decoration: InputDecoration(labelText: 'Username'),
            ),
            TextFormField(
              controller: _passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              child: Text('Login'),
              onPressed: () {
                String username = _usernameController.text;
                String password = _passwordController.text;

                if (username.isEmpty || password.isEmpty) {
                  // Show an error message or handle the validation error
                  return;
                }

                String validUsername = 'admin';
                String validPassword = 'password';

                if (username == validUsername && password == validPassword) {
                  // Successful login
                  // Navigate to the home screen or perform any other desired action
                } else {
                  // Invalid credentials
                  // Show an error message or handle the failed login attempt
                }

                _usernameController.clear();
                _passwordController.clear();

                // Implement your login logic here
              },
            ),
          ],
        ),
      ),
    );
  }
}