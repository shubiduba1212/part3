import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_practice/screen/home_screen.dart';
import 'package:flutter_practice/screen/login_screen.dart';

class SplashScreen extends StatefulWidget{
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>{
  @override
  void initState(){
    super.initState();
    _navigateToNextScreen();
  }
  
  void _navigateToNextScreen(){
    Future.delayed(Duration(seconds: 3), (){
      Navigator.pushReplacement(
          context, 
          MaterialPageRoute(builder: (context) => LoginScreen()),
      );
    });
  }
  
  @override
  Widget build(BuildContext context){
    return Scaffold(
      backgroundColor: Color(0xffFFF49C),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/home_s.png'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Text('JyeJye',)
        ],
      ),
    );
  }
}