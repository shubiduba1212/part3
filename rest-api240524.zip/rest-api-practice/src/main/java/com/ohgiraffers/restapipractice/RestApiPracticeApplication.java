package com.ohgiraffers.restapipractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiPracticeApplication {

  public static void main(String[] args) {
    SpringApplication.run(RestApiPracticeApplication.class, args);
  }

}
