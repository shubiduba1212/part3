package com.ohgiraffers.restapipractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiPracticeApplicationTests {

  @Test
  void contextLoads() {
  }

}
