import 'dart:async';
import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:chap04_flutter_api/widget/main_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:translator/translator.dart';

import '../../const/colors.dart';
import '../../widget/navigationbar.dart';
import '../detail/detailMain.dart';

class MainWidget extends StatefulWidget {
  const MainWidget({super.key});

  @override
  State<MainWidget> createState() => _HttpAppState();
}

class _HttpAppState extends State<MainWidget> {
  final Map<String, int> monthMap = {
    'January': 1,
    'February': 2,
    'March': 3,
    'April': 4,
    'May': 5,
    'June': 6,
    'July': 7,
    'August': 8,
    'September': 9,
    'October': 10,
    'November': 11,
    'December': 12,
  };
  final Map<String, String> species = {
    'Alligator': '악어',
    'Anteater': '개미핥기',
    'Bear': '곰',
    'Bear cub': '꼬마 곰',
    'Bird': '새',
    'Bull': '황소',
    'Cat': '고양이',
    'Cub': '꼬마 곰',
    'Chicken': '닭',
    'Cow': '소',
    'Deer': '사슴',
    'Dog': '개',
    'Duck': '오리',
    'Eagle': '독수리',
    'Elephant': '코끼리',
    'Frog': '개구리',
    'Goat': '염소',
    'Gorilla': '고릴라',
    'Hamster': '햄스터',
    'Hippo': '하마',
    'Horse': '말',
    'Koala': '코알라',
    'Kangaroo': '캥거루',
    'Lion': '사자',
    'Monkey': '원숭이',
    'Mouse': '쥐',
    'Octopus': '문어',
    'Ostrich': '타조',
    'Penguin': '펭귄',
    'Pig': '돼지',
    'Rabbit': '토끼',
    'Rhino': '코뿔소',
    'Rhinoceros': '코뿔소',
    'Sheep': '양',
    'Squirrel': '다람쥐',
    'Tiger': '호랑이',
    'Wolf': '늑대',
  };

  // ScrollController _scrollController = ScrollController();

  Future<String>? _futureData;
  List? edenData;
  List? transData;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    // _scrollController.addListener(_scrollListener);
    edenData = new List.empty(growable: true);
    transData = new List.empty(growable: true);
    _futureData = getJSONData();
  }

  Color hexToColorBack(String hex) {
    if (hex == "" || hex == "ffffff") {
      hex = "FBFCD5";
    }
    // 16진수 문자열을 정수로 변환하고, Color 객체를 생성합니다.
    return Color(int.parse(hex, radix: 16) + 0xFF000000);
  }

  Color hexToColorFont(String hex) {
    if (hex == "") {
      hex = "000000";
    }
    // 16진수 문자열을 정수로 변환하고, Color 객체를 생성합니다.
    return Color(int.parse(hex, radix: 16) + 0xFF000000);
  }

  int currentPage = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: MainAppBar(),
        bottomNavigationBar: bottomNavigator(context, currentPage),
        body: FutureBuilder<String>(
          future: _futureData,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              // 데이터가 로드 중일 때 표시할 로딩 스피너
              return Center(child: loading(context));
            } else if (snapshot.hasError) {
              // 에러가 발생했을 때 표시할 위젯
              return Center(child: Text('Error: ${snapshot.error}'));
            } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
              // 데이터가 없을 때 표시할 위젯
              return Center(child: Text('No data available'));
            } else {
              return Container(
                color: Color(0xFFFBFCD5),
                child: Stack(children: [
                  Column(children: [
                    Container(
                      height: 140,
                      padding: EdgeInsets.only(top: 40),
                      child: Stack(
                        alignment: Alignment.topCenter,
                        children: [
                          Image.asset('assets/images/blue_ribbon6 1.png'),
                          Container(
                            alignment: Alignment.center,
                            padding: EdgeInsets.only(top: 4),
                            height: 42,
                            width: 186,
                            child: Text(
                              "Today's Birth",
                              style: TextStyle(
                                  fontSize: 24,
                                  fontFamily: 'Monggle',
                                  // fontWeight: FontWeight.bold,
                                  color: Colors.white),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      height: 530,
                      child: Center(
                        child: transData!.isEmpty
                            ? Column(children: [
                                // Image.asset('assets/images/침착맨탕후루 1.png'),
                                Text(
                                  '생일인 친구가 없어요',
                                  style: TextStyle(fontSize: 20),
                                  textAlign: TextAlign.center,
                                ),
                              ])
                            : ListView.builder(
                                physics: BouncingScrollPhysics(),
                                scrollDirection: Axis.horizontal,
                                // controller: _scrollController,
                                itemBuilder: (context, index) {
                                  return Card(
                                    margin: const EdgeInsets.only(left: 45),
                                    color: Colors.transparent,
                                    elevation: 0,
                                    child: GestureDetector(
                                      onTap: () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) => DetailMain(
                                                selectedName: edenData![index]
                                                    ['name']),
                                          ),
                                        );
                                      },
                                      child: Stack(
                                        children: [
                                          Image.asset(
                                              'assets/images/생일캐릭1 프레임.png'),
                                          Container(
                                            alignment: Alignment.center,
                                            height: 480,
                                            width: 320,
                                            margin:
                                                const EdgeInsets.only(top: 22),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Container(
                                                  decoration: BoxDecoration(
                                                    color: hexToColorBack(
                                                        transData![index]
                                                            ['title_color']),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            16),
                                                  ),
                                                  width: 150,
                                                  height: 24,
                                                  alignment: Alignment.center,
                                                  margin: const EdgeInsets.only(
                                                      bottom: 17),
                                                  child: Text(
                                                    transData![index]['name'],
                                                    style: TextStyle(
                                                      color: hexToColorFont(
                                                          transData![index]
                                                              ['text_color']),
                                                      fontFamily: 'beomseok',
                                                    ),
                                                  ),
                                                ),
                                                Container(
                                                  margin: const EdgeInsets.only(
                                                      bottom: 12),
                                                  child: CachedNetworkImage(
                                                    imageUrl: transData![index]
                                                        ['image_url']!,
                                                    height: 160,
                                                    width: 90,
                                                    fit: BoxFit.contain,
                                                    placeholder: (context,
                                                            url) =>
                                                        Center(
                                                            child:
                                                                CircularProgressIndicator(
                                                      color: yellow,
                                                      backgroundColor:
                                                          mainGreen,
                                                      strokeWidth: 2,
                                                    )),
                                                    errorWidget:
                                                        (context, url, error) =>
                                                            Icon(Icons.error),
                                                  ),
                                                ),
                                                Container(
                                                  margin: const EdgeInsets.only(
                                                      bottom: 4),
                                                  child: Row(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    children: [
                                                      Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        children: [
                                                          Container(
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          16),
                                                              color: hexToColorBack(
                                                                  transData![
                                                                          index]
                                                                      [
                                                                      'title_color']),
                                                            ),
                                                            width: 80,
                                                            height: 24,
                                                            alignment: Alignment
                                                                .center,
                                                            margin:
                                                                const EdgeInsets
                                                                    .only(
                                                                    bottom: 4),
                                                            child: Text(
                                                              '종족',
                                                              style: TextStyle(
                                                                fontFamily:
                                                                    'beomseok',
                                                                fontSize: 18,
                                                                color: hexToColorFont(
                                                                    transData![
                                                                            index]
                                                                        [
                                                                        'text_color']),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          16),
                                                              color: hexToColorBack(
                                                                  transData![
                                                                          index]
                                                                      [
                                                                      'title_color']),
                                                            ),
                                                            width: 80,
                                                            height: 24,
                                                            alignment: Alignment
                                                                .center,
                                                            margin:
                                                                const EdgeInsets
                                                                    .only(
                                                                    bottom: 4),
                                                            child: Text(
                                                              '성별',
                                                              style: TextStyle(
                                                                fontFamily:
                                                                    'beomseok',
                                                                fontSize: 18,
                                                                color: hexToColorFont(
                                                                    transData![
                                                                            index]
                                                                        [
                                                                        'text_color']),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          16),
                                                              color: hexToColorBack(
                                                                  transData![
                                                                          index]
                                                                      [
                                                                      'title_color']),
                                                            ),
                                                            width: 80,
                                                            height: 24,
                                                            alignment: Alignment
                                                                .center,
                                                            margin:
                                                                const EdgeInsets
                                                                    .only(
                                                                    bottom: 4),
                                                            child: Text(
                                                              '생일',
                                                              style: TextStyle(
                                                                fontFamily:
                                                                    'beomseok',
                                                                fontSize: 18,
                                                                color: hexToColorFont(
                                                                    transData![
                                                                            index]
                                                                        [
                                                                        'text_color']),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                      SizedBox(
                                                        width: 10,
                                                      ),
                                                      Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .center,
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        children: [
                                                          Container(
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          16),
                                                              color: hexToColorBack(
                                                                  transData![
                                                                          index]
                                                                      [
                                                                      'title_color']),
                                                            ),
                                                            width: 130,
                                                            height: 24,
                                                            alignment: Alignment
                                                                .center,
                                                            margin:
                                                                const EdgeInsets
                                                                    .only(
                                                                    bottom: 4),
                                                            child: Text(
                                                              species[transData![
                                                                          index]
                                                                      [
                                                                      'species']] ??
                                                                  transData![
                                                                          index]
                                                                      [
                                                                      'species'],
                                                              style: TextStyle(
                                                                fontFamily:
                                                                    'beomseok',
                                                                fontSize: 16,
                                                                color: hexToColorFont(
                                                                    transData![
                                                                            index]
                                                                        [
                                                                        'text_color']),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                              decoration:
                                                                  BoxDecoration(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            16),
                                                                color: hexToColorBack(
                                                                    transData![
                                                                            index]
                                                                        [
                                                                        'title_color']),
                                                              ),
                                                              width: 130,
                                                              height: 24,
                                                              alignment:
                                                                  Alignment
                                                                      .center,
                                                              margin:
                                                                  const EdgeInsets
                                                                      .only(
                                                                      bottom:
                                                                          4),
                                                              child:
                                                                  ColorFiltered(
                                                                colorFilter: ColorFilter.mode(
                                                                    hexToColorFont(
                                                                        transData![index]
                                                                            [
                                                                            'text_color']),
                                                                    BlendMode
                                                                        .srcIn),
                                                                child: transData![index]
                                                                            [
                                                                            'gender'] ==
                                                                        'Male'
                                                                    ? Image.asset(
                                                                        'assets/images/Male.png')
                                                                    : Image.asset(
                                                                        'assets/images/Female.png'),
                                                              )),
                                                          Container(
                                                            decoration:
                                                                BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius
                                                                      .circular(
                                                                          16),
                                                              color: hexToColorBack(
                                                                  transData![
                                                                          index]
                                                                      [
                                                                      'title_color']),
                                                            ),
                                                            width: 130,
                                                            height: 24,
                                                            alignment: Alignment
                                                                .center,
                                                            margin:
                                                                const EdgeInsets
                                                                    .only(
                                                                    bottom: 4),
                                                            child: Text(
                                                              "${monthMap[transData![index]['birthday_month']] ?? ''}월 " +
                                                                  transData![
                                                                          index]
                                                                      [
                                                                      'birthday_day'] +
                                                                  '일',
                                                              style: TextStyle(
                                                                fontFamily:
                                                                    'beomseok',
                                                                fontSize: 15,
                                                                color: hexToColorFont(
                                                                    transData![
                                                                            index]
                                                                        [
                                                                        'text_color']),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            16),
                                                    color: hexToColorBack(
                                                        transData![index]
                                                            ['title_color']),
                                                  ),
                                                  width: 220,
                                                  height: 60,
                                                  alignment: Alignment.center,
                                                  child: Column(
                                                    children: [
                                                      Container(
                                                        margin: const EdgeInsets
                                                            .only(top: 2),
                                                        child: Text(
                                                          '좋아하는 말',
                                                          style: TextStyle(
                                                            fontFamily:
                                                                'beomseok',
                                                            fontSize: 16,
                                                            color: hexToColorFont(
                                                                transData![
                                                                        index][
                                                                    'text_color']),
                                                          ),
                                                        ),
                                                      ),
                                                      Expanded(
                                                        child:
                                                            SingleChildScrollView(
                                                          padding:
                                                              const EdgeInsets
                                                                  .only(
                                                                  left: 20,
                                                                  right: 10),
                                                          child: Text(
                                                            transData![index][
                                                                        'quote'] ==
                                                                    ""
                                                                ? '-'
                                                                : transData![
                                                                        index]
                                                                    ['quote'],
                                                            style: TextStyle(
                                                              fontFamily:
                                                                  'beomseok',
                                                              color:
                                                                  hexToColorFont(
                                                                transData![
                                                                        index][
                                                                    'text_color'],
                                                              ),
                                                              fontSize: 12,
                                                            ),
                                                            softWrap: true,
                                                            overflow:
                                                                TextOverflow
                                                                    .clip,
                                                          ),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                )
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                                itemCount: transData!.length,
                                padding: const EdgeInsets.only(right: 45),
                              ),
                      ),
                    )
                  ]),
                  Container(
                    child: Image.asset("assets/images/폭죽.png"),
                    height: 180,
                    width: 400,
                    alignment: Alignment.topRight,
                    margin: const EdgeInsets.only(top: 20),
                  ),
                ]),
              );
            }
          },
        ));
  }

  Future<String> getJSONData() async {
    var url = 'https://api.nookipedia.com/villagers';
    var response = await http.get(Uri.parse(url), headers: {
      "x-api-key": "1e12770e-930f-4f94-8bf2-7dd37587e30b",
      "Accept-Version": "1.0.0",
    });

    var dataConvertedToJSON = json.decode(response.body);
    List result = dataConvertedToJSON;

    int currentMonth = DateTime.now().month;
    int currentDay = DateTime.now().day;
    final translator = GoogleTranslator();

    // for (var villager in result) {
    //   if (monthMap[villager['birthday_month']] == currentMonth) {
    //     if (int.parse(villager['birthday_day']) == currentDay) {
    //       setState(() {
    //         print(edenData);
    //       });
    //     }
    //   }
    // }

    for (var villager in result) {
      if (monthMap[villager['birthday_month']] == currentMonth) {
        if (int.parse(villager['birthday_day']) == currentDay) {
          var translatedName = await translator.translate(villager['name'],
              from: 'en', to: 'ko');
          // var translatedSpecies = await translator
          //     .translate(result[i]['species'], from: 'en', to: 'ko');
          // var translatedPersonality = await translator
          //     .translate(result[i]['personality'], from: 'en', to: 'ko');
          // var translatedBirth = await translator
          //     .translate(result[i]['birthday_month'], from: 'en', to: 'ko');
          // var translatedSign = await translator.translate(result[i]['sign'],
          //     from: 'en', to: 'ko');
          // var translatedPhrase = await translator
          //     .translate(result[i]['phrase'], from: 'en', to: 'ko');
          var translatedQuote = await translator.translate(villager['quote'],
              from: 'en', to: 'ko');

          setState(() {
            print(villager);
            edenData?.add(Map<String, dynamic>.from(villager));
            print("edenData :  $edenData");
            print("detailInfo before translated : $villager");
            villager["name"] = translatedName.text;
            // villager["species"] = translatedSpecies.text;
            // villager["personality"] = translatedPersonality.text;
            // villager["birthday_month"] = translatedBirth.text;
            // villager["sign"] = translatedSign.text;
            // villager["phrase"] = translatedPhrase.text;
            villager["quote"] = translatedQuote.text;
            print(villager);
            transData?.add(Map<String, dynamic>.from(villager));
            print(transData);
            print("detailInfo after translated : $villager");
          });
        }
      }
    }

    return response.body;
  }
}

Widget loading(context) {
  double screenHeight = MediaQuery.of(context).size.height;
  return Container(
    width: double.infinity,
    height: (screenHeight - 120),
    decoration: const BoxDecoration(
      color: white,
    ),
    child: Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.asset(
            'assets/images/logo.png',
            width: 100.0,
          ),
          SizedBox(
            height: 20.0,
          ),
          Text(
            '로딩 중입니다.\n잠시만 기다려주세요.',
            style: TextStyle(
              fontSize: 24,
              fontFamily: 'Monggle',
              fontWeight: FontWeight.w700,
              color: mainGreen,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(
            height: 50.0,
          ),
          CircularProgressIndicator(
            color: yellow,
            backgroundColor: mainGreen,
            strokeWidth: 2,
          )
        ],
      ),
    ),
  );
}
