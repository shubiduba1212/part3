import 'package:chap04_flutter_api/widget/main_app_bar.dart';
import 'package:chap04_flutter_api/widget/navigationbar.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:translator/translator.dart';
import 'package:chap04_flutter_api/const/colors.dart';

class HoroscopeModel {
  final String date;
  final String description;

  HoroscopeModel({required this.date, required this.description});

  factory HoroscopeModel.fromJson(Map<String, dynamic> json) {
    return HoroscopeModel(
      date: json['data']['date'],
      description: json['data']['horoscope_data'],
    );
  }
}

class HoroscopeApi {
  static const String baseUrl =
      "https://horoscope-app-api.vercel.app/api/v1/get-horoscope/daily";

  Future<HoroscopeModel> fetchHoroscope(String sign) async {
    final response = await http.get(Uri.parse('$baseUrl?sign=$sign&day=TODAY'));

    if (response.statusCode == 200) {
      var jsonData = jsonDecode(response.body);

      final translator = GoogleTranslator();
      var translatedDescription = await translator.translate(
        jsonData['data']['horoscope_data'],
        from: 'en',
        to: 'ko',
      );
      jsonData['data']['horoscope_data'] = translatedDescription.text;

      return HoroscopeModel.fromJson(jsonData);
    } else {
      throw Exception('Failed to load horoscope');
    }
  }
}

class Villager {
  final String imageUrl;
  final String sign;

  Villager({required this.imageUrl, required this.sign});

  factory Villager.fromJson(Map<String, dynamic> json) {
    return Villager(
      imageUrl: json['image_url'],
      sign: json['sign'],
    );
  }
}

class VillagerApi {
  static const String baseUrl = 'https://api.nookipedia.com/villagers';
  static const Map<String, String> headers = {
    'X-API-KEY': '1e12770e-930f-4f94-8bf2-7dd37587e30b'
  };

  Future<List<Villager>> fetchVillagers() async {
    final response = await http.get(Uri.parse(baseUrl), headers: headers);

    if (response.statusCode == 200) {
      List<dynamic> jsonData = jsonDecode(response.body);
      return jsonData.map((json) => Villager.fromJson(json)).toList();
    } else {
      throw Exception('Failed to load villagers');
    }
  }
}

class HoroscopeWidget extends StatefulWidget {
  const HoroscopeWidget({super.key});

  @override
  State<HoroscopeWidget> createState() => _HoroscopeState();
}

class _HoroscopeState extends State<HoroscopeWidget> {
  int currentPageIndex = 2;
  String horoscopeName = "양자리";
  String horoscopeImageUrl = "assets/images/horoscope/aries.png";
  HoroscopeModel? currentHoroscope;
  List<Villager>? allVillagers;
  List<Villager>? filteredVillagers;
  bool isLoading = false;
  String errorMessage = '';

  @override
  void initState() {
    super.initState();
    _fetchHoroscope("aries");
    _fetchVillagers();
  }

  void _fetchHoroscope(String sign) async {
    setState(() {
      isLoading = true;
      errorMessage = '';
    });

    final horoscopeApi = HoroscopeApi();
    try {
      final horoscope = await horoscopeApi.fetchHoroscope(sign);
      setState(() {
        currentHoroscope = horoscope;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        errorMessage = 'Failed to load horoscope: $e';
        isLoading = false;
      });
    }
  }

  void _fetchVillagers() async {
    setState(() {
      isLoading = true;
      errorMessage = '';
    });

    final villagerApi = VillagerApi();
    try {
      final villagerList = await villagerApi.fetchVillagers();
      setState(() {
        allVillagers = villagerList;
        _filterVillagersBySign(villagerList, "aries");
      });
    } catch (e) {
      setState(() {
        errorMessage = 'Failed to load villagers: $e';
        isLoading = false;
      });
    }
  }

  void _filterVillagersBySign(List<Villager> villagerList, String sign) {
    setState(() {
      filteredVillagers = villagerList
          .where(
              (villager) => villager.sign.toLowerCase() == sign.toLowerCase())
          .toList();
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: bg,
      appBar: MainAppBar(),
      bottomNavigationBar: bottomNavigator(context, currentPageIndex),
      body: ListView(
        children: [
          Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      Padding(
                        padding: EdgeInsets.only(top: 30, bottom: 20),
                        child: Image.asset(
                          'assets/images/horoscope/blue_ribbon.png',
                        ),
                      ),
                      Text(
                        '별자리 운세',
                        style: TextStyle(
                          fontFamily: 'Monggle',
                          fontSize: 28,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              Container(
                width: screenWidth - 90,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _buildHoroscopeButton('양자리', 'aries'),
                    _buildHoroscopeButton('황소자리', 'taurus'),
                    _buildHoroscopeButton('쌍둥이자리', 'gemini'),
                    _buildHoroscopeButton('게자리', 'cancer'),
                    _buildHoroscopeButton('사자자리', 'leo'),
                    _buildHoroscopeButton('처녀자리', 'virgo'),
                  ],
                ),
              ),
              Container(
                width: screenWidth - 90,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _buildHoroscopeButton('천칭자리', 'libra'),
                    _buildHoroscopeButton('전갈자리', 'scorpio'),
                    _buildHoroscopeButton('사수자리', 'sagittarius'),
                    _buildHoroscopeButton('염소자리', 'capricorn'),
                    _buildHoroscopeButton('물병자리', 'aquarius'),
                    _buildHoroscopeButton('물고기자리', 'pisces'),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.only(top: 12),
                width: screenWidth - 40,
                height: 350,
                decoration: BoxDecoration(
                  color: Colors.orange,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(
                  children: [
                    SizedBox(height: 20),
                    Container(
                      width: 90,
                      height: 90,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(50),
                      ),
                      child: Center(
                        child: Image(
                          image: AssetImage(horoscopeImageUrl),
                          width: 50,
                          height: 50,
                        ),
                      ),
                    ),
                    SizedBox(height: 10),
                    Text(
                      horoscopeName,
                      style: TextStyle(
                        fontFamily: 'beomseok',
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    Center(
                      child: isLoading
                          ? CircularProgressIndicator()
                          : currentHoroscope == null
                          ? Text(
                        '운세를 불러오는데 실패했습니다.',
                        style: TextStyle(
                          fontFamily: 'beomseok',
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      )
                          : Padding(
                        padding: const EdgeInsets.only(
                            left: 15, top: 10, bottom: 10, right: 15),
                        child: Container(
                          height: 180,
                          child: SingleChildScrollView(
                            scrollDirection: Axis.vertical,
                            child: Text(
                              currentHoroscope!.description,
                              style: TextStyle(
                                fontFamily: 'beomseok',
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 18),
              Text(
                '$horoscopeName 주민',
                style: TextStyle(
                  fontFamily: 'beomseok',
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(
                height: 18,
              ),
              Container(
                height: 50,
                width: screenWidth - 40,
                child: Center(
                  child: isLoading
                      ? CircularProgressIndicator()
                      : filteredVillagers == null
                      ? Text(
                    '',
                    style: TextStyle(
                      fontFamily: 'beomseok',
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                    ),
                  )
                      : ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: filteredVillagers!.length,
                    itemBuilder: (context, index) {
                      final villager = filteredVillagers![index];
                      return Column(
                        children: [

                          Padding(
                            padding: const EdgeInsets.only(right: 8.0),
                            child: Container( decoration: const BoxDecoration(
                              color: Colors.white,
                              shape: BoxShape.circle,
                            ),
                              child: Image.network(
                                villager.imageUrl,
                                width: 50,
                                height: 50,
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildHoroscopeButton(String name, String sign) {
    String assetPath = 'assets/images/horoscope/$sign.png';
    return Column(
      children: [
        Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
          ),
          width: 45,
          height: 45,
          child: IconButton(
            padding: EdgeInsets.zero,
            icon: Image.asset(
              assetPath,
              width: 30,
              height: 30,
            ),
            onPressed: () {
              setState(() {
                horoscopeName = name;
                horoscopeImageUrl = assetPath;
                _fetchHoroscope(sign);
                if (allVillagers != null) {
                  _filterVillagersBySign(allVillagers!, sign);
                }
              });
            },
          ),
        ),
        Text(
          name,
          style: const TextStyle(
            fontSize: 13,
            fontFamily: 'beomseok',
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }
}
