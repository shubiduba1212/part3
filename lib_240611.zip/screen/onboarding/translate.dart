import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Home")),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Info()),
            );
          },
          child: Text("Go to Info Page"),
        ),
      ),
    );
  }
}

class Info extends StatelessWidget {
  const Info({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("버전 정보 (Rest API 호출)"),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: HttpApp(),
    );
  }
}

class HttpApp extends StatefulWidget {
  const HttpApp({super.key});

  @override
  State<HttpApp> createState() => _HttpAppState();
}

class _HttpAppState extends State<HttpApp> {
  Map<String, dynamic>? userData;
  bool isLoading = true;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    getJSONData();
  }

  int currentPage = 4;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(
          child: isLoading
              ? CircularProgressIndicator()
              : errorMessage != null
                  ? Text('Error: $errorMessage')
                  : Card(
                      child: Container(
                        padding: EdgeInsets.all(16.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisSize: MainAxisSize.min,
                          children: <Widget>[
                            Text('  버     전    :  ${userData!['version']}',
                                style: TextStyle(fontSize: 18)),
                            Text('  제     작    :  ${userData!['teamName']}',
                                style: TextStyle(fontSize: 18)),
                            Text('업 데 이 트 :  ${userData!['date']}',
                                style: TextStyle(fontSize: 18)),
                          ],
                        ),
                      ),
                    ),
        ),
      ),
    );
  }

  Future<void> getJSONData() async {
    try {
      var url = 'http://10.0.2.2:8081/valid/users/1'; // 에뮬레이터를 사용하는 경우
      print('Fetching data from $url');
      var response = await http.get(Uri.parse(url), headers: {});
      print('Response status: ${response.statusCode}');
      print('Response body: ${response.body}');

      if (response.statusCode == 200) {
        var jsonResponse = response.body;
        var dataResponse = json.decode(jsonResponse);
        print('Decoded JSON: $dataResponse');

        if (dataResponse is Map) {
          var user = dataResponse['results']['info'];
          setState(() {
            userData = user.cast<String, dynamic>();
            isLoading = false;
          });
        } else {
          setState(() {
            errorMessage = 'Unexpected JSON format';
            isLoading = false;
          });
        }
      } else {
        setState(() {
          errorMessage = 'Failed to load data: ${response.statusCode}';
          isLoading = false;
        });
      }
    } catch (e) {
      print('Error occurred: $e');
      setState(() {
        errorMessage = 'Error: $e';
        isLoading = false;
      });
    }
  }
}
