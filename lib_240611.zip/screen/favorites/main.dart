import 'dart:convert';
import 'package:chap04_flutter_api/widget/main_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../const/colors.dart';
import '../detail/detailMain.dart';
// import '../detail/main.dart';
import 'package:chap04_flutter_api/widget/navigationbar.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  int get currentPageIndex => 3;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: MainAppBar(),
        body: const VillagersListScreen(),
        backgroundColor: const Color(0xFFFBFCD5),
        bottomNavigationBar: bottomNavigator(context, currentPageIndex),
      ),
    );
  }
}

class VillagersListScreen extends StatefulWidget {
  const VillagersListScreen({Key? key}) : super(key: key);

  @override
  _VillagersListScreenState createState() => _VillagersListScreenState();
}

class _VillagersListScreenState extends State<VillagersListScreen> {
  List<dynamic> villagers = [];
  List<String> villagerNames = ['Apple'];
  bool isLoading = true;
  String errorMessage = '';

  @override
  void initState() {
    super.initState();
    fetchVillagers();
  }

  Future<void> fetchVillagers() async {
    const apiKey =
        '1e12770e-930f-4f94-8bf2-7dd37587e30b'; // Replace with your actual API key

    try {
      final response = await http.get(
        Uri.parse('https://api.nookipedia.com/villagers'),
        headers: {
          'X-API-KEY': apiKey,
        },
      );

      if (response.statusCode == 200) {
        setState(() {
          villagers = json.decode(response.body);
          isLoading = false;
        });
      } else {
        throw Exception('Failed to load villagers');
      }
    } catch (e) {
      setState(() {
        isLoading = false;
        errorMessage = 'Error fetching villagers: $e';
      });
      print('Error fetching villagers: $e');
    }
  }

  void removeVillager(int index) {
    setState(() {
      villagerNames.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (errorMessage.isNotEmpty) {
      return Center(child: Text(errorMessage));
    }

    if (villagerNames.isEmpty) {
      return const Center(
        child: Text(
          '아직 즐겨찾기에 추가된 캐릭터가 없습니다. 상세페이지에서 추가해 주세요.',
          style: TextStyle(fontSize: 18.0),
          textAlign: TextAlign.center,
        ),
      );
    }

    return ListView.builder(
      itemCount: villagerNames.length,
      itemBuilder: (context, index) {
        String villagerName = villagerNames[index];
        var villager = villagers.firstWhere(
          (villager) => villager['name'] == villagerName,
          orElse: () => null,
        );

        String titleColor =
            villager != null ? villager['title_color'] ?? '000000' : '000000';

        return VillagerTile(
          villager: villager,
          titleColor: titleColor,
          onRemove: () => removeVillager(index),
        );
      },
    );
  }
}

class VillagerTile extends StatefulWidget {
  final dynamic villager;
  final String titleColor;
  final VoidCallback onRemove;

  const VillagerTile({
    Key? key,
    required this.villager,
    required this.titleColor,
    required this.onRemove,
  }) : super(key: key);

  @override
  _VillagerTileState createState() => _VillagerTileState();
}

class _VillagerTileState extends State<VillagerTile> {
  bool isImageWhite = false;

  void toggleImageColor() {
    setState(() {
      isImageWhite = !isImageWhite;
      if (isImageWhite) {
        widget.onRemove();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    String modifiedTitleColor = widget.titleColor.toLowerCase() == 'ffffff'
        ? '800080' // Purple color
        : widget.titleColor;

    return ListTile(
      title: Row(
        children: [
          GestureDetector(
            onTap: () {
              if (!isImageWhite) {
                // Navigate to detail page
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => DetailMain(selectedName: ''),
                  ),
                );
              }
            },
            child: MouseRegion(
              cursor: SystemMouseCursors.click,
              child: Container(
                alignment: Alignment.center,
                width: 370,
                height: 51,
                decoration: BoxDecoration(
                  color: Color(int.parse('0xFF$modifiedTitleColor')),
                  borderRadius: BorderRadius.circular(20.0),
                  boxShadow: [
                    BoxShadow(
                      color: Color(int.parse('0xFF$modifiedTitleColor'))
                          .withOpacity(0.5),
                      spreadRadius: 0,
                      blurRadius: 0,
                      offset: const Offset(2, 3), // changes position of shadow
                    ),
                  ],
                ),
                child: Center(
                  child: Row(
                    children: [
                      const SizedBox(width: 10),
                      Container(
                        width: 30,
                        height: 30,
                        child: Image.network(widget.villager != null
                            ? widget.villager['image_url']
                            : 'https://example.com/placeholder_image.png'),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Container(
                          alignment: Alignment.center,
                          child: Padding(
                            padding: const EdgeInsets.only(right: 200),
                            child: Text(
                              widget.villager != null
                                  ? widget.villager['name']
                                  : 'Unknown',
                              style: const TextStyle(
                                fontSize: 16.0,
                                fontWeight: FontWeight.bold,
                              ),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: toggleImageColor,
                        child: Image.asset(
                          'assets/images/pngwing 1.png',
                          height: 30,
                          color: isImageWhite ? Colors.white : null,
                        ),
                      ),
                      const SizedBox(width: 10),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
