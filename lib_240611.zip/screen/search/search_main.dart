import 'dart:convert';

import 'package:chap04_flutter_api/screen/search/search_Name.dart';
import 'package:chap04_flutter_api/screen/search/select_birthday_month.dart';
import 'package:chap04_flutter_api/screen/search/select_species.dart';
import 'package:chap04_flutter_api/widget/main_app_bar.dart';
import 'package:flutter/material.dart';
import '../../const/colors.dart';
import '../../widget/navigationbar.dart';
import 'package:http/http.dart' as http;
import 'package:translator/translator.dart';

class SearchMainPage extends StatefulWidget {
  const SearchMainPage({Key? key}) : super(key: key);

  @override
  State<SearchMainPage> createState() => _SearchMainPageState();
}

class _SearchMainPageState extends State<SearchMainPage> {
  int currentPageIndex = 1; // 현재 페이지 index(Navbar기준)

  String? selectedSpecies; // 선택한 종족
  String? selectedBirthdayMonth; //선택한 생일(월)
  String? searchText = ''; // 검색단어
  bool showSpeciesOptions = true; // 종족선택창 활성화 여부
  bool showBirthdayMonthOptions = true; // 생일(월) 활성화 여부
  List<String> speciesList = []; // 종족리스트
  List<String> birthdayMonthList = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
  ]; // 생일(월) 리스트
  bool isLoading = true; // 로딩중
  bool showSpeciesList = false;
  bool showBirthdayMonthList = false;
  final translator = GoogleTranslator();
  static bool showVillagers = false;

  void toggleSpeciesOptions() {
    setState(() {
      showSpeciesOptions = true;
      showSpeciesList = true;
      showBirthdayMonthOptions = false;
      showBirthdayMonthList = false;
    });
  }

  void toggleBirthdayOptions() {
    setState(() {
      showBirthdayMonthOptions = true;
      showBirthdayMonthList = true;
      showSpeciesOptions = false;
      showSpeciesList = false;
    });
  }

  void submitSearch() {
    if (searchText!.isNotEmpty) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => SearchNamePage(searchText)),
      );
    }
  }

  @override
  void initState() {
    super.initState();
    getAllSpeciesData();
    toggleSpeciesOptions();
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width; // 기기 너비!
    double screenHeight = MediaQuery.of(context).size.height; // 기기 높이!

    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: MainAppBar(),
      bottomNavigationBar: bottomNavigator(context, currentPageIndex),
      backgroundColor: bg,
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            Container(
              width: screenWidth - 40,
              height: 40,
              decoration: BoxDecoration(
                  color: mainGreen,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0xFF00753F),
                      offset: Offset(2, 3),
                    )
                  ]),
              child: TextField(
                onChanged: (text) {
                  setState(() {
                    searchText = text;
                  });
                },
                onSubmitted: (value) {
                  submitSearch();
                },
                decoration: InputDecoration(
                  hintText: '',
                  suffixIcon: Icon(Icons.search, color: Colors.white),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide.none,
                  ),
                ),
                style: TextStyle(color: Colors.white),
                textAlignVertical: TextAlignVertical.center,
              ),
            ),
            SizedBox(height: 14),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: ((screenWidth - 40) / 2) - 10,
                  height: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: showSpeciesOptions
                        ? [
                            BoxShadow(
                              color: Color(0xFFA95B00),
                              offset: Offset(2, 3),
                            ),
                          ]
                        : [],
                  ),
                  child: ElevatedButton(
                    onPressed: toggleSpeciesOptions,
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          showSpeciesOptions ? yellow : Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    child: Text(
                      '종족',
                      style: TextStyle(
                          fontSize: 20,
                          fontFamily: 'Monggle',
                          color: showSpeciesOptions
                              ? Colors.white
                              : Colors.yellow),
                    ),
                  ),
                ),
                Container(
                  width: ((screenWidth - 40) / 2) - 10,
                  height: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: showBirthdayMonthOptions
                        ? [
                            BoxShadow(
                              color: Color(0xFF0081DC),
                              offset: Offset(2, 3),
                            ),
                          ]
                        : [],
                  ),
                  child: ElevatedButton(
                    onPressed: toggleBirthdayOptions,
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          showBirthdayMonthOptions ? blue : Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                    child: Text(
                      '생일',
                      style: TextStyle(
                          fontSize: 20,
                          fontFamily: 'Monggle',
                          color:
                              showBirthdayMonthOptions ? Colors.white : blue),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 16),
            if (showSpeciesList)
              Container(
                width: screenWidth - 40,
                height: screenHeight - 310,
                decoration: BoxDecoration(
                  color: yellow.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: isLoading
                    ? loading(context)
                    : GridView.builder(
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 0,
                          mainAxisSpacing: 20,
                          childAspectRatio: (screenWidth / 2 - 40) / 30,
                        ),
                        itemCount: speciesList.length,
                        itemBuilder: (context, index) {
                          return ListTile(
                            title: ElevatedButton(
                              onPressed: () {
                                setState(() {
                                  selectedSpecies = speciesList[index];
                                });
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => SelectedSpeciesApp(
                                      selectedSpecies: speciesList[index],
                                    ),
                                  ),
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                padding: EdgeInsets.zero,
                                backgroundColor:
                                    selectedSpecies == speciesList[index]
                                        ? yellow
                                        : Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                ),
                              ),
                              child: Text(
                                speciesList[index],
                                style: TextStyle(
                                  fontSize: 16,
                                  fontFamily: 'Monggle',
                                  color: selectedSpecies == speciesList[index]
                                      ? Colors.white
                                      : yellow,
                                ),
                              ),
                            ),
                          );
                        },
                      ),
              ),
            if (showBirthdayMonthList)
              Container(
                width: screenWidth - 40,
                height: screenHeight - 565,
                decoration: BoxDecoration(
                  color: blue.withOpacity(0.5), // 생일 버튼을 눌렀을 때의 색상 설정
                  borderRadius: BorderRadius.circular(20),
                ),
                child: isLoading
                    ? loading(context)
                    : GridView.builder(
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 0,
                          mainAxisSpacing: 20,
                          childAspectRatio: (screenWidth / 2 - 40) / 30,
                        ),
                        itemCount: birthdayMonthList.length,
                        itemBuilder: (context, index) {
                          return ListTile(
                            title: ElevatedButton(
                              onPressed: () {
                                setState(() {
                                  selectedBirthdayMonth =
                                      birthdayMonthList[index];
                                });
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        SelectedBirthdayMonthPage(
                                      selectedBirthdayMonth:
                                          birthdayMonthList[index],
                                    ),
                                  ),
                                );
                              },
                              style: ElevatedButton.styleFrom(
                                padding: EdgeInsets.zero,
                                backgroundColor: selectedBirthdayMonth ==
                                        birthdayMonthList[index]
                                    ? blue
                                    : Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                ),
                              ),
                              child: Text(
                                birthdayMonthList[index],
                                style: TextStyle(
                                  fontSize: 16,
                                  fontFamily: 'Monggle',
                                  color: selectedBirthdayMonth ==
                                          birthdayMonthList[index]
                                      ? Colors.white
                                      : blue,
                                ),
                              ),
                            ),
                          );
                        },
                      ),
              )
          ],
        ),
      ),
    );
  }

  // 모든 종족 가져오기
  Future<void> getAllSpeciesData() async {
    setState(() {
      isLoading = true;
    });

    var url = 'https://api.nookipedia.com/villagers';
    var response = await http.get(
      Uri.parse(url),
      headers: {"X-API-KEY": "1e12770e-930f-4f94-8bf2-7dd37587e30b"},
    );

    if (response.statusCode == 200) {
      var dataConvertedToJSON = json.decode(response.body);
      List<dynamic> villagers = dataConvertedToJSON;

      Set<String> allSpecies = {};
      for (var villager in villagers) {
        allSpecies.add(villager['species']);
      }

      // 번역하기
      // List<String> translatedSpeciesList = [];
      // for (String species in allSpecies) {
      //   var translation = await translator.translate(species, to: 'ko');
      //   translatedSpeciesList.add(translation.text);
      // }

      setState(() {
        // speciesList = translatedSpeciesList;
        speciesList = allSpecies.toList();
        isLoading = false;
      });

      // 콘솔에 종족 데이터 출력
      print('종족 데이터: $speciesList');
    } else {
      // API 호출 실패 처리
      print('API 호출에 실패했습니다. 상태 코드: ${response.statusCode}');
      isLoading = false;
    }
  }

// 로딩 페이지
  Widget loading(context) {
    double screenHeight = MediaQuery.of(context).size.height;
    return Container(
      width: double.infinity,
      height: (screenHeight - 120),
      decoration: const BoxDecoration(
        color: white,
      ),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              'assets/images/logo.png',
              width: 100.0,
            ),
            SizedBox(
              height: 20.0,
            ),
            Text(
              '로딩 중입니다.\n잠시만 기다려주세요.',
              style: TextStyle(
                fontSize: 24,
                fontFamily: 'Monggle',
                fontWeight: FontWeight.w700,
                color: mainGreen,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(
              height: 50.0,
            ),
            CircularProgressIndicator(
              color: yellow,
              backgroundColor: mainGreen,
              strokeWidth: 2,
            )
          ],
        ),
      ),
    );
  }
}
