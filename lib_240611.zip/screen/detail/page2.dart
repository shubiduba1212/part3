import 'package:chap04_flutter_api/screen/detail/detailMain.dart';
import 'package:chap04_flutter_api/screen/detail/page1.dart';
import 'package:chap04_flutter_api/widget/navigationbar.dart';
import 'package:flutter/material.dart';

class Page2 extends StatelessWidget {
  const Page2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // 현재 페이지 index
    int currentPageIndex = 2;
    String? villagerName = "Ribbot";
    List<FavoriteVillager> addedVillagerList = new List.empty(growable: true);

    return Scaffold(
      bottomNavigationBar: bottomNavigator(context, currentPageIndex),
      body: Center(
        child: GestureDetector(
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => DetailMain(
                            selectedName: villagerName,
                            list: addedVillagerList,
                          )));
            },
            child: Text('page2')),
      ),
    );
  }
}
