import 'package:flutter/material.dart';

class FavoriteVillager {
  String? villagerName;

  FavoriteVillager({required this.villagerName});
}
