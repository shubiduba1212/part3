// widgets/main_app_bar.dart

import 'package:chap04_flutter_api/screen/onboarding/translate.dart';
import 'package:flutter/material.dart';
import '../const/colors.dart';
import '../screen/onboarding/main.dart';

class MainAppBar extends StatelessWidget implements PreferredSizeWidget {
  const MainAppBar({super.key});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      leading: Container(),
      backgroundColor: mainGreen,
      title: Row(
        children: [
          SizedBox(width: 56), // leading 공간 확보
          Image.asset(
            'assets/images/search/logo.png',
            width: 28,
          ),
          SizedBox(width: 10),
          Text(
            'SOOPCHIVE',
            style:
                TextStyle(fontSize: 20, fontFamily: 'Monggle', color: yellow),
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: Icon(
            Icons.info_outline,
            color: Colors.black26,
          ),
          onPressed: () {
            Navigator.of(context).push(MaterialPageRoute(
              builder: (context) => const Info(),
            ));
          },
        ),
      ],
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(kToolbarHeight);
}
