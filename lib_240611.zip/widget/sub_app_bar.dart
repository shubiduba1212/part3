// widgets/main_app_bar.dart
import 'package:flutter/material.dart';
import '../const/colors.dart';
import '../screen/onboarding/main.dart';
import '../screen/onboarding/translate.dart';

class SubAppBar extends StatelessWidget implements PreferredSizeWidget {
  const SubAppBar({super.key});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: mainGreen,
      title: Row(
        children: [
          SizedBox(width: 56), // leading 공간 확보
          Image.asset(
            'assets/images/search/logo.png',
            width: 28,
          ),
          SizedBox(width: 10),
          Text(
            'SOOPCHIVE',
            style:
                TextStyle(fontSize: 20, fontFamily: 'Monggle', color: yellow),
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: Icon(
            Icons.info_outline,
            color: Colors.black26,
          ),
          onPressed: () {
            Navigator.of(context).push(MaterialPageRoute(
              builder: (context) => const Info(),
            ));
          },
        ),
      ],
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(kToolbarHeight);
}
