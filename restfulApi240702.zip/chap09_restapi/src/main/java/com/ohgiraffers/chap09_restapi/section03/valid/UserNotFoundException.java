package com.ohgiraffers.chap09_restapi.section03.valid;

public class UserNotFoundException extends Exception{

  public UserNotFoundException(String msg) {
    super(msg);
  }
}
