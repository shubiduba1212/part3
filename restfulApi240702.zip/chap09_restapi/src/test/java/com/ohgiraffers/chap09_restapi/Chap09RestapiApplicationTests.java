package com.ohgiraffers.chap09_restapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chap09RestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
