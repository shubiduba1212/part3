// import 'dart:js';
import 'package:flutter/material.dart';
import 'package:wallet_template/const/colors.dart';
import 'package:wallet_template/screen/exchange/exchange_amount_screen.dart';
import 'package:wallet_template/screen/exchange/exchange_screen.dart';
import 'package:wallet_template/screen/home_screen.dart';
import 'package:wallet_template/screen/join_screen.dart';
import 'package:wallet_template/screen/login_screen.dart';
import 'package:wallet_template/screen/send/send_coin_screen.dart';
import 'package:wallet_template/screen/send/send_comp_screen.dart';
import 'package:wallet_template/screen/send/send_info_screen.dart';
import 'package:wallet_template/screen/send/send_pin_screen.dart';
import 'package:wallet_template/screen/send/send_screen.dart';
import 'package:wallet_template/screen/send/send_search_screen.dart';
import 'package:wallet_template/screen/send/wallet_address_screen.dart';
import 'package:wallet_template/screen/splash_screen.dart';
import 'package:wallet_template/screen/user/mypage_screen.dart';

void main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      routes: {
        '/':(context) => SplashScreen(), //스플래쉬 화면
        '/login_screen':(context) => LoginScreen(),
        '/join_screen':(context) => JoinScreen(),
        '/home_screen':(context) => HomeScreen(),
        '/send_screen':(context) => SendScreen(),
        '/exchange_screen':(context) => ExchangeScreen(),
        '/mypage_screen':(context) => MyPageScreen(),
        '/wallet_address':(context) => WalletAddrScreen(),
        '/send_coin_screen':(context) => SendCoinScreen(),
        '/send_search_screen':(context) => SendSearchScreen(),
        '/send_info_screen':(context) => SendInfoScreen(),
        '/send_pin_screen':(context) => SendPinScreen(),
        '/send_comp_screen':(context) => SendCompleteScreen(),
      },
      theme: ThemeData(
        fontFamily: 'Spoqa_R',
        useMaterial3: true,
        appBarTheme: AppBarTheme(
          iconTheme: IconThemeData(color: Colors.black),
          backgroundColor: Colors.white,
        ),
      ),
    )
  );
}
