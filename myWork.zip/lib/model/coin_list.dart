import 'package:flutter/material.dart';

//Main > 코인 리스트
class CoinList {
  String? imgPath; //코인 이미지 경로
  String? name; //코인명
  String? price; //코인 가격
  String? unit; //코인 단위
  String? won; //코인 가격 원화 환산 금액
  String? balance; //코인 잔액
  String? lockAmount; //잠금 수량
  String? available; //전송 가능한 수량

  CoinList(this.imgPath, this.name, this.price, this.unit, this.won); //메인 페이지 코인 리스트
  CoinList.exchange(this.imgPath, this.name); // 교환 > 메인 페이지 코인 리스트
  CoinList.send(this.name, this.unit, this.balance, this.lockAmount, this.available); // 보내기 > 코인 선택 페이지 관련 리스트 파일
}

//Exchange > 코인 교환 리스트
class CoinListExchange {
  final String imgPath; //코인 이미지 경로
  final String name; //코인명

  CoinListExchange(this.imgPath, this.name);
}

// class CoinListView extends StatefulWidget {
//   const CoinListView({Key? key}) : super(key: key);
//
//   @override
//   State<CoinListView> createState() => _CoinListViewState();
// }
//
// class _CoinListViewState extends State<CoinListView> {
//   //코인 이미지 경로
//   static List<String> coinImagePath = [
//     'assets/img/main/icon_coin_bit.svg',
//     'assets/img/main/icon_coin_eth.svg',
//     'assets/img/main/icon_coin_tara.svg',
//     'assets/img/main/icon_coin_trx.svg',
//     'assets/img/main/icon_coin_usdt.svg',
//     'assets/img/main/icon_coin_xrp.svg',
//   ];
//
//   //코인 이름
//   static List<String> coinName = [
//     'BitCoin',
//     'Etherium',
//     'TARA Coin',
//     'Tron',
//     'Tether',
//     'Ripple',
//   ];
//
//   //코인 가격
//   static List<String> coinPrice = [
//     '854,684,685',
//     '2,215,654',
//     '1',
//     '5,545',
//     '2,515',
//     '8,484',
//   ];
//
//   //코인 단위
//   static List<String> coinUnit = [
//     'BIT',
//     'ETH',
//     'TARA',
//     'TRX',
//     'USDT',
//     'XRP',
//   ];
//
//   //코인 원화 환산 금액
//   static List<String> coinWon = [
//     '31,200,000',
//     '2,100,000',
//     '10,000',
//     '630',
//     '1,250',
//     '680',
//   ];
//
//   final List<CoinList> coinList = List.generate(coinName.length, (index) =>
//       CoinList(coinImagePath[index], coinName[index], coinPrice[index], coinUnit[index], coinWon[index]));
//
//   @override
//   Widget build(BuildContext context) {
//     return const Placeholder();
//   }
// }
