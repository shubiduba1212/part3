import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../const/colors.dart';

class CommonTextFormField extends StatelessWidget {

  CommonTextFormField({
    required this.controller,
    required this.hintText,
    required this.validator,
    required this.onSaved,
    required this.title,
    this.isPassword,
    this.keyboardType,
    this.inputFormatters,
    this.maxLength,
    Key? key,
  }) : super(key: key);

  final String? title;
  final TextInputType? keyboardType;
  final TextEditingController controller;
  final FormFieldValidator<String>? validator;
  final ValueChanged<String?>? onSaved;
  final bool? isPassword;
  final String hintText;
  final List<TextInputFormatter>? inputFormatters;
  final int ?maxLength;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 20.0,
        ),
        Row(
          children: [
            Text(
              '${title}',
              style: TextStyle(
                color: Colors.black,
                fontSize: 16.0,
              ),
            ),
            Text(
              '* ',
              style: TextStyle(
                color: Colors.red,
                fontSize: 16.0,
              ),
            ),
          ],
        ),
        TextFormField(
        controller: controller,
        validator: validator,
        onSaved: onSaved,
        obscureText: null == isPassword ? false : true,
        decoration: InputDecoration(
          filled: true,
          //input에 배경색 추가 여부
          fillColor: Colors.white,
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
              width: 1,
              color: InputLine,
            ),
            borderRadius: BorderRadius.circular(6.0),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(width: 1, color: PRIMARY_COLOR),
            borderRadius: BorderRadius.circular(6.0),
          ),
          contentPadding: EdgeInsets.symmetric(
              vertical: 12.0, horizontal: 25.0),
          hintText: null == hintText ? '' : hintText,
          hintStyle: TextStyle(
            color: InputLine,
            fontSize: 16.0,
            fontWeight: FontWeight.w400,
          ),
          errorBorder: const OutlineInputBorder(
            borderSide: BorderSide(
              width: 1.0,
              color: PRIMARY_COLOR,
            ),
            borderRadius: BorderRadius.all(Radius.circular(
                6.0)),
          ),
          focusedErrorBorder: const OutlineInputBorder(
            borderSide: BorderSide(
              width: 1.0,
              color: PRIMARY_COLOR,
            ),
            borderRadius: BorderRadius.all(Radius.circular(
                6.0)),
          ),
          counterText: '', //텍스트 제한 글자수 비활성화
        ),
        keyboardType: keyboardType,
        inputFormatters: inputFormatters,
        maxLength: maxLength,
      ),
      ]
    );
  }
}