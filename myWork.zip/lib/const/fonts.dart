//Fonts
import 'dart:ui';

import 'package:google_fonts/google_fonts.dart';

// final eng = GoogleFonts.montserrat(
//   textStyle: TextStyle(fontSize: 22.0)
// )

final font_10 = 10;
