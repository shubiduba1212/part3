import 'package:flutter/material.dart';


class SlidableWidget extends StatefulWidget {
  final Widget child;
  final VoidCallback onSlide;

  const SlidableWidget({
    required this.child,
    required this.onSlide,
    Key? key
  }) : super(key: key);

  @override
  State<SlidableWidget> createState() => _SlidableWidgetState();
}

class _SlidableWidgetState extends State<SlidableWidget> with SingleTickerProviderStateMixin{
  late final AnimationController _controller;
  dynamic _dragExtent = 0;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _controller = AnimationController(vsync: this);
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    _controller.dispose();
  }

  Widget build(BuildContext context) => GestureDetector(
      onHorizontalDragStart: onDragStart,
      onHorizontalDragUpdate: onDragUpdate,
      onHorizontalDragEnd: onDragEnd,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return SlideTransition(
            position: AlwaysStoppedAnimation(Offset(-_controller.value, 0)),
            child: widget.child,
          );
        }
      ),
  );

  void onDragStart(DragStartDetails details) {
    setState(() {
      _dragExtent = 0; //default value
      _controller.reset();
    });
  }

  void onDragUpdate(DragUpdateDetails details) {
    _dragExtent += details.primaryDelta;

    setState(() {
      _controller.value = _dragExtent.abs() / context.size.width;
    });
  }

  void onDragEnd(DragEndDetails details) {
    _controller.fling();
  }

}
