import 'package:google_fonts/google_fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:wallet_template/const/colors.dart';
// destinations: [
// NavigationDestination(
// icon: SvgPicture.asset('assets/img/svg/icon_menu_wallet.svg', width:22.0, height: 22.0,),
// label: '지갑',
// selectedIcon: SvgPicture.asset('assets/img/svg/icon_menu_wallet_on.svg', width:22.0, height: 22.0,),
// ),
// NavigationDestination(
// icon: SvgPicture.asset('assets/img/svg/icon_menu_send.svg',  width:22.0, height: 22.0,),
// label: '보내기',
// selectedIcon: SvgPicture.asset('assets/img/svg/icon_menu_send_on.svg', width:22.0, height: 22.0,),
// ),
// NavigationDestination(
// icon: SvgPicture.asset('assets/img/svg/icon_menu_change.svg',  width:22.0, height: 22.0,),
// label: '교환',
// selectedIcon: SvgPicture.asset('assets/img/svg/icon_menu_change_on.svg', width:22.0, height: 22.0,),
// ),
// NavigationDestination(
// icon: SvgPicture.asset('assets/img/svg/icon_menu_mypage.svg',  width:22.0, height: 22.0,),
// label: '나의정보',
// selectedIcon: SvgPicture.asset('assets/img/svg/icon_menu_mypage_on.svg', width:22.0, height: 22.0,),
// ),
// ],

// DropdownButton<String>(
// // Step 3.
// value: dropdownValue,
// // Step 4.
// items: <String>['Dog', 'Cat', 'Tiger', 'Lion']
// .map<DropdownMenuItem<String>>((String value) {
// return DropdownMenuItem<String>(
// value: value,
// child: Container(
// width: MediaQuery.of(context).size.width - 64,
// padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
// decoration: BoxDecoration(
// borderRadius: BorderRadius.circular(6.0),
// border: Border.all(
// width: 1.0,
// color: border
// )
// ),
// child: Text(
// value,
// style: TextStyle(fontSize: 30),
// ),
// ),
// );
// }).toList(),
// // Step 5.
// onChanged: (String? newValue) {
// setState(() {
// dropdownValue = newValue!;
// });
// },
// ),



class Ref extends StatefulWidget {
  const Ref({Key? key}) : super(key: key);

  @override
  State<Ref> createState() => _RefState();
}

class _RefState extends State<Ref> {
  bool coinListClicked = false;
 //코인 리스트 클릭 여부
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:
      Container(
        color: Colors.white,
        padding: EdgeInsets.all(20.0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '타라 코인 목록',
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 22.0,
                      fontFamily: 'Spoqa_B',
                      fontWeight: FontWeight.w700),
                ),
                IconButton(
                    onPressed: () {
                      debugPrint(
                          'coin list page link button clicked.');
                    },
                    icon: Icon(
                      Icons.arrow_forward_ios,
                      size: 16.0,
                      color: Colors.black,
                    ))
              ],
            ),
            SizedBox(
              height: 20.0,
            ),
            Stack(
              fit: StackFit.loose,
              children: [
                SizedBox(
                  height: 108.0,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      SizedBox(
                        width: 70.0,
                        height: 60.0,
                        child: ElevatedButton(
                          onPressed: () {
                            debugPrint(
                                'transaction history button clicked.');
                          },
                          child: Text(
                            '거래내역',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 14.0,
                                fontFamily: 'Spoqa_B',
                                fontWeight: FontWeight.w700),
                            softWrap: true,
                            textAlign: TextAlign.center,
                          ),
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius:
                              BorderRadius.circular(4.0),
                            ),
                            padding: EdgeInsets.symmetric(
                                vertical: 8.0, horizontal: 16.0),
                            backgroundColor: PRIMARY_COLOR,
                            // minimumSize: Size.fromHeight(60.0),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 10.0,
                      ),
                      SizedBox(
                        width: 70.0,
                        height: 60.0,
                        child: ElevatedButton(
                          onPressed: () {
                            debugPrint('send button clicked.');
                          },
                          child: Text(
                            '보내기',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 14.0,
                                fontFamily: 'Spoqa_B',
                                fontWeight: FontWeight.w700),
                            softWrap: true,
                            textAlign: TextAlign.center,
                          ),
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius:
                              BorderRadius.circular(4.0),
                            ),
                            padding: EdgeInsets.symmetric(
                                vertical: 8.0, horizontal: 14.0),
                            backgroundColor: PRIMARY_COLOR,
                            // minimumSize: Size.fromHeight(60.0),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 10.0,
                      ),
                      SizedBox(
                        width: 70.0,
                        height: 60.0,
                        child: ElevatedButton(
                          onPressed: () {
                            debugPrint(
                                'copy address button clicked.');
                            // showPopup(); //지갑 주소 복사 알림 팝업창
                            // Clipboard.setData(ClipboardData(text: "0x279A6E150A971e76e88719e067d50787dE733E31"));
                          },
                          child: Text(
                            '주소복사',
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 14.0,
                                fontFamily: 'Spoqa_B',
                                fontWeight: FontWeight.w700),
                            softWrap: true,
                            textAlign: TextAlign.center,
                          ),
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius:
                              BorderRadius.circular(4.0),
                            ),
                            padding: EdgeInsets.symmetric(
                                vertical: 8.0, horizontal: 16.0),
                            backgroundColor: PRIMARY_COLOR,
                            // minimumSize: Size.fromHeight(60.0),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 1.0,
                      ),
                    ],
                  ),
                ), //거래내역/보내기/주소복사 버튼 영역

                AnimatedPositioned(
                  duration: Duration(milliseconds: 250),
                  left: !coinListClicked ? 0 : -240,
                  width: MediaQuery.of(context).size.width - 40,
                  // height: 108.0,
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        if (!coinListClicked) {
                          debugPrint(
                              'coin list clicked now - Activate.');
                          coinListClicked = true;
                        } else {
                          debugPrint(
                              'coin list clicked now - inactivate.');
                          coinListClicked = false;
                        }
                      });
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width,
                      // height: 500.0,
                      padding: EdgeInsets.symmetric(
                          vertical: 10.0, horizontal: 16.0),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(6.0),
                        border: Border.all(
                          color: border_sub,
                          width: 1.0,
                        ),
                        boxShadow: [
                          BoxShadow(
                              blurRadius: 2,
                              offset: const Offset(1, 1),
                              color:
                              Colors.black12.withOpacity(0.28))
                        ],
                      ),
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Padding(
                                padding: EdgeInsets.symmetric(
                                    vertical: 20.0),
                                child: Row(
                                  children: [
                                    SvgPicture.asset(
                                      'assets/img/main/tara_logo.svg',
                                      width: 44.0,
                                      height: 44.0,
                                    ),
                                    SizedBox(
                                      width: 10.0,
                                    ),
                                    Text(
                                      'Tara Coin',
                                      style: GoogleFonts.montserrat(
                                        fontSize: 16.0,
                                        fontWeight: FontWeight.w700,
                                        color: Colors.black,
                                      ),
                                      //   TextStyle(
                                      //       color: Colors.black,
                                      //       fontSize: 16.0,
                                      //       fontWeight: FontWeight.w700),
                                      // )
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.end,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    '1.000000 ',
                                    style: TextStyle(
                                      fontSize: 16.0,
                                      fontWeight: FontWeight.w700,
                                      fontFamily: 'Spoqa_B',
                                      color: Colors.black,
                                    ),
                                    // TextStyle(
                                    //   fontSize: 16.0,
                                    //   fontWeight: FontWeight.w700,
                                    //   color: Colors.black,
                                    // ),
                                  ),
                                  Text(
                                    '(TARA)',
                                    style: GoogleFonts.montserrat(
                                      fontSize: 16.0,
                                      fontWeight: FontWeight.w700,
                                      color: Colors.black,
                                    ),
                                    // TextStyle(
                                    //   fontSize: 16.0,
                                    //   fontWeight: FontWeight.w700,
                                    //   color: Colors.black,
                                    // ),
                                  ),
                                ],
                              ),
                              Text(
                                '￦ 280.000000',
                                style: TextStyle(
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w400,
                                  fontFamily: 'Spoqa_R',
                                  color: Gray,
                                ),
                              )
                            ],
                          )
                        ],
                      ),
                    ),
                  ),
                ) //코인 리스트 항목
              ],
            ),
            // SizedBox(
            //   height: 20.0,
            // ),
            SizedBox(
              height: 128.0 * coinList.length,
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: coinList.length,
                itemBuilder: (context, index){
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 20.0),
                    child: Stack(
                      fit: StackFit.loose,
                      children: [
                        SizedBox(
                          height: 108.0,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              SizedBox(
                                width: 70.0,
                                height: 60.0,
                                child: ElevatedButton(
                                  onPressed: () {
                                    debugPrint(
                                        'transaction history button clicked.');
                                  },
                                  child: Text(
                                    '거래내역',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 14.0,
                                        fontFamily: 'Spoqa_B',
                                        fontWeight: FontWeight.w700),
                                    softWrap: true,
                                    textAlign: TextAlign.center,
                                  ),
                                  style: ElevatedButton.styleFrom(
                                    shape: RoundedRectangleBorder(
                                      borderRadius:
                                      BorderRadius.circular(4.0),
                                    ),
                                    padding: EdgeInsets.symmetric(
                                        vertical: 8.0, horizontal: 16.0),
                                    backgroundColor: PRIMARY_COLOR,
                                    // minimumSize: Size.fromHeight(60.0),
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: 10.0,
                              ),
                              SizedBox(
                                width: 70.0,
                                height: 60.0,
                                child: ElevatedButton(
                                  onPressed: () {
                                    debugPrint('send button clicked.');
                                  },
                                  child: Text(
                                    '보내기',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 14.0,
                                        fontFamily: 'Spoqa_B',
                                        fontWeight: FontWeight.w700),
                                    softWrap: true,
                                    textAlign: TextAlign.center,
                                  ),
                                  style: ElevatedButton.styleFrom(
                                    shape: RoundedRectangleBorder(
                                      borderRadius:
                                      BorderRadius.circular(4.0),
                                    ),
                                    padding: EdgeInsets.symmetric(
                                        vertical: 8.0, horizontal: 14.0),
                                    backgroundColor: PRIMARY_COLOR,
                                    // minimumSize: Size.fromHeight(60.0),
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: 10.0,
                              ),
                              SizedBox(
                                width: 70.0,
                                height: 60.0,
                                child: ElevatedButton(
                                  onPressed: () {
                                    debugPrint(
                                        'copy address button clicked.');
                                    showPopup(); //지갑 주소 복사 알림 팝업창
                                    Clipboard.setData(ClipboardData(text: "0x279A6E150A971e76e88719e067d50787dE733E31"));
                                  },
                                  child: Text(
                                    '주소복사',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 14.0,
                                        fontFamily: 'Spoqa_B',
                                        fontWeight: FontWeight.w700),
                                    softWrap: true,
                                    textAlign: TextAlign.center,
                                  ),
                                  style: ElevatedButton.styleFrom(
                                    shape: RoundedRectangleBorder(
                                      borderRadius:
                                      BorderRadius.circular(4.0),
                                    ),
                                    padding: EdgeInsets.symmetric(
                                        vertical: 8.0, horizontal: 16.0),
                                    backgroundColor: PRIMARY_COLOR,
                                    // minimumSize: Size.fromHeight(60.0),
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: 1.0,
                              ),
                            ],
                          ),
                        ), //거래내역/보내기/주소복사 버튼 영역

                        AnimatedPositioned(
                          duration: Duration(milliseconds: 250),
                          left: !coinListClicked ? 0 : -240,
                          width: MediaQuery.of(context).size.width - 40,
                          // height: 108.0,
                          child: GestureDetector(
                            onTap: () {
                              setState(() {
                                if (!coinListClicked) {
                                  debugPrint(
                                      'coin list clicked now - Activate.');
                                  coinListClicked = true;
                                } else {
                                  debugPrint(
                                      'coin list clicked now - inactivate.');
                                  coinListClicked = false;
                                }
                              });
                            },
                            child: Container(
                              width: MediaQuery.of(context).size.width,
                              // height: 500.0,
                              padding: EdgeInsets.symmetric(
                                  vertical: 10.0, horizontal: 16.0),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(6.0),
                                border: Border.all(
                                  color: border_sub,
                                  width: 1.0,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                      blurRadius: 2,
                                      offset: const Offset(1, 1),
                                      color:
                                      Colors.black12.withOpacity(0.28))
                                ],
                              ),
                              child: Row(
                                mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    children: [
                                      Padding(
                                        padding: EdgeInsets.symmetric(
                                            vertical: 20.0),
                                        child: Row(
                                          children: [
                                            SvgPicture.asset(
                                              coinList[index].imgPath,
                                              width: 44.0,
                                              height: 44.0,
                                            ),
                                            SizedBox(
                                              width: 10.0,
                                            ),
                                            Text(
                                              coinList[index].name,
                                              style: GoogleFonts.montserrat(
                                                fontSize: 16.0,
                                                fontWeight: FontWeight.w700,
                                                color: Colors.black,
                                              ),
                                              //   TextStyle(
                                              //       color: Colors.black,
                                              //       fontSize: 16.0,
                                              //       fontWeight: FontWeight.w700),
                                              // )
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.end,
                                    children: [
                                      Row(
                                        children: [
                                          Text(
                                            coinList[index].price,
                                            style: TextStyle(
                                              fontSize: 16.0,
                                              fontWeight: FontWeight.w700,
                                              fontFamily: 'Spoqa_B',
                                              color: Colors.black,
                                            ),
                                            // TextStyle(
                                            //   fontSize: 16.0,
                                            //   fontWeight: FontWeight.w700,
                                            //   color: Colors.black,
                                            // ),
                                          ),
                                          Text(
                                            coinList[index].unit,
                                            style: GoogleFonts.montserrat(
                                              fontSize: 16.0,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.black,
                                            ),
                                            // TextStyle(
                                            //   fontSize: 16.0,
                                            //   fontWeight: FontWeight.w700,
                                            //   color: Colors.black,
                                            // ),
                                          ),
                                        ],
                                      ),
                                      Text(
                                        '￦ ${coinList[index].won}',
                                        style: TextStyle(
                                          fontSize: 14.0,
                                          fontWeight: FontWeight.w400,
                                          fontFamily: 'Spoqa_R',
                                          color: Gray,
                                        ),
                                      )
                                    ],
                                  )
                                ],
                              ),
                            ),
                          ),
                        ) //코인 리스트 항목
                      ],
                    ),
                  );
                },
              ),
            ),

            Container(
              color: Colors.white,
              padding: EdgeInsets.all(20.0),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '타라 코인 목록',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 22.0,
                            fontFamily: 'Spoqa_B',
                            fontWeight: FontWeight.w700),
                      ),
                      IconButton(
                          onPressed: () {
                            debugPrint(
                                'coin list page link button clicked.');
                          },
                          icon: Icon(
                            Icons.arrow_forward_ios,
                            size: 16.0,
                            color: Colors.black,
                          ))
                    ],
                  ),
                  SizedBox(
                    height: 20.0,
                  ),
                  Stack(
                    fit: StackFit.loose,
                    children: [
                      SizedBox(
                        height: 108.0,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            SizedBox(
                              width: 70.0,
                              height: 60.0,
                              child: ElevatedButton(
                                onPressed: () {
                                  debugPrint(
                                      'transaction history button clicked.');
                                },
                                child: Text(
                                  '거래내역',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14.0,
                                      fontFamily: 'Spoqa_B',
                                      fontWeight: FontWeight.w700),
                                  softWrap: true,
                                  textAlign: TextAlign.center,
                                ),
                                style: ElevatedButton.styleFrom(
                                  shape: RoundedRectangleBorder(
                                    borderRadius:
                                    BorderRadius.circular(4.0),
                                  ),
                                  padding: EdgeInsets.symmetric(
                                      vertical: 8.0, horizontal: 16.0),
                                  backgroundColor: PRIMARY_COLOR,
                                  // minimumSize: Size.fromHeight(60.0),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10.0,
                            ),
                            SizedBox(
                              width: 70.0,
                              height: 60.0,
                              child: ElevatedButton(
                                onPressed: () {
                                  debugPrint('send button clicked.');
                                },
                                child: Text(
                                  '보내기',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14.0,
                                      fontFamily: 'Spoqa_B',
                                      fontWeight: FontWeight.w700),
                                  softWrap: true,
                                  textAlign: TextAlign.center,
                                ),
                                style: ElevatedButton.styleFrom(
                                  shape: RoundedRectangleBorder(
                                    borderRadius:
                                    BorderRadius.circular(4.0),
                                  ),
                                  padding: EdgeInsets.symmetric(
                                      vertical: 8.0, horizontal: 14.0),
                                  backgroundColor: PRIMARY_COLOR,
                                  // minimumSize: Size.fromHeight(60.0),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10.0,
                            ),
                            SizedBox(
                              width: 70.0,
                              height: 60.0,
                              child: ElevatedButton(
                                onPressed: () {
                                  debugPrint(
                                      'copy address button clicked.');
                                  // showPopup(); //지갑 주소 복사 알림 팝업창
                                  // Clipboard.setData(ClipboardData(text: "0x279A6E150A971e76e88719e067d50787dE733E31"));
                                },
                                child: Text(
                                  '주소복사',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14.0,
                                      fontFamily: 'Spoqa_B',
                                      fontWeight: FontWeight.w700),
                                  softWrap: true,
                                  textAlign: TextAlign.center,
                                ),
                                style: ElevatedButton.styleFrom(
                                  shape: RoundedRectangleBorder(
                                    borderRadius:
                                    BorderRadius.circular(4.0),
                                  ),
                                  padding: EdgeInsets.symmetric(
                                      vertical: 8.0, horizontal: 16.0),
                                  backgroundColor: PRIMARY_COLOR,
                                  // minimumSize: Size.fromHeight(60.0),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 1.0,
                            ),
                          ],
                        ),
                      ), //거래내역/보내기/주소복사 버튼 영역

                      AnimatedPositioned(
                        duration: Duration(milliseconds: 250),
                        left: !coinListClicked ? 0 : -240,
                        width: MediaQuery.of(context).size.width - 40,
                        // height: 108.0,
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              if (!coinListClicked) {
                                debugPrint(
                                    'coin list clicked now - Activate.');
                                coinListClicked = true;
                              } else {
                                debugPrint(
                                    'coin list clicked now - inactivate.');
                                coinListClicked = false;
                              }
                            });
                          },
                          child: Container(
                            width: MediaQuery.of(context).size.width,
                            // height: 500.0,
                            padding: EdgeInsets.symmetric(
                                vertical: 10.0, horizontal: 16.0),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(6.0),
                              border: Border.all(
                                color: border_sub,
                                width: 1.0,
                              ),
                              boxShadow: [
                                BoxShadow(
                                    blurRadius: 2,
                                    offset: const Offset(1, 1),
                                    color:
                                    Colors.black12.withOpacity(0.28))
                              ],
                            ),
                            child: Row(
                              mainAxisAlignment:
                              MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.symmetric(
                                          vertical: 20.0),
                                      child: Row(
                                        children: [
                                          SvgPicture.asset(
                                            'assets/img/main/tara_logo.svg',
                                            width: 44.0,
                                            height: 44.0,
                                          ),
                                          SizedBox(
                                            width: 10.0,
                                          ),
                                          Text(
                                            'Tara Coin',
                                            style: GoogleFonts.montserrat(
                                              fontSize: 16.0,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.black,
                                            ),
                                            //   TextStyle(
                                            //       color: Colors.black,
                                            //       fontSize: 16.0,
                                            //       fontWeight: FontWeight.w700),
                                            // )
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.end,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          '1.000000 ',
                                          style: TextStyle(
                                            fontSize: 16.0,
                                            fontWeight: FontWeight.w700,
                                            fontFamily: 'Spoqa_B',
                                            color: Colors.black,
                                          ),
                                          // TextStyle(
                                          //   fontSize: 16.0,
                                          //   fontWeight: FontWeight.w700,
                                          //   color: Colors.black,
                                          // ),
                                        ),
                                        Text(
                                          '(TARA)',
                                          style: GoogleFonts.montserrat(
                                            fontSize: 16.0,
                                            fontWeight: FontWeight.w700,
                                            color: Colors.black,
                                          ),
                                          // TextStyle(
                                          //   fontSize: 16.0,
                                          //   fontWeight: FontWeight.w700,
                                          //   color: Colors.black,
                                          // ),
                                        ),
                                      ],
                                    ),
                                    Text(
                                      '￦ 280.000000',
                                      style: TextStyle(
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: 'Spoqa_R',
                                        color: Gray,
                                      ),
                                    )
                                  ],
                                )
                              ],
                            ),
                          ),
                        ),
                      ) //코인 리스트 항목
                    ],
                  ),
                  SizedBox(
                    height: 20.0,
                  ),
                  Stack(
                    fit: StackFit.loose,
                    children: [
                      SizedBox(
                        height: 108.0,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            SizedBox(
                              width: 70.0,
                              height: 60.0,
                              child: ElevatedButton(
                                onPressed: () {
                                  debugPrint(
                                      'transaction history button clicked.');
                                },
                                child: Text(
                                  '거래내역',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14.0,
                                      fontFamily: 'Spoqa_B',
                                      fontWeight: FontWeight.w700),
                                  softWrap: true,
                                  textAlign: TextAlign.center,
                                ),
                                style: ElevatedButton.styleFrom(
                                  shape: RoundedRectangleBorder(
                                    borderRadius:
                                    BorderRadius.circular(4.0),
                                  ),
                                  padding: EdgeInsets.symmetric(
                                      vertical: 8.0, horizontal: 16.0),
                                  backgroundColor: PRIMARY_COLOR,
                                  // minimumSize: Size.fromHeight(60.0),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10.0,
                            ),
                            SizedBox(
                              width: 70.0,
                              height: 60.0,
                              child: ElevatedButton(
                                onPressed: () {
                                  debugPrint('send button clicked.');
                                },
                                child: Text(
                                  '보내기',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14.0,
                                      fontFamily: 'Spoqa_B',
                                      fontWeight: FontWeight.w700),
                                  softWrap: true,
                                  textAlign: TextAlign.center,
                                ),
                                style: ElevatedButton.styleFrom(
                                  shape: RoundedRectangleBorder(
                                    borderRadius:
                                    BorderRadius.circular(4.0),
                                  ),
                                  padding: EdgeInsets.symmetric(
                                      vertical: 8.0, horizontal: 14.0),
                                  backgroundColor: PRIMARY_COLOR,
                                  // minimumSize: Size.fromHeight(60.0),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10.0,
                            ),
                            SizedBox(
                              width: 70.0,
                              height: 60.0,
                              child: ElevatedButton(
                                onPressed: () {
                                  debugPrint(
                                      'copy address button clicked.');
                                  // showPopup(); //지갑 주소 복사 알림 팝업창
                                  // Clipboard.setData(ClipboardData(text: "0x279A6E150A971e76e88719e067d50787dE733E31"));
                                },
                                child: Text(
                                  '주소복사',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14.0,
                                      fontFamily: 'Spoqa_B',
                                      fontWeight: FontWeight.w700),
                                  softWrap: true,
                                  textAlign: TextAlign.center,
                                ),
                                style: ElevatedButton.styleFrom(
                                  shape: RoundedRectangleBorder(
                                    borderRadius:
                                    BorderRadius.circular(4.0),
                                  ),
                                  padding: EdgeInsets.symmetric(
                                      vertical: 8.0, horizontal: 16.0),
                                  backgroundColor: PRIMARY_COLOR,
                                  // minimumSize: Size.fromHeight(60.0),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 1.0,
                            ),
                          ],
                        ),
                      ), //거래내역/보내기/주소복사 버튼 영역

                      AnimatedPositioned(
                        duration: Duration(milliseconds: 250),
                        left: !coinListClicked ? 0 : -240,
                        width: MediaQuery.of(context).size.width - 40,
                        // height: 108.0,
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              // bool ThisClicked = val;
                              if (!coinListClicked) {
                                debugPrint(
                                    'coin list clicked now - Activate.');
                                coinListClicked = true;
                              } else {
                                debugPrint(
                                    'coin list clicked now - inactivate.');
                                coinListClicked = false;
                              }
                            });
                          },
                          child: Container(
                            width: MediaQuery.of(context).size.width,
                            // height: 500.0,
                            padding: EdgeInsets.symmetric(
                                vertical: 10.0, horizontal: 16.0),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(6.0),
                              border: Border.all(
                                color: border_sub,
                                width: 1.0,
                              ),
                              boxShadow: [
                                BoxShadow(
                                    blurRadius: 2,
                                    offset: const Offset(1, 1),
                                    color:
                                    Colors.black12.withOpacity(0.28))
                              ],
                            ),
                            child: Row(
                              mainAxisAlignment:
                              MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.symmetric(
                                          vertical: 20.0),
                                      child: Row(
                                        children: [
                                          SvgPicture.asset(
                                            'assets/img/main/tara_logo.svg',
                                            width: 44.0,
                                            height: 44.0,
                                          ),
                                          SizedBox(
                                            width: 10.0,
                                          ),
                                          Text(
                                            'Tara Coin2',
                                            style: GoogleFonts.montserrat(
                                              fontSize: 16.0,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.black,
                                            ),
                                            //   TextStyle(
                                            //       color: Colors.black,
                                            //       fontSize: 16.0,
                                            //       fontWeight: FontWeight.w700),
                                            // )
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.end,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          '1.000000 ',
                                          style: TextStyle(
                                            fontSize: 16.0,
                                            fontWeight: FontWeight.w700,
                                            fontFamily: 'Spoqa_B',
                                            color: Colors.black,
                                          ),
                                          // TextStyle(
                                          //   fontSize: 16.0,
                                          //   fontWeight: FontWeight.w700,
                                          //   color: Colors.black,
                                          // ),
                                        ),
                                        Text(
                                          '(TARA)',
                                          style: GoogleFonts.montserrat(
                                            fontSize: 16.0,
                                            fontWeight: FontWeight.w700,
                                            color: Colors.black,
                                          ),
                                          // TextStyle(
                                          //   fontSize: 16.0,
                                          //   fontWeight: FontWeight.w700,
                                          //   color: Colors.black,
                                          // ),
                                        ),
                                      ],
                                    ),
                                    Text(
                                      '￦ 280.000000',
                                      style: TextStyle(
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: 'Spoqa_R',
                                        color: Gray,
                                      ),
                                    )
                                  ],
                                )
                              ],
                            ),
                          ),
                        ),
                      ) //코인 리스트 항목
                    ],
                  ),
                  SizedBox(
                    height: 20.0,
                  ),
                  Stack(
                    fit: StackFit.loose,
                    children: [
                      SizedBox(
                        height: 108.0,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            SizedBox(
                              width: 70.0,
                              height: 60.0,
                              child: ElevatedButton(
                                onPressed: () {
                                  debugPrint(
                                      'transaction history button clicked.');
                                },
                                child: Text(
                                  '거래내역',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14.0,
                                      fontFamily: 'Spoqa_B',
                                      fontWeight: FontWeight.w700),
                                  softWrap: true,
                                  textAlign: TextAlign.center,
                                ),
                                style: ElevatedButton.styleFrom(
                                  shape: RoundedRectangleBorder(
                                    borderRadius:
                                    BorderRadius.circular(4.0),
                                  ),
                                  padding: EdgeInsets.symmetric(
                                      vertical: 8.0, horizontal: 16.0),
                                  backgroundColor: PRIMARY_COLOR,
                                  // minimumSize: Size.fromHeight(60.0),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10.0,
                            ),
                            SizedBox(
                              width: 70.0,
                              height: 60.0,
                              child: ElevatedButton(
                                onPressed: () {
                                  debugPrint('send button clicked.');
                                },
                                child: Text(
                                  '보내기',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14.0,
                                      fontFamily: 'Spoqa_B',
                                      fontWeight: FontWeight.w700),
                                  softWrap: true,
                                  textAlign: TextAlign.center,
                                ),
                                style: ElevatedButton.styleFrom(
                                  shape: RoundedRectangleBorder(
                                    borderRadius:
                                    BorderRadius.circular(4.0),
                                  ),
                                  padding: EdgeInsets.symmetric(
                                      vertical: 8.0, horizontal: 14.0),
                                  backgroundColor: PRIMARY_COLOR,
                                  // minimumSize: Size.fromHeight(60.0),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10.0,
                            ),
                            SizedBox(
                              width: 70.0,
                              height: 60.0,
                              child: ElevatedButton(
                                onPressed: () {
                                  debugPrint(
                                      'copy address button clicked.');
                                  // showPopup(); //지갑 주소 복사 알림 팝업창
                                  // Clipboard.setData(ClipboardData(text: "0x279A6E150A971e76e88719e067d50787dE733E31"));
                                },
                                child: Text(
                                  '주소복사',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14.0,
                                      fontFamily: 'Spoqa_B',
                                      fontWeight: FontWeight.w700),
                                  softWrap: true,
                                  textAlign: TextAlign.center,
                                ),
                                style: ElevatedButton.styleFrom(
                                  shape: RoundedRectangleBorder(
                                    borderRadius:
                                    BorderRadius.circular(4.0),
                                  ),
                                  padding: EdgeInsets.symmetric(
                                      vertical: 8.0, horizontal: 16.0),
                                  backgroundColor: PRIMARY_COLOR,
                                  // minimumSize: Size.fromHeight(60.0),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 1.0,
                            ),
                          ],
                        ),
                      ), //거래내역/보내기/주소복사 버튼 영역

                      AnimatedPositioned(
                        duration: Duration(milliseconds: 250),
                        left: !coinListClicked ? 0 : -240,
                        width: MediaQuery.of(context).size.width - 40,
                        // height: 108.0,
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              if (!coinListClicked) {
                                debugPrint(
                                    'coin list clicked now - Activate.');
                                coinListClicked = true;
                              } else {
                                debugPrint(
                                    'coin list clicked now - inactivate.');
                                coinListClicked = false;
                              }
                            });
                          },
                          child: Container(
                            width: MediaQuery.of(context).size.width,
                            // height: 500.0,
                            padding: EdgeInsets.symmetric(
                                vertical: 10.0, horizontal: 16.0),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(6.0),
                              border: Border.all(
                                color: border_sub,
                                width: 1.0,
                              ),
                              boxShadow: [
                                BoxShadow(
                                    blurRadius: 2,
                                    offset: const Offset(1, 1),
                                    color:
                                    Colors.black12.withOpacity(0.28))
                              ],
                            ),
                            child: Row(
                              mainAxisAlignment:
                              MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.symmetric(
                                          vertical: 20.0),
                                      child: Row(
                                        children: [
                                          SvgPicture.asset(
                                            'assets/img/main/tara_logo.svg',
                                            width: 44.0,
                                            height: 44.0,
                                          ),
                                          SizedBox(
                                            width: 10.0,
                                          ),
                                          Text(
                                            'Tara Coin3',
                                            style: GoogleFonts.montserrat(
                                              fontSize: 16.0,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.black,
                                            ),
                                            //   TextStyle(
                                            //       color: Colors.black,
                                            //       fontSize: 16.0,
                                            //       fontWeight: FontWeight.w700),
                                            // )
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.end,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          '1.000000 ',
                                          style: TextStyle(
                                            fontSize: 16.0,
                                            fontWeight: FontWeight.w700,
                                            fontFamily: 'Spoqa_B',
                                            color: Colors.black,
                                          ),
                                          // TextStyle(
                                          //   fontSize: 16.0,
                                          //   fontWeight: FontWeight.w700,
                                          //   color: Colors.black,
                                          // ),
                                        ),
                                        Text(
                                          '(TARA)',
                                          style: GoogleFonts.montserrat(
                                            fontSize: 16.0,
                                            fontWeight: FontWeight.w700,
                                            color: Colors.black,
                                          ),
                                          // TextStyle(
                                          //   fontSize: 16.0,
                                          //   fontWeight: FontWeight.w700,
                                          //   color: Colors.black,
                                          // ),
                                        ),
                                      ],
                                    ),
                                    Text(
                                      '￦ 280.000000',
                                      style: TextStyle(
                                        fontSize: 14.0,
                                        fontWeight: FontWeight.w400,
                                        fontFamily: 'Spoqa_R',
                                        color: Gray,
                                      ),
                                    )
                                  ],
                                )
                              ],
                            ),
                          ),
                        ),
                      ) //코인 리스트 항목
                    ],
                  ),
                  SizedBox(
                    height: 20.0,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
