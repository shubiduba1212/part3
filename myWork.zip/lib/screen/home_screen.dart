import 'package:carousel_slider/carousel_controller.dart';
import 'package:flutter/services.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:marquee/marquee.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:wallet_template/const/colors.dart';

import '../model/coin_list.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool dataExist = false;
  int _current = 0; //슬라이드 페이저 index 초기값
  int selectedIndex = 0;//해당 페이지의 활성화된 내비게이션 index
  final CarouselController _controller = CarouselController(); //상단 배너 슬라이드 컨트롤러
  bool coinListClicked = false; //코인 리스트 클릭 여부
  int ?coinListIndex;

  //상단 배너 이미지
  List bannerList = [
    'assets/img/main/banner01.png',
    'assets/img/main/banner02.png',
    'assets/img/main/banner03.png',
  ];

  //코인 이미지 경로
  static List<String> coinImagePath = [
    'assets/img/main/icon_coin_bit.svg',
    'assets/img/main/icon_coin_eth.svg',
    'assets/img/main/icon_coin_tara.svg',
    'assets/img/main/icon_coin_trx.svg',
    'assets/img/main/icon_coin_usdt.svg',
    'assets/img/main/icon_coin_xrp.svg',
  ];

  //코인 이름
  static List<String> coinName = [
    'BitCoin',
    'Etherium',
    'TARA Coin',
    'Tron',
    'Tether',
    'Ripple',
  ];

  //코인 가격
  static List<String> coinPrice = [
    '854,684,685',
    '2,215,654',
    '1',
    '5,545',
    '2,515',
    '8,484',
  ];

  //코인 단위
  static List<String> coinUnit = [
    'BIT',
    'ETH',
    'TARA',
    'TRX',
    'USDT',
    'XRP',
  ];

  //코인 원화 환산 금액
  static List<String> coinWon = [
    '31,200,000',
    '2,100,000',
    '10,000',
    '630',
    '1,250',
    '680',
  ];

  final List<CoinList> coinList = List.generate(coinName.length, (index) =>
      CoinList(coinImagePath[index], coinName[index], coinPrice[index], coinUnit[index], coinWon[index]));

  //carousel slider
  Widget imageSlider() {
    return CarouselSlider(
      items: bannerList.map((imgPath) {
        return Builder(builder: (context) {
          return SizedBox(
            width: MediaQuery.of(context).size.width,
            child: Image(
              fit: BoxFit.contain,
              image: AssetImage(imgPath),
            ),
          );
        });
      }).toList(),
      options: CarouselOptions(
          height: 300,
          viewportFraction: 1.0,
          autoPlay: true,
          autoPlayInterval: const Duration(seconds: 3),
          onPageChanged: (index, reason) {
            setState(() {
              _current = index;
            });
          }),
    );
  }

  Widget sliderIndicator() {
    return Padding(
      padding: EdgeInsets.only(bottom: 25.0),
      child: Align(
        alignment: Alignment.bottomCenter,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: bannerList.asMap().entries.map((entry) {
            return GestureDetector(
              onTap: () => _controller.animateToPage(entry.key),
              child: Container(
                width: 12.0,
                height: 12.0,
                margin:
                    const EdgeInsets.symmetric(vertical: 8.0, horizontal: 4.0),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.indigo
                      .withOpacity(_current == entry.key ? 0.9 : 0.4),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  @override
  void initState() {
    // TODO: implement initState
    int selectedIndex = 0;
    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  void showPopup() {
    //지갑주소 복사 알림창
    showDialog(
        context: context,
        builder: (context) {
          return Dialog(
            child: Container(
              width: MediaQuery.of(context).size.width * 0.7,
              height: 150,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10), color: Colors.white),
              padding: EdgeInsets.all(20.0),
              child: Center(
                child: Column(
                  children: [
                    Expanded(
                      child: Text(
                        '지갑 주소가 복사되었습니다.',
                        style: TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w500,
                            color: Colors.black),
                      ),
                    ),
                    SizedBox(
                      height: 20.0,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text(
                        '확인',
                        style: TextStyle(
                            fontSize: 16.0,
                            fontWeight: FontWeight.w600,
                            color: Colors.white),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: PRIMARY_COLOR,
                        minimumSize: const Size.fromHeight(50.0),
                        elevation: 0,
                        shadowColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        bottomNavigationBar: NavigationBar(
          backgroundColor: White,
          selectedIndex: selectedIndex,
          onDestinationSelected: (value) => setState(() {
            selectedIndex = value;
            if(value == 0){
              Navigator.of(context).popAndPushNamed('/home_screen');
            }else if(value == 1){
              Navigator.of(context).popAndPushNamed('/send_screen');
            }else if(value == 2){
              Navigator.of(context).popAndPushNamed('/exchange_screen');
            }else if(value == 3){
              Navigator.of(context).popAndPushNamed('/mypage_screen');
            }
          }),
            destinations: [
              NavigationDestination(
                icon: Icon(Icons.account_balance_wallet_outlined),
                label: '지갑',
              ),
              NavigationDestination(
                icon: Icon(Icons.send_rounded),
                label: '보내기',
              ),
              NavigationDestination(
                icon: Icon(Icons.currency_exchange_outlined),
                label: '교환',
              ),
              NavigationDestination(
                icon: Icon(Icons.person),
                label: '나의정보',
              ),
            ],
          animationDuration: const Duration(milliseconds: 500),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
              ),
              child: Column(
                children: [
                  //상단 배너 영역
                  Stack(
                    children: [
                      Column(
                        children: [
                          Container(
                            height: 300.0,
                            color: PRIMARY_COLOR.withOpacity(0.3),
                            child: Stack(
                              children: [
                                imageSlider(),
                                sliderIndicator(),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 25.0,
                          )
                        ],
                      ), //상단 배너 영역

                      //공지사항 표시 영역
                      Positioned(
                        bottom: 0,
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 20.0),
                          width: MediaQuery.of(context).size.width,
                          child: Container(
                            padding: EdgeInsets.symmetric(
                                vertical: 5.0, horizontal: 20.0),
                            height: 50.0,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(50.0),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    blurRadius: 2,
                                    offset: const Offset(1, 1),
                                    color: Colors.black.withOpacity(0.3))
                              ],
                            ),
                            child: Marquee(
                              text: '공지사항 샘플입니다. 공지사항 테스트입니다.',
                              style: TextStyle(fontWeight: FontWeight.bold),
                              scrollAxis: Axis.horizontal,
                              crossAxisAlignment: CrossAxisAlignment.center,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  // 회원 아이디/금액/포인트/주소 복사 버튼
                  Container(
                    padding: EdgeInsets.all(20.0),
                    child: Container(
                      padding: EdgeInsets.all(16.0),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(6.0),
                        color: PRIMARY_COLOR.withOpacity(0.7),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                '회원 아이디 : ',
                                style: TextStyle(
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.white,
                                ),
                              ),
                              Text(
                                'Kimtara',
                                style: GoogleFonts.montserrat(
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(
                            height: 5.0,
                          ),
                          Text(
                            '￦ 280',
                            style: TextStyle(
                              fontSize: 22.0,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'Spoqa_B',
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(
                            height: 5.0,
                          ),
                          Text(
                            'P 0',
                            style: TextStyle(
                              fontSize: 22.0,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'Spoqa_B',
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Divider(
                            height: 1.0,
                            thickness: 1.0,
                            color: PRIMARY_COLOR.withOpacity(0.8),
                          ),
                          SizedBox(
                            height: 5,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              ElevatedButton(
                                onPressed: () {
                                  debugPrint('address copy button clicked.');
                                  showPopup(); //지갑 주소 복사 알림 팝업창
                                  Clipboard.setData(ClipboardData(text: "0x279A6E150A971e76e88719e067d50787dE733E31"));// 지갑 주소 복사
                                },
                                child: Text(
                                  '타라 주소 복사',
                                  style: TextStyle(
                                      fontSize: 14.0,
                                      fontFamily: 'Spoqa_B',
                                      fontWeight: FontWeight.w700,
                                      color: Colors.black),
                                ),
                                style: ElevatedButton.styleFrom(
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(4.0)),
                                    elevation: 0.0,
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 16.0, vertical: 8.0),
                                    backgroundColor: PRIMARY_COLOR),
                              )
                            ],
                          ),
                        ],
                      ),
                    ),
                  ), //회원 아이디 카드 영역

                  Divider(
                    height: 10.0,
                    thickness: 10.0,
                    color: divider,
                  ),

                  //타라코인 목록
                  Container(
                    color: Colors.white,
                    padding: EdgeInsets.only(top:20.0, left: 20.0, right: 20.0),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '타라 코인 목록',
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 22.0,
                                  fontFamily: 'Spoqa_B',
                                  fontWeight: FontWeight.w700),
                            ),
                            IconButton(
                                onPressed: () {
                                  debugPrint(
                                      'coin list page link button clicked.');
                                },
                                icon: Icon(
                                  Icons.arrow_forward_ios,
                                  size: 16.0,
                                  color: Colors.black,
                                ))
                          ],
                        ),
                        SizedBox(
                          height: 20.0,
                        ),
                        Column(
                          children: [
                            Container(
                              height: 128.0 * coinList.length,
                              child: ListView.builder(
                                primary: false,
                                shrinkWrap: true,
                                itemCount: coinList.length,
                                itemBuilder: (context, index){
                                  return Padding(
                                    padding: const EdgeInsets.only(bottom: 20.0),
                                    child: Stack(
                                      fit: StackFit.loose,
                                      children: [
                                        SizedBox(
                                          height: 108.0,
                                          child: Row(
                                            mainAxisAlignment: MainAxisAlignment.end,
                                            children: [
                                              SizedBox(
                                                width: 70.0,
                                                height: 60.0,
                                                child: ElevatedButton(
                                                  onPressed: () {
                                                    debugPrint(
                                                        'transaction history button clicked.');
                                                  },
                                                  child: Text(
                                                    '거래내역',
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 14.0,
                                                        fontFamily: 'Spoqa_B',
                                                        fontWeight: FontWeight.w700),
                                                    softWrap: true,
                                                    textAlign: TextAlign.center,
                                                  ),
                                                  style: ElevatedButton.styleFrom(
                                                    shape: RoundedRectangleBorder(
                                                      borderRadius:
                                                      BorderRadius.circular(4.0),
                                                    ),
                                                    padding: EdgeInsets.symmetric(
                                                        vertical: 8.0, horizontal: 16.0),
                                                    backgroundColor: PRIMARY_COLOR,
                                                    // minimumSize: Size.fromHeight(60.0),
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 10.0,
                                              ),
                                              SizedBox(
                                                width: 70.0,
                                                height: 60.0,
                                                child: ElevatedButton(
                                                  onPressed: () {
                                                    debugPrint('send button clicked.');
                                                  },
                                                  child: Text(
                                                    '보내기',
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 14.0,
                                                        fontFamily: 'Spoqa_B',
                                                        fontWeight: FontWeight.w700),
                                                    softWrap: true,
                                                    textAlign: TextAlign.center,
                                                  ),
                                                  style: ElevatedButton.styleFrom(
                                                    shape: RoundedRectangleBorder(
                                                      borderRadius:
                                                      BorderRadius.circular(4.0),
                                                    ),
                                                    padding: EdgeInsets.symmetric(
                                                        vertical: 8.0, horizontal: 14.0),
                                                    backgroundColor: PRIMARY_COLOR,
                                                    // minimumSize: Size.fromHeight(60.0),
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 10.0,
                                              ),
                                              SizedBox(
                                                width: 70.0,
                                                height: 60.0,
                                                child: ElevatedButton(
                                                  onPressed: () {
                                                    debugPrint(
                                                        'copy address button clicked.');
                                                    showPopup(); //지갑 주소 복사 알림 팝업창
                                                    Clipboard.setData(ClipboardData(text: "0x279A6E150A971e76e88719e067d50787dE733E31"));
                                                  },
                                                  child: Text(
                                                    '주소복사',
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 14.0,
                                                        fontFamily: 'Spoqa_B',
                                                        fontWeight: FontWeight.w700),
                                                    softWrap: true,
                                                    textAlign: TextAlign.center,
                                                  ),
                                                  style: ElevatedButton.styleFrom(
                                                    shape: RoundedRectangleBorder(
                                                      borderRadius:
                                                      BorderRadius.circular(4.0),
                                                    ),
                                                    padding: EdgeInsets.symmetric(
                                                        vertical: 8.0, horizontal: 16.0),
                                                    backgroundColor: PRIMARY_COLOR,
                                                    // minimumSize: Size.fromHeight(60.0),
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 1.0,
                                              ),
                                            ],
                                          ),
                                        ), //거래내역/보내기/주소복사 버튼 영역

                                        AnimatedPositioned(
                                          duration: Duration(milliseconds: 250),
                                          left: coinListIndex != index ? 0 : coinListClicked ? -240 : 0,
                                          width: MediaQuery.of(context).size.width - 40,
                                          // height: 108.0,
                                          child: GestureDetector(
                                            onTap: () {
                                              setState(() {
                                                if(coinListIndex == index){ //해당 리스트를 다시 탭한 상태
                                                  !coinListClicked ? coinListClicked = true : coinListClicked = false;
                                                }else{//이전 탭한 리스트와 다른 리스트를 탭한 상태
                                                  coinListIndex = index; // 클릭된 해당 리스트 index값으로 변경
                                                  coinListClicked = true; // 해당 리스트 활성화
                                                }
                                              });
                                            },
                                            child: Container(
                                              width: MediaQuery.of(context).size.width,
                                              // height: 500.0,
                                              padding: EdgeInsets.symmetric(
                                                  vertical: 10.0, horizontal: 16.0),
                                              decoration: BoxDecoration(
                                                color: Colors.white,
                                                borderRadius: BorderRadius.circular(6.0),
                                                border: Border.all(
                                                  color: border_sub,
                                                  width: 1.0,
                                                ),
                                                boxShadow: [
                                                  BoxShadow(
                                                      blurRadius: 2,
                                                      offset: const Offset(1, 1),
                                                      color:
                                                      Colors.black12.withOpacity(0.28))
                                                ],
                                              ),
                                              child: Row(
                                                mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Row(
                                                    children: [
                                                      Padding(
                                                        padding: EdgeInsets.symmetric(
                                                            vertical: 20.0),
                                                        child: Row(
                                                          children: [
                                                            SvgPicture.asset(
                                                              coinList[index].imgPath.toString(),
                                                              width: 44.0,
                                                              height: 44.0,
                                                            ),
                                                            SizedBox(
                                                              width: 10.0,
                                                            ),
                                                            Text(
                                                              coinList[index].name.toString(),
                                                              style: GoogleFonts.montserrat(
                                                                fontSize: 16.0,
                                                                fontWeight: FontWeight.w700,
                                                                color: Colors.black,
                                                              ),
                                                              //   TextStyle(
                                                              //       color: Colors.black,
                                                              //       fontSize: 16.0,
                                                              //       fontWeight: FontWeight.w700),
                                                              // )
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                    children: [
                                                      Row(
                                                        children: [
                                                          Text(
                                                            coinList[index].price.toString(),
                                                            style: TextStyle(
                                                              fontSize: 16.0,
                                                              fontWeight: FontWeight.w700,
                                                              fontFamily: 'Spoqa_B',
                                                              color: Colors.black,
                                                            ),
                                                            // TextStyle(
                                                            //   fontSize: 16.0,
                                                            //   fontWeight: FontWeight.w700,
                                                            //   color: Colors.black,
                                                            // ),
                                                          ),
                                                          Text(
                                                            coinList[index].unit.toString(),
                                                            style: GoogleFonts.montserrat(
                                                              fontSize: 16.0,
                                                              fontWeight: FontWeight.w700,
                                                              color: Colors.black,
                                                            ),
                                                            // TextStyle(
                                                            //   fontSize: 16.0,
                                                            //   fontWeight: FontWeight.w700,
                                                            //   color: Colors.black,
                                                            // ),
                                                          ),
                                                        ],
                                                      ),
                                                      Text(
                                                        '￦ ${coinList[index].won}',
                                                        style: TextStyle(
                                                          fontSize: 14.0,
                                                          fontWeight: FontWeight.w400,
                                                          fontFamily: 'Spoqa_R',
                                                          color: Gray,
                                                        ),
                                                      )
                                                    ],
                                                  )
                                                ],
                                              ),
                                            ),
                                          ),
                                        ) //코인 리스트 항목
                                      ],
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),

                  Divider(
                    height: 10.0,
                    thickness: 10.0,
                    color: divider,
                  ),

                  //뉴스 영역
                  Container(
                    color: Colors.white,
                    padding: EdgeInsets.all(20.0),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '뉴스',
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 22.0,
                                  fontFamily: 'Spoqa_B',
                                  fontWeight: FontWeight.w700),
                            ),
                            IconButton(
                                onPressed: () {
                                  debugPrint(
                                      'coin list page link button clicked.');
                                },
                                icon: Icon(
                                  Icons.arrow_forward_ios,
                                  size: 16.0,
                                  color: Colors.black,
                                ))
                          ],
                        ),

                        //등록된 뉴스 없는 경우
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 30.0),
                          child: Text(
                            '등록된 뉴스가 없습니다.',
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 18.0,
                                fontFamily: 'Spoqa_B',
                                fontWeight: FontWeight.w700),
                          ),
                        ), //등록된 뉴스 없는 경우
                      ],
                    ),
                  ), //뉴스 영역

                  Divider(
                    height: 10.0,
                    thickness: 10.0,
                    color: divider,
                  ),

                  //공지사항 영역
                  Container(
                    color: Colors.white,
                    padding: EdgeInsets.all(20.0),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              '공지사항',
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 22.0,
                                  fontFamily: 'Spoqa_B',
                                  fontWeight: FontWeight.w700),
                            ),
                            IconButton(
                                onPressed: () {
                                  debugPrint(
                                      'coin list page link button clicked.');
                                },
                                icon: Icon(
                                  Icons.arrow_forward_ios,
                                  size: 16.0,
                                  color: Colors.black,
                                ))
                          ],
                        ),

                        //등록된 공지사항 없는 경우
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 30.0),
                          child: Text(
                            '등록된 공지사항이 없습니다.',
                            style: TextStyle(
                                color: Colors.black,
                                fontSize: 18.0,
                                fontFamily: 'Spoqa_B',
                                fontWeight: FontWeight.w700),
                          ),
                        ), //등록된 공지사항 없는 경우
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ));
  }
}

//공지사항 marquee

// ListView(
//   padding: EdgeInsets.only(top: 50.0),
//   children: [
//     _buildMarquee(),
//     _buildComplexMarquee(),
//   ].map(_wrapWithStuff).toList(),
// ),

Widget _buildMarquee() {
  return Marquee(
    text: 'GeeksforGeeks.org was created'
        ' with a goal in mind to provide well written,'
        ' well thought and well explained solutions for'
        ' selected questions. The core team of five super geeks constituting'
        ' of technology lovers and computer science enthusiasts'
        ' have been constantly working in this direction ',
  );
}

Widget _buildComplexMarquee() {
  return Marquee(
    text: 'GeeksforGeeks is a one-stop destination for programmers.',
    style: TextStyle(fontWeight: FontWeight.bold),
    scrollAxis: Axis.horizontal,
    crossAxisAlignment: CrossAxisAlignment.start,
    blankSpace: 20.0,
    velocity: 100.0,
    //speed
    pauseAfterRound: Duration(seconds: 1),
    showFadingOnlyWhenScrolling: true,
    fadingEdgeStartFraction: 0.1,
    fadingEdgeEndFraction: 0.1,
    numberOfRounds: 3,
    startPadding: 10.0,
    accelerationDuration: Duration(seconds: 1),
    accelerationCurve: Curves.linear,
    decelerationDuration: Duration(milliseconds: 500),
    decelerationCurve: Curves.easeOut,
  );
}
