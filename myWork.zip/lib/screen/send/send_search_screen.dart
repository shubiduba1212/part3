import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:wallet_template/const/colors.dart';

class SendSearchScreen extends StatefulWidget {
  const SendSearchScreen({Key? key}) : super(key: key);

  @override
  State<SendSearchScreen> createState() => _SendSearchScreenState();
}

class _SendSearchScreenState extends State<SendSearchScreen> {
  final walletAddressSame = TextEditingController();
  final walletAddressDiff = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          '보내기',
          style: TextStyle(
              color: Colors.black, fontSize: 18.0, fontWeight: FontWeight.w700),
        ),
        centerTitle: true,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, 'refresh');
            // Navigator.of(context).pop();
          },
          icon: Icon(
            Icons.arrow_back_ios_new_outlined,
            color: Colors.black,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.popAndPushNamed(context, '/home_screen');
            },
            icon: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: Icon(
                Icons.close,
                size: 24.0,
                color: Colors.black,
              ),
            ),
          )
        ],
        elevation: 0.2,
      ),
      body: SafeArea(
        child: Container(
          width: double.infinity,
          height: double.infinity,
          padding: EdgeInsets.only(left: 20.0, right: 20.0, bottom: 20.0),
          color: Colors.white,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                    // width: MediaQuery.of(context).size.width - 40,
                    width: double.infinity,
                    margin: EdgeInsets.only(top: 20.0),
                    padding: EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      border: Border.all(width: 1.0, color: border),
                      borderRadius: BorderRadius.circular(6.0),
                      color: Colors.white,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '코인명',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Dark_gray),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          'Glow Coin (GLOW)',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w700,
                              color: Colors.black),
                        ), //코인명
                        SizedBox(
                          height: 14.0,
                        ),
                        Divider(
                          height: 1.0,
                          thickness: 1.0,
                          color: border_sub,
                        ),
                        SizedBox(
                          height: 14.0,
                        ),
                        Text(
                          '아이디',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Dark_gray),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          'tarakim',
                          style: GoogleFonts.montserrat(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w700,
                            color: Colors.black,
                          ),
                        ), //잔액
                        SizedBox(
                          height: 14.0,
                        ),
                        Divider(
                          height: 1.0,
                          thickness: 1.0,
                          color: border_sub,
                        ),
                        SizedBox(
                          height: 14.0,
                        ),
                        Text(
                          '주소',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Dark_gray),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          '0x896bc959615bc063a1b5ef3c5859434245cc232a',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w700,
                              color: Colors.black),
                        ), //잠금 수량
                        SizedBox(
                          height: 14.0,
                        ),
                        Divider(
                          height: 1.0,
                          thickness: 1.0,
                          color: border_sub,
                        ),
                        SizedBox(
                          height: 14.0,
                        ),
                        Text(
                          '전송 가능한 수량',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Dark_gray),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          '99.945485 TARA',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w700,
                              color: Colors.black),
                        ), //잠금 수량
                        SizedBox(
                          height: 14.0,
                        ),
                        Divider(
                          height: 1.0,
                          thickness: 1.0,
                          color: border_sub,
                        ),
                        SizedBox(
                          height: 14.0,
                        ),
                        Text(
                          '보낸 수량',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Dark_gray),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          '0.001 TARA',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w700,
                              color: Colors.black),
                        ), //잠금 수량
                        SizedBox(
                          height: 14.0,
                        ),
                        Divider(
                          height: 1.0,
                          thickness: 1.0,
                          color: border_sub,
                        ),
                        SizedBox(
                          height: 14.0,
                        ),
                        Text(
                          '가스(수수료)',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Dark_gray),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          '1.2 TARA',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w700,
                              color: Colors.black),
                        ), //가스(수수료)
                        SizedBox(
                          height: 14.0,
                        ),
                        Divider(
                          height: 1.0,
                          thickness: 1.0,
                          color: border_sub,
                        ),
                        SizedBox(
                          height: 14.0,
                        ),
                        Text(
                          '남은 수량',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Dark_gray),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          '99.000000 TARA',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w700,
                              color: Colors.black),
                        ),
                      ],
                    )), //코인명/잔액/잠금수량/가스(수수료)/전송가능한 수량
                SizedBox(
                  height: 20.0,
                ),
                Text(
                  '받는 사람(같은 지갑)',
                  style: TextStyle(
                      fontSize: 16.0,
                      fontWeight: FontWeight.w700,
                      color: Colors.black),
                ),
                SizedBox(
                  height: 10.0,
                ),
                Container(
                  // padding:
                  //     EdgeInsets.symmetric(horizontal: 16.0),
                  width: MediaQuery.of(context).size.width - 40.0,
                  // width: double.infinity,
                  height: 40.0,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(width: 1.0, color: border),
                    borderRadius: BorderRadius.circular(6.0),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: walletAddressSame,
                          decoration: InputDecoration(
                            enabledBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(width: 0, color: Colors.transparent),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(width: 0, color: Colors.transparent),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            focusedErrorBorder: OutlineInputBorder(
                              borderSide:
                                  BorderSide(width: 0, color: Colors.transparent),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            hintText: '아이디 또는 주소를 입력해 주세요.',
                            hintStyle: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Dark_gray,
                            ),
                            contentPadding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                          ),
                          textAlignVertical: TextAlignVertical.center,
                        ),
                      ),
                      IconButton(
                          onPressed: () {}, icon: Icon(Icons.search_outlined))
                    ],
                  ),
                ), //받은 사람(같은 지갑) 입력칸
                SizedBox(
                  height: 20.0,
                ),
                //받은 사람(다른 지갑)
                Text(
                  '받는 사람(다른 지갑)',
                  style: TextStyle(
                      fontSize: 16.0,
                      fontWeight: FontWeight.w700,
                      color: Colors.black),
                ),
                SizedBox(
                  height: 10.0,
                ),
                Container(
                  width: MediaQuery.of(context).size.width - 40.0,
                  // width: double.infinity,
                  height: 40.0,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(width: 1.0, color: border),
                    borderRadius: BorderRadius.circular(6.0),
                  ),
                  child:
                      TextField(
                        controller: walletAddressDiff,
                        decoration: InputDecoration(
                          enabledBorder: OutlineInputBorder(
                            borderSide:
                            BorderSide(width: 0, color: Colors.transparent),
                            borderRadius: BorderRadius.circular(6.0),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide:
                            BorderSide(width: 0, color: Colors.transparent),
                            borderRadius: BorderRadius.circular(6.0),
                          ),
                          focusedErrorBorder: OutlineInputBorder(
                            borderSide:
                            BorderSide(width: 0, color: Colors.transparent),
                            borderRadius: BorderRadius.circular(6.0),
                          ),
                          hintText: '주소를 입력해 주세요.',
                          hintStyle: TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w500,
                            color: Dark_gray,
                          ),
                          contentPadding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                        ),
                      ),
                ),//받은 사람(다른 지갑)
                SizedBox(
                  height: 20.0,
                ),
                //받은 사람(다른 지갑)
                Text(
                  '참고사항',
                  style: TextStyle(
                      fontSize: 16.0,
                      fontWeight: FontWeight.w700,
                      color: Colors.black),
                ),
                SizedBox(
                  height: 10.0,
                ),
                Divider(
                  height: 1.0,
                  thickness: 1.0,
                  color: border_sub,
                ),
                SizedBox(
                  height: 10.0,
                ),
                Text(
                  '암호화폐의 특성상 송금 요청이 완료된 후에는 취소가 불가능합니다.',
                  style: TextStyle(
                      fontSize: 16.0,
                      fontWeight: FontWeight.w700,
                      color: Red),
                ),
                Text(
                  '주소와 수량을 확인해주세요.',
                  style: TextStyle(
                      fontSize: 16.0,
                      fontWeight: FontWeight.w700,
                      color: Red),
                ),
                SizedBox(
                  height: 50.0,
                ),
                ElevatedButton(
                  //다음 버튼
                  onPressed: () {
                    debugPrint('Next button clicked.');
                    Navigator.of(context).pushNamed('/send_info_screen');
                  },
                  child: Text(
                    '다음',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16.0,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: PRIMARY_COLOR,
                      minimumSize: const Size.fromHeight(50.0),
                      elevation: 0,
                      shadowColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4.0),
                      )),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
