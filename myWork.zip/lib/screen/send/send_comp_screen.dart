import 'package:google_fonts/google_fonts.dart';
import 'package:wallet_template/const/colors.dart';
import 'package:flutter/material.dart';

class SendCompleteScreen extends StatelessWidget {
  const SendCompleteScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          '보내기',
          style: TextStyle(
              color: Colors.black, fontSize: 18.0, fontWeight: FontWeight.w700),
        ),
        automaticallyImplyLeading: false,
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: () {
              Navigator.popAndPushNamed(context, '/home_screen');
            },
            icon: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: Icon(
                Icons.close,
                size: 24.0,
                color: Colors.black,
              ),
            ),
          )
        ],
        elevation: 0.2,
      ),
      body: SafeArea(
          child: Container(
            width: double.infinity,
            height: double.infinity,
            padding: EdgeInsets.only(left: 20.0, right: 20.0, bottom: 20.0),
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.only(top: 20.0),
                  alignment: Alignment.center,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text('전송이 ', style: TextStyle(color: Colors.black, fontSize: 22.0, fontWeight: FontWeight.w700),),
                      Text('완료 되었습니다.', style: TextStyle(color: Red, fontSize: 22.0, fontWeight: FontWeight.w700),),
                    ],
                  ),
                ),
                SizedBox(
                  height: 20.0,
                ),
                Text(
                  '전송 내역',
                  style: TextStyle(
                      fontSize: 16.0,
                      fontWeight: FontWeight.w700,
                      color: Colors.black),
                ),
                Container(
                    margin: EdgeInsets.only(top: 10.0),
                    // width: MediaQuery.of(context).size.width - 40,
                    width: double.infinity,
                    padding: EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      border: Border.all(width: 1.0, color: border),
                      borderRadius: BorderRadius.circular(6.0),
                      color: Colors.white,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '주소',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Dark_gray),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          '0x896bc959615bc063a1b5ef3c5859434245cc232a',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w700,
                              color: Colors.black),
                        ),
                        SizedBox(
                          height: 14.0,
                        ),
                        Divider(
                          height: 1.0,
                          thickness: 1.0,
                          color: border_sub,
                        ),
                        SizedBox(
                          height: 14.0,
                        ),
                        Text(
                          '가스(수수료)',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Dark_gray),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          '1.2 TARA',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w700,
                              color: Colors.black),
                        ), //가스(수수료)//잠금 수량
                        SizedBox(
                          height: 14.0,
                        ),
                        Divider(
                          height: 1.0,
                          thickness: 1.0,
                          color: border_sub,
                        ),
                        SizedBox(
                          height: 14.0,
                        ),
                        Text(
                          '보낸 수량',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Dark_gray),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          '1.000000 TARA',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w700,
                              color: Colors.black),
                        ),
                        SizedBox(
                          height: 14.0,
                        ),
                        Divider(
                          height: 1.0,
                          thickness: 1.0,
                          color: border_sub,
                        ),
                        SizedBox(
                          height: 14.0,
                        ),
                        Text(
                          '보내는 사람',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Dark_gray),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          'tarakim',
                          style: GoogleFonts.montserrat(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w700,
                            color: Colors.black,
                          ),
                        ),//보내는 사람
                        SizedBox(
                          height: 14.0,
                        ),
                        Divider(
                          height: 1.0,
                          thickness: 1.0,
                          color: border_sub,
                        ),
                        SizedBox(
                          height: 14.0,
                        ),
                        Text(
                          '받는 사람',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Dark_gray),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          'Admin',
                          style: GoogleFonts.montserrat(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w700,
                            color: Colors.black,
                          ),
                        ),//받는 사람
                      ],
                    )),
                Expanded(child: Container(child: SizedBox(height: 20.0,),)),
                // Expanded(child: Container(child: ,))
                //확인 버튼
                ElevatedButton(
                  onPressed: () {
                    debugPrint('Confirm button clicked.');
                    Navigator.popAndPushNamed(context, '/home_screen');
                  },
                  child: Text(
                    '확인',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16.0,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: PRIMARY_COLOR,
                      minimumSize: const Size.fromHeight(50.0),
                      elevation: 0,
                      shadowColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4.0),
                      )),
                ),
              ],
            ),
          )),
    );
  }
}
