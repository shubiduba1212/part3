import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:wallet_template/const/colors.dart';

class SendScreen extends StatefulWidget {
  const SendScreen({Key? key}) : super(key: key);

  @override
  State<SendScreen> createState() => _SendScreenState();
}

class _SendScreenState extends State<SendScreen> {
  int selectedIndex = 1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(

        title: Text(
          '보내기',
          style: TextStyle(
              color: Colors.black, fontSize: 18.0, fontWeight: FontWeight.w700),
        ),
        centerTitle: true,
        leading: IconButton(
          onPressed: () {
            // Navigator.of(context).pop();
            Navigator.popAndPushNamed(context, '/home_screen');
          },
          icon: Icon(
            Icons.arrow_back_ios_new_outlined,
            color: Colors.black,
          ),
        ),
        // leadingWidth: 10.0,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: (value) => setState(() {
          selectedIndex = value;
          if (value == 0) {
            Navigator.popAndPushNamed(context, '/home_screen');
          } else if (value == 1) {
            Navigator.popAndPushNamed(context, '/send_screen');
          } else if (value == 2) {
            Navigator.popAndPushNamed(context, '/exchange_screen');
          } else if (value == 3) {
            Navigator.popAndPushNamed(context, '/mypage_screen');
          }
        }),
        destinations: [
          NavigationDestination(
            icon: Icon(Icons.account_balance_wallet_outlined),
            label: '지갑',
          ),
          NavigationDestination(
            icon: Icon(Icons.send_rounded),
            label: '보내기',
          ),
          NavigationDestination(
            icon: Icon(Icons.currency_exchange_outlined),
            label: '교환',
          ),
          NavigationDestination(
            icon: Icon(Icons.person),
            label: '나의정보',
          ),
        ],
        animationDuration: const Duration(milliseconds: 500),
      ),
      body: SafeArea(
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 20.0),
          decoration: BoxDecoration(
            color: Colors.white,
          ),
          child: Column(
            children: [
              SizedBox(
                height: 30.0,
              ),
              Text(
                '타라(TARA)기반 코인 보내기',
                style: TextStyle(
                  fontSize: 22.0,
                  fontWeight: FontWeight.w700,
                  color: Colors.black,
                ),
              ),
              SizedBox(
                height: 30.0,
              ),
              Row(
                children: [
                  GestureDetector(
                    onTap: () {
                      Navigator.of(context).pushNamed('/send_coin_screen');
                    },
                    child: Container(
                      width:
                          ((MediaQuery.of(context).size.width - 40) / 2) - 10,
                      clipBehavior: Clip.hardEdge,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10.0),
                        // border: Border.all(
                        //   color: border_sub,
                        //   width: 1.0,
                        // ),
                        boxShadow: [
                          BoxShadow(
                              blurRadius: 2,
                              offset: const Offset(1, 1),
                              color: Colors.black12.withOpacity(0.2))
                        ],
                      ),
                      child: Column(
                        children: [
                          Container(
                            width:double.infinity,
                            // color:Colors.white,
                            padding: EdgeInsets.only(top: 20.0),
                            child: SvgPicture.asset(
                              'assets/img/svg/icon_send.svg',
                              width: 160.0,
                              height: 160.0,
                            ),
                            decoration:BoxDecoration(
                              border: Border.all(
                                  color: border_sub,
                                  width: 1.0,
                              ),
                              borderRadius: BorderRadius.only(topLeft: Radius.circular(10.0),topRight: Radius.circular(10.0),)
                            ),
                          ),
                          Container(
                            alignment: Alignment.center,
                            width:double.infinity,
                            //((MediaQuery.of(context).size.width - 40) / 2) - 20
                            height: 52.0,
                            decoration: BoxDecoration(
                              color: PRIMARY_COLOR,
                            ),
                            child: Text(
                              '보내기',
                              style: TextStyle(
                                fontSize: 18.0,
                                fontWeight: FontWeight.w700,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 20.0,
                  ),
                  GestureDetector(
                    onTap: () {
                      Navigator.of(context).pushNamed('/wallet_address');
                    },
                    child: Container(
                      width:
                          ((MediaQuery.of(context).size.width - 40) / 2) - 10,
                      clipBehavior: Clip.antiAliasWithSaveLayer,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(10.0),
                        // border: Border.all(
                        //   color: border_sub,
                        //   width: 1.0,
                        // ),
                        boxShadow: [
                          BoxShadow(
                              blurRadius: 2,
                              offset: const Offset(1, 1),
                              color: Colors.black12.withOpacity(0.28))
                        ],
                      ),
                      child: Column(
                        children: [
                          Container(
                            width:double.infinity,
                            // color:Colors.white,
                            padding: EdgeInsets.only(top: 20.0),
                            child: SvgPicture.asset(
                              'assets/img/svg/icon_wallet_addr.svg',
                              width: 160.0,
                              height: 160.0,
                            ),
                            decoration:BoxDecoration(
                                border: Border.all(
                                  color: border_sub,
                                  width: 1.0,
                                ),
                                borderRadius: BorderRadius.only(topLeft: Radius.circular(10.0),topRight: Radius.circular(10.0),)
                            ),
                          ),
                          Container(
                            alignment: Alignment.center,
                            width: double.infinity,
                            height: 52.0,
                            decoration: BoxDecoration(
                              color: PRIMARY_COLOR,
                            ),
                            child: Text(
                              '타라 지갑 주소',
                              style: TextStyle(
                                fontSize: 18.0,
                                fontWeight: FontWeight.w700,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
