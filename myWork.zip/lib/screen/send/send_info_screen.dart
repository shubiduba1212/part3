import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:wallet_template/const/colors.dart';

class SendInfoScreen extends StatelessWidget {
  const SendInfoScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          '보내기',
          style: TextStyle(
              color: Colors.black, fontSize: 18.0, fontWeight: FontWeight.w700),
        ),
        centerTitle: true,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          icon: Icon(
            Icons.arrow_back_ios_new_outlined,
            color: Colors.black,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.popAndPushNamed(context, '/home_screen');
            },
            icon: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: Icon(
                Icons.close,
                size: 24.0,
                color: Colors.black,
              ),
            ),
          )
        ],
        elevation: 0.2,
      ),
      body: SafeArea(
          child: Container(
        width: double.infinity,
        height: double.infinity,
        padding: EdgeInsets.only(left: 20.0, right: 20.0, bottom: 20.0),
        color: Colors.white,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.only(top: 20.0),
                alignment: Alignment.center,
                child: Column(
                  children: [
                    Text(
                      '보내는 사람',
                      style: TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w700,
                        color: Colors.black,
                        fontFamily: 'Spoqa_B',
                      ),
                    ),
                    SizedBox(
                      height: 10.0,
                    ),
                    Container(
                        width: double.infinity,
                        padding: EdgeInsets.symmetric(
                            vertical: 14.0, horizontal: 10.0),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(6.0),
                            color: Light_gray),
                        child: Text(
                          '0x896bc959615bc063a1b5ef3c5859434245cc232a',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w400,
                              color: Colors.black),
                        )), //보내는 사람 주소
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 20.0),
                        child: Icon(
                      Icons.arrow_downward_outlined,
                      size: 16.0,
                      color: Red,
                    )),
                    Text(
                      '받는 사람',
                      style: TextStyle(
                        fontSize: 16.0,
                        fontWeight: FontWeight.w700,
                        color: Colors.black,
                        fontFamily: 'Spoqa_B',
                      ),
                    ),
                    SizedBox(
                      height: 10.0,
                    ),
                    Container(
                        width: double.infinity,
                        padding: EdgeInsets.symmetric(
                            vertical: 14.0, horizontal: 10.0),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(6.0),
                            color: Light_gray),
                        child: Text(
                          '0x896bc959615bc063a1b5ef3c5859434245cc232a',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w400,
                              color: Colors.black),
                        )), //받는 사람 주소
                  ],
                ),
              ),
              SizedBox(
                height: 20.0,
              ),
              Text(
                '보내는 정보',
                style: TextStyle(
                    fontSize: 16.0,
                    fontWeight: FontWeight.w700,
                    color: Colors.black),
              ),
              Container(
                  margin: EdgeInsets.only(top: 10.0),
                  // width: MediaQuery.of(context).size.width - 40,
                  width: double.infinity,
                  padding: EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                    border: Border.all(width: 1.0, color: border),
                    borderRadius: BorderRadius.circular(6.0),
                    color: Colors.white,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '전송 가능한 수량',
                        style: TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w500,
                            color: Dark_gray),
                      ),
                      SizedBox(
                        height: 10.0,
                      ),
                      Text(
                        '99.945485 TARA',
                        style: TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w700,
                            color: Colors.black),
                      ),
                      SizedBox(
                        height: 14.0,
                      ),
                      Divider(
                        height: 1.0,
                        thickness: 1.0,
                        color: border_sub,
                      ),
                      SizedBox(
                        height: 14.0,
                      ),
                      Text(
                        '가스(수수료)',
                        style: TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w500,
                            color: Dark_gray),
                      ),
                      SizedBox(
                        height: 10.0,
                      ),
                      Text(
                        '1.2 TARA',
                        style: TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w700,
                            color: Colors.black),
                      ), //가스(수수료)//잠금 수량
                      SizedBox(
                        height: 14.0,
                      ),
                      Divider(
                        height: 1.0,
                        thickness: 1.0,
                        color: border_sub,
                      ),
                      SizedBox(
                        height: 14.0,
                      ),
                      Text(
                        '남은 수량',
                        style: TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w500,
                            color: Dark_gray),
                      ),
                      SizedBox(
                        height: 10.0,
                      ),
                      Text(
                        '99.000000 TARA',
                        style: TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w700,
                            color: Colors.black),
                      ),
                      SizedBox(
                        height: 14.0,
                      ),
                      Divider(
                        height: 1.0,
                        thickness: 1.0,
                        color: border_sub,
                      ),
                      SizedBox(
                        height: 14.0,
                      ),
                      Text(
                        '보내는 사람',
                        style: TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w500,
                            color: Dark_gray),
                      ),
                      SizedBox(
                        height: 10.0,
                      ),
                      Text(
                        'tarakim',
                        style: GoogleFonts.montserrat(
                          fontSize: 14.0,
                          fontWeight: FontWeight.w700,
                          color: Colors.black,
                        ),
                      ),//보내는 사람
                      SizedBox(
                        height: 14.0,
                      ),
                      Divider(
                        height: 1.0,
                        thickness: 1.0,
                        color: border_sub,
                      ),
                      SizedBox(
                        height: 14.0,
                      ),
                      Text(
                        '받는 사람',
                        style: TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w500,
                            color: Dark_gray),
                      ),
                      SizedBox(
                        height: 10.0,
                      ),
                      Text(
                        'Admin',
                        style: GoogleFonts.montserrat(
                          fontSize: 14.0,
                          fontWeight: FontWeight.w700,
                          color: Colors.black,
                        ),
                      ),//받는 사람
                    ],
                  )), //코인명/잔액/잠금수량/가스(수수료)/전송가능한 수량
              SizedBox(
                height: 20.0,
              ),
              Container(
                alignment: Alignment.center,
                child: Text(
                  '999,999,999.000000 TARA',
                  style: TextStyle(
                      color: Red, fontSize: 18.0, fontWeight: FontWeight.w700),
                ),
              ),
              Container(
                alignment: Alignment.center,
                child: Text(
                  '보내시겠습니까?',
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 18.0,
                      fontWeight: FontWeight.w700),
                ),
              ),
              SizedBox(
                height: 50.0,
              ),

              //취소, 다음 버튼
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: ((MediaQuery.of(context).size.width - 40) / 2) - 10,
                    child: ElevatedButton(
                    onPressed: () {
                      debugPrint('Cancel button clicked.');
                      Navigator.popAndPushNamed(context, '/send_screen');
                    },
                    child: Text(
                      '취소',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 16.0,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Light_gray,
                        minimumSize: const Size.fromHeight(50.0),
                        elevation: 0,
                        shadowColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(4.0),
                        )),
                ),
                  ),
                  SizedBox(
                    width: ((MediaQuery.of(context).size.width - 40) / 2) - 10,
                    child: ElevatedButton(
                      onPressed: () {
                        debugPrint('Next button clicked.');
                        Navigator.of(context).pushNamed('/send_pin_screen');
                      },
                      child: Text(
                        '다음',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16.0,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: PRIMARY_COLOR,
                          minimumSize: const Size.fromHeight(50.0),
                          elevation: 0,
                          shadowColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(4.0),
                          )),
                    ),
                  ),
                ]
              ),
            ],
          ),
        ),
      )),
    );
  }
}
