import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:wallet_template/const/colors.dart';

class SendPinScreen extends StatefulWidget {
  const SendPinScreen({Key? key}) : super(key: key);

  @override
  State<SendPinScreen> createState() => _SendPinScreenState();
}

class _SendPinScreenState extends State<SendPinScreen> {
  int sendKeyIndex = 0;
  String sendKeyEntered = '';

  void showPopup(BuildContext context) {
    //지갑주소 복사 알림창
    showDialog(
        context: context,
        builder: (context) {
          return Dialog(
            child: Container(
              width: MediaQuery.of(context).size.width * 0.7,
              height: 150,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10), color: Colors.white),
              padding: EdgeInsets.all(20.0),
              child: Center(
                child: Column(
                  children: [
                    Expanded(
                      child: Text(
                        '전송키가 올바르지 않습니다. 다시 입력해주세요.',
                        style: TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w500,
                            color: Colors.black),
                      ),
                    ),
                    SizedBox(
                      height: 20.0,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          sendKeyEntered = '';
                          sendKeyIndex = 0;
                        });
                        debugPrint('입력된 전송키 : ${sendKeyEntered}');
                        Navigator.pop(context);
                      },
                      child: Text(
                        '확인',
                        style: TextStyle(
                            fontSize: 16.0,
                            fontWeight: FontWeight.w600,
                            color: Colors.white),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: PRIMARY_COLOR,
                        minimumSize: const Size.fromHeight(50.0),
                        elevation: 0,
                        shadowColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          '보내기',
          style: TextStyle(
              color: Colors.black, fontSize: 18.0, fontWeight: FontWeight.w700),
        ),
        centerTitle: true,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          icon: Icon(
            Icons.arrow_back_ios_new_outlined,
            color: Colors.black,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.popAndPushNamed(context, '/home_screen');
            },
            icon: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: Icon(
                Icons.close,
                size: 24.0,
                color: Colors.black,
              ),
            ),
          )
        ],
        // elevation: 0.2,
      ),
      body: SafeArea(
        child: Container(
          padding: EdgeInsets.all(20.0),
          alignment: Alignment.center,
          color: Colors.white,
          child: Column(
            children: [
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      '전송키 6자리를',
                      style: TextStyle(
                          fontSize: 22.0,
                          fontWeight: FontWeight.w700,
                          color: Colors.black),
                    ),
                    Text(
                      '입력하세요.',
                      style: TextStyle(
                          fontSize: 22.0,
                          fontWeight: FontWeight.w700,
                          color: Colors.black),
                    ),
                    SizedBox(height: 20.0,),
                    Text(
                      '입력 후 취소는 불가능하며,',
                      style: TextStyle(
                          fontSize: 14.0,
                          fontWeight: FontWeight.w500,
                          color: Red),
                    ),
                    Text(
                      '신중하게 입력해주시기 바랍니다.',
                      style: TextStyle(
                          fontSize: 14.0,
                          fontWeight: FontWeight.w500,
                          color: Red),
                    ),
                    SizedBox(height: 60.0,),
                    SizedBox(
                      width: 258.0,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                              for(num i=0; i<sendKeyIndex; i++)//입력된 전송키 표시 영역
                                Container(
                                  width: 38.0,
                                  height: 38.0,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(6.0),
                                      color: PRIMARY_COLOR
                                  ),
                                ),
                              for(num i=0; i<6-sendKeyIndex; i++)//미입력된 전송키 표시 영역
                                Container(
                                  width: 38.0,
                                  height: 38.0,
                                  decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(6.0),
                                      color: Light_gray
                                  ),
                                )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                children: [
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () {
                          debugPrint('1 button clicked.');
                          setState(() {
                            sendKeyIndex++;
                            debugPrint('입력전 전송키 : '+sendKeyEntered);
                            if(sendKeyIndex == 6){
                              sendKeyEntered += '1';
                              debugPrint('전송키 6자리를 모두 입력하셨습니다. ${sendKeyEntered}');
                              sendKeyIndex == 6 && sendKeyEntered == '123456' ? Navigator.of(context).pushNamed('/send_comp_screen') : showPopup(context);
                            }else{
                              sendKeyEntered += '1';
                              debugPrint('전송키 6자리를 입력해주세요.');
                              debugPrint('현재 입력된 전송키 : '+sendKeyEntered);
                            }
                          });
                        },
                        child: Container(
                          width:
                          (MediaQuery.of(context).size.width - 40.0) / 3,
                          //  MediaQuery.of(context).size.width
                          height: 78.0,
                          alignment: Alignment.center,
                          color: Colors.white,
                          child: Text(
                            '1',
                            style: TextStyle(
                                fontSize: 26.0,
                                fontWeight: FontWeight.w700,
                                color: Colors.black),
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          debugPrint('2 button clicked.');
                          setState(() {
                            sendKeyIndex++;
                            debugPrint('입력전 전송키 : '+sendKeyEntered);
                            if(sendKeyIndex == 6){
                              debugPrint('전송키 6자리를 모두 입력하셨습니다.');
                              sendKeyEntered += '2';
                              debugPrint('전송키 6자리를 모두 입력하셨습니다. ${sendKeyEntered}');
                              sendKeyIndex == 6 && sendKeyEntered == '123456' ? Navigator.of(context).pushNamed('/send_comp_screen') : showPopup(context);
                            }else{
                              sendKeyEntered += '2';
                              debugPrint('전송키 6자리를 입력해주세요.');
                              debugPrint('현재 입력된 전송키 : '+sendKeyEntered);
                            }
                          });
                        },
                        child: Container(
                          width:
                          (MediaQuery.of(context).size.width - 40.0) / 3,
                          //  MediaQuery.of(context).size.width
                          height: 78.0,
                          alignment: Alignment.center,
                          color: Colors.white,
                          child: Text(
                            '2',
                            style: TextStyle(
                                fontSize: 26.0,
                                fontWeight: FontWeight.w700,
                                color: Colors.black),
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          debugPrint('3 button clicked.');
                          setState(() {
                            sendKeyIndex++;
                            debugPrint('입력전 : '+sendKeyEntered);
                            if(sendKeyIndex == 6){
                              debugPrint('전송키 6자리를 모두 입력하셨습니다.');
                              sendKeyEntered += '3';
                              debugPrint('전송키 6자리를 모두 입력하셨습니다. ${sendKeyEntered}');
                              sendKeyIndex == 6 && sendKeyEntered == '123456' ? Navigator.of(context).pushNamed('/send_comp_screen') : showPopup(context);
                            }else{
                              sendKeyEntered += '3';
                              debugPrint('전송키 6자리를 입력해주세요.');
                              debugPrint('현재 입력된 전송키 : '+sendKeyEntered);
                            }
                          });
                        },
                        child: Container(
                          width:
                          (MediaQuery.of(context).size.width - 40.0) / 3,
                          //  MediaQuery.of(context).size.width
                          height: 78.0,
                          alignment: Alignment.center,
                          color: Colors.white,
                          child: Text(
                            '3',
                            style: TextStyle(
                                fontSize: 26.0,
                                fontWeight: FontWeight.w700,
                                color: Colors.black),
                          ),
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () {
                          debugPrint('4 button clicked.');
                          setState(() {
                            sendKeyIndex++;
                            debugPrint('입력전 전송키 : '+sendKeyEntered);
                            if(sendKeyIndex == 6){
                              debugPrint('전송키 6자리를 모두 입력하셨습니다.');
                              sendKeyEntered += '4';
                              debugPrint('전송키 6자리를 모두 입력하셨습니다. ${sendKeyEntered}');
                              sendKeyIndex == 6 && sendKeyEntered == '123456' ? Navigator.of(context).pushNamed('/send_comp_screen') : showPopup(context);
                            }else{
                              sendKeyEntered += '4';
                              debugPrint('전송키 6자리를 입력해주세요.');
                              debugPrint('현재 입력된 전송키 : '+sendKeyEntered);
                            }
                          });
                        },
                        child: Container(
                          width:
                          (MediaQuery.of(context).size.width - 40.0) / 3,
                          //  MediaQuery.of(context).size.width
                          height: 78.0,
                          alignment: Alignment.center,
                          color: Colors.white,
                          child: Text(
                            '4',
                            style: TextStyle(
                                fontSize: 26.0,
                                fontWeight: FontWeight.w700,
                                color: Colors.black),
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          debugPrint('5 button clicked.');
                          setState(() {
                            sendKeyIndex++;
                            debugPrint('입력전 전송키 : '+sendKeyEntered);
                            if(sendKeyIndex == 6){
                              debugPrint('전송키 6자리를 모두 입력하셨습니다.');
                              sendKeyEntered += '5';
                              debugPrint('전송키 6자리를 모두 입력하셨습니다. ${sendKeyEntered}');
                              sendKeyIndex == 6 && sendKeyEntered == '123456' ? Navigator.of(context).pushNamed('/send_comp_screen') : showPopup(context);
                            }else{
                              sendKeyEntered += '5';
                              debugPrint('전송키 6자리를 입력해주세요.');
                              debugPrint('현재 입력된 전송키 : '+sendKeyEntered);
                            }
                          });
                        },
                        child: Container(
                          width:
                          (MediaQuery.of(context).size.width - 40.0) / 3,
                          //  MediaQuery.of(context).size.width
                          height: 78.0,
                          alignment: Alignment.center,
                          color: Colors.white,
                          child: Text(
                            '5',
                            style: TextStyle(
                                fontSize: 26.0,
                                fontWeight: FontWeight.w700,
                                color: Colors.black),
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          debugPrint('6 button clicked.');
                          setState(() {
                            sendKeyIndex++;
                            if(sendKeyIndex == 6){
                              debugPrint('전송키 6자리를 모두 입력하셨습니다.');
                              sendKeyEntered += '6';
                              debugPrint('전송키 6자리를 모두 입력하셨습니다. ${sendKeyEntered}');
                              sendKeyIndex == 6 && sendKeyEntered == '123456' ? Navigator.of(context).pushNamed('/send_comp_screen') : showPopup(context);
                            }else{
                              sendKeyEntered += '6';
                              debugPrint('전송키 6자리를 입력해주세요.');
                            }
                          });
                        },
                        child: Container(
                          width:
                          (MediaQuery.of(context).size.width - 40.0) / 3,
                          //  MediaQuery.of(context).size.width
                          height: 78.0,
                          alignment: Alignment.center,
                          color: Colors.white,
                          child: Text(
                            '6',
                            style: TextStyle(
                                fontSize: 26.0,
                                fontWeight: FontWeight.w700,
                                color: Colors.black),
                          ),
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () {
                          debugPrint('7 button clicked.');
                          setState(() {
                            sendKeyIndex++;
                            debugPrint('입력전 전송키 : '+sendKeyEntered);

                            if(sendKeyIndex == 6){
                              debugPrint('전송키 6자리를 모두 입력하셨습니다.');
                              sendKeyEntered += '7';
                              debugPrint('전송키 6자리를 모두 입력하셨습니다. ${sendKeyEntered}');
                              sendKeyIndex == 6 && sendKeyEntered == '123456' ? Navigator.of(context).pushNamed('/send_comp_screen') : showPopup(context);
                            }else{
                              sendKeyEntered += '7';
                              debugPrint('전송키 6자리를 입력해주세요.');
                              debugPrint('현재 입력된 전송키 : '+sendKeyEntered);
                            }
                          });
                        },
                        child: Container(
                          width:
                          (MediaQuery.of(context).size.width - 40.0) / 3,
                          //  MediaQuery.of(context).size.width
                          height: 78.0,
                          alignment: Alignment.center,
                          color: Colors.white,
                          child: Text(
                            '7',
                            style: TextStyle(
                                fontSize: 26.0,
                                fontWeight: FontWeight.w700,
                                color: Colors.black),
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          debugPrint('8 button clicked.');
                          setState(() {
                            sendKeyIndex++;
                            debugPrint('입력전 전송키 : '+sendKeyEntered);
                            if(sendKeyIndex == 6){
                              debugPrint('전송키 6자리를 모두 입력하셨습니다.');
                              sendKeyEntered += '8';
                              debugPrint('전송키 6자리를 모두 입력하셨습니다. ${sendKeyEntered}');
                              sendKeyIndex == 6 && sendKeyEntered == '123456' ? Navigator.of(context).pushNamed('/send_comp_screen') : showPopup(context);
                            }else{
                              sendKeyEntered += '8';
                              debugPrint('전송키 6자리를 입력해주세요.');
                              debugPrint('현재 입력된 전송키 : '+sendKeyEntered);
                            }
                          });
                        },
                        child: Container(
                          width:
                          (MediaQuery.of(context).size.width - 40.0) / 3,
                          //  MediaQuery.of(context).size.width
                          height: 78.0,
                          alignment: Alignment.center,
                          color: Colors.white,
                          child: Text(
                            '8',
                            style: TextStyle(
                                fontSize: 26.0,
                                fontWeight: FontWeight.w700,
                                color: Colors.black),
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          debugPrint('9 button clicked.');

                          setState(() {
                            sendKeyIndex++;
                            debugPrint('입력전 전송키 : '+sendKeyEntered);

                            if(sendKeyIndex == 6){
                              debugPrint('전송키 6자리를 모두 입력하셨습니다.');
                              sendKeyEntered += '9';
                              debugPrint('전송키 6자리를 모두 입력하셨습니다. ${sendKeyEntered}');
                              sendKeyIndex == 6 && sendKeyEntered == '123456' ? Navigator.of(context).pushNamed('/send_comp_screen') : showPopup(context);
                            }else{
                              sendKeyEntered += '9';
                              debugPrint('전송키 6자리를 입력해주세요.');
                              debugPrint('현재 입력된 전송키 : '+sendKeyEntered);
                            }
                          });
                          // setState(() {
                          //   if(sendAmount.startsWith('0')){
                          //     !sendAmount.contains('.', 1) ? debugPrint('잘못된 입력입니다.') : sendAmount += '9';
                          //   }else{
                          //     sendAmount += '9';
                          //   }
                          // });
                        },
                        child: Container(
                          width:
                          (MediaQuery.of(context).size.width - 40.0) / 3,
                          //  MediaQuery.of(context).size.width
                          height: 78.0,
                          alignment: Alignment.center,
                          color: Colors.white,
                          child: Text(
                            '9',
                            style: TextStyle(
                                fontSize: 26.0,
                                fontWeight: FontWeight.w700,
                                color: Colors.black),
                          ),
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () {
                          debugPrint('Refresh button clicked.');
                          setState(() {
                            sendKeyEntered = '';
                            sendKeyIndex = 0;
                          });
                        },
                        child: Container(
                          width:
                          (MediaQuery.of(context).size.width - 40.0) / 3,
                          //  MediaQuery.of(context).size.width
                          height: 78.0,
                          alignment: Alignment.center,
                          color: Colors.white,
                          child: SvgPicture.asset(
                            'assets/img/svg/icon_menu_change_on.svg',
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          debugPrint('0 button clicked.');
                          setState(() {
                            sendKeyIndex++;
                            debugPrint('입력전 전송키 : '+sendKeyEntered);
                            if(sendKeyIndex == 6){
                              debugPrint('전송키 6자리를 모두 입력하셨습니다.');
                              sendKeyEntered += '0';
                              debugPrint('전송키 6자리를 모두 입력하셨습니다. ${sendKeyEntered}');
                              sendKeyIndex == 6 && sendKeyEntered == '123456' ? Navigator.of(context).pushNamed('/send_comp_screen') : showPopup(context);
                            }else{
                              sendKeyEntered += '0';
                              debugPrint('현재 입력된 전송키 : '+sendKeyEntered);
                              debugPrint('전송키 6자리를 입력해주세요.');
                            }
                          });
                        },
                        child: Container(
                          width:
                          (MediaQuery.of(context).size.width - 40.0) / 3,
                          //  MediaQuery.of(context).size.width
                          height: 78.0,
                          alignment: Alignment.center,
                          color: Colors.white,
                          child: Text(
                            '0',
                            style: TextStyle(
                                fontSize: 26.0,
                                fontWeight: FontWeight.w700,
                                color: Colors.black),
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          debugPrint('clear button clicked.');
                          setState(() {

                            // int sendKeyLength = sendKeyEntered.length;
                            debugPrint('현재 입력된 전송키 : '+sendKeyEntered);
                            if(sendKeyIndex == 0){
                              debugPrint('입력된 전송키가 없습니다. 전송키를 입력해주세요.');
                            }else{
                              sendKeyIndex--;
                              sendKeyEntered = sendKeyEntered.substring(
                                  0, sendKeyEntered.length - 1);
                              debugPrint('삭제 후 전송키 : '+sendKeyEntered);
                            }
                          });
                        },
                        child: Container(
                            width:
                            (MediaQuery.of(context).size.width - 40.0) /
                                3,
                            //  MediaQuery.of(context).size.width
                            height: 78.0,
                            alignment: Alignment.center,
                            color: Colors.white,
                            child: SvgPicture.asset(
                              'assets/img/svg/icon_clear.svg',
                            )
                          // Text(
                          //   '6',
                          //   style: TextStyle(
                          //       fontSize: 26.0,
                          //       fontWeight: FontWeight.w700,
                          //       color: Colors.black),
                          // ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

