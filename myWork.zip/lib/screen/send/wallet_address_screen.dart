import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:wallet_template/const/colors.dart';

class WalletAddrScreen extends StatelessWidget {
  const WalletAddrScreen({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: Text(
          '나의 지갑 주소',
          style: TextStyle(
              color: Colors.black, fontSize: 18.0, fontWeight: FontWeight.w700),
        ),
        centerTitle: true,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          icon: Icon(
            Icons.arrow_back_ios_new_outlined,
            color: Colors.black,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.popAndPushNamed(context, '/home_screen');
            },
            icon: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: Icon(
                Icons.close,
                size: 24.0,
                color: Colors.black,
              ),
            ),
          )
        ],
      ),
      body: SafeArea(
          child: Container(
        width: double.infinity,
        height: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: 20.0),
        color: Colors.white,
        child: Column(
          children: [
            SizedBox(
              height: 100.0,
            ),
            //지갑이미지
            Container(
              alignment: Alignment.center,
              width: 160.0,
              height: 160.0,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(6.0),
                border: Border.all(width: 2.0, color: border),
                // color: Colors.white,
              ),
              child: SvgPicture.asset(
                'assets/img/svg/icon_wallet.svg',
                width: 60,
                height: 60,
              ),
            ),
            SizedBox(
              height: 20.0,
            ),
            Text(
              '0x279A6E150A971e76e88719e067d50787dE733E31',
              style: TextStyle(
                fontSize: 16.0,
                fontWeight: FontWeight.w700,
                color: Colors.black,
                fontFamily: 'Spoqa_B'
              ),
            ),
            SizedBox(height: 50.0,),
            ElevatedButton(
              //회원가입 버튼
              onPressed: () {
                showPopup(context); //지갑 주소 복사 알림 팝업창
                Clipboard.setData(ClipboardData(text: "0x279A6E150A971e76e88719e067d50787dE733E31"));
              },
              child: Text(
                '지갑 주소 복사하기',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16.0,
                  fontWeight: FontWeight.w700,
                ),
              ),
              style: ElevatedButton.styleFrom(
                  backgroundColor: PRIMARY_COLOR,
                  minimumSize: const Size.fromHeight(50.0),
                  elevation: 0,
                  shadowColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(4.0),
                  )),
            ),
          ],
        ),
      )),
    );
  }
}

void showPopup(BuildContext context) {
  //지갑주소 복사 알림창
  showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          child: Container(
            width: MediaQuery.of(context).size.width * 0.7,
            height: 180,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10), color: Colors.white),
            padding: EdgeInsets.all(20.0),
            child: Center(
              child: Column(
                children: [
                  Expanded(
                    child: Column(
                      children: [
                        Text(
                          '0x279A6E150A971e76e88719e067d50787dE733E31',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Colors.black),
                        ),
                        Text(
                          '지갑 주소가 복사되었습니다.',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Colors.black),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 20.0,
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text(
                      '확인',
                      style: TextStyle(
                          fontSize: 16.0,
                          fontWeight: FontWeight.w600,
                          color: Colors.white),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: PRIMARY_COLOR,
                      minimumSize: const Size.fromHeight(50.0),
                      elevation: 0,
                      shadowColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12.0),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        );
      });
}
