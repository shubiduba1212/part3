import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:wallet_template/const/colors.dart';
import 'package:wallet_template/model/coin_list.dart';
import 'package:wallet_template/screen/send/send_search_screen.dart';
import 'dart:math';

class SendCoinScreen extends StatefulWidget {
  const SendCoinScreen({Key? key}) : super(key: key);

  @override
  State<SendCoinScreen> createState() => _SendCoinScreenState();
}

class _SendCoinScreenState extends State<SendCoinScreen> {
  Random random = Random.secure();
  double randomDouble = 0.00;

  double generateRandomDouble(num min, num max) {
    double randomDouble = random.nextDouble() * (max - min) + min;
    return double.parse(randomDouble.toStringAsFixed(6));
  }

  String selectedDropdown = dropdownList[0]; //코인 select 초기값
  int selectedIndex = 0; //코인 리스트에서 선택한 코인의 index
  String sendAmount = ''; //보낼 금액 초기값
  String sendAvailable = (double.parse(coinBalance[0]) -
      double.parse(coinLock[0])).toString(); //전송가능한 수량

  dynamic stringToNum = 0; //보낼 금액을 실수/정수로 parse한 값의 초기값
  dynamic amountAvailable = 0; //전송가능한 수량을 실수/정수로 parse한 값의 초기값


  //코인 명
  static List<String> dropdownList = [
    'Glow Coin(GLOW)',
    'Tara Coin(TARA)',
    'Etherium(ETH)',
    'Ripple(XRP)',
  ]; //코인 종류 리스트

  //코인 단위
  static List<String> coinUnit = [
    'GLOW',
    'TARA',
    'ETH',
    'XRP',
  ];

  //코인 잔액
  static List<String> coinBalance = [
    '12.008411',
    '54545.087',
    '3112.89678',
    '0.541654',
  ];

  //잠금 수량
  static List<String> coinLock = [
    '1.5478',
    '454.218820',
    '125.058582',
    '0.000578',
  ];

  //전송가능한 수량
  static List<String> coinAvailable = List.generate(
      dropdownList.length, (index) =>
      (double.parse(coinBalance[0]) - double.parse(coinLock[0])).toString());


  //다음 페이지에서 뒤로가기시, 보낼 금액 입력금액 초기화
  void refreshData() {
    setState(() {
      sendAmount = '';
    });
  }

  //send > 필요한 항목 내용 리스트 생성
  final List<CoinList> coinListSend = List.generate(
      dropdownList.length, (index) =>
      CoinList.send(dropdownList[index], coinUnit[index], coinBalance[index],
          coinLock[index], coinAvailable[index]));


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: White,
        title: Text(
          '보내기',
          style: TextStyle(
              color: Colors.black, fontSize: 18.0, fontWeight: FontWeight.w700),
        ),
        centerTitle: true,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          icon: Icon(
            Icons.arrow_back_ios_new_outlined,
            color: Colors.black,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.popAndPushNamed(context, '/home_screen');
            },
            icon: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: Icon(
                Icons.close,
                size: 24.0,
                color: Colors.black,
              ),
            ),
          )
        ],
        elevation: 1.0,
      ),
      body: SafeArea(
        child: Container(
          width: double.infinity,
          height: double.infinity,
          padding: EdgeInsets.all(20.0),
          color: Colors.white,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '코인을 선택하세요',
                  style: TextStyle(
                      fontSize: 16.0,
                      fontWeight: FontWeight.w700,
                      color: Colors.black),
                ),
                SizedBox(
                  height: 10.0,
                ),

                //코인 선택
                Container(
                  width: MediaQuery
                      .of(context)
                      .size
                      .width - 40,
                  padding:
                  EdgeInsets.symmetric(vertical: 2.0, horizontal: 16.0),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6.0),
                      border: Border.all(width: 1.0, color: border)),
                  child: DropdownButton(
                    value: selectedDropdown,
                    items: dropdownList.map((String item) {
                      return DropdownMenuItem<String>(
                        child: Text(
                          '$item',
                          style: GoogleFonts.montserrat(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w700,
                            color: Colors.black,
                          ),
                        ),
                        value: item,
                      );
                    }).toList(),
                    onChanged: (dynamic value) {
                      setState(() {
                        randomDouble = generateRandomDouble(
                            0.1, 1000000.000000);
                        selectedDropdown = value;
                        selectedIndex = dropdownList.indexOf(value);
                        sendAvailable = (double.parse(
                            coinBalance[selectedIndex]) -
                            double.parse(coinLock[selectedIndex])).toString();
                      });
                    },
                    borderRadius: BorderRadius.circular(6.0),
                    underline: SizedBox.shrink(),
                    //밑줄 처리 해제
                    isExpanded: true,
                  ),
                ),
                SizedBox(
                  height: 30.0,
                ),
                Container(
                  // width: MediaQuery.of(context).size.width - 40,
                    width: double.infinity,
                    padding: EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      border: Border.all(width: 1.0, color: border),
                      borderRadius: BorderRadius.circular(6.0),
                      color: Colors.white,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '코인명',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Dark_gray),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          '${selectedDropdown}',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w700,
                              color: Colors.black),
                        ), //코인명
                        SizedBox(
                          height: 14.0,
                        ),
                        Divider(
                          height: 1.0,
                          thickness: 1.0,
                          color: border_sub,
                        ),
                        SizedBox(
                          height: 14.0,
                        ),
                        Text(
                          '잔액',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Dark_gray),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          '${coinListSend[selectedIndex]
                              .balance} ${coinListSend[selectedIndex].unit}',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w700,
                              color: Colors.black),
                        ), //잔액
                        SizedBox(
                          height: 14.0,
                        ),
                        Divider(
                          height: 1.0,
                          thickness: 1.0,
                          color: border_sub,
                        ),
                        SizedBox(
                          height: 14.0,
                        ),
                        Text(
                          '잠금 수량',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Dark_gray),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          '${coinListSend[selectedIndex]
                              .lockAmount} ${coinListSend[selectedIndex].unit}',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w700,
                              color: Colors.black),
                        ), //잠금 수량
                        SizedBox(
                          height: 14.0,
                        ),
                        Divider(
                          height: 1.0,
                          thickness: 1.0,
                          color: border_sub,
                        ),
                        SizedBox(
                          height: 14.0,
                        ),
                        Text(
                          '가스(수수료)',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Dark_gray),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          '1.2 TARA',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w700,
                              color: Colors.black),
                        ), //가스(수수료)
                        SizedBox(
                          height: 14.0,
                        ),
                        Divider(
                          height: 1.0,
                          thickness: 1.0,
                          color: border_sub,
                        ),
                        SizedBox(
                          height: 14.0,
                        ),
                        Text(
                          '전송가능한 수량',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w500,
                              color: Dark_gray),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Text(
                          '${sendAvailable} ${coinListSend[selectedIndex]
                              .unit}',
                          style: TextStyle(
                              fontSize: 14.0,
                              fontWeight: FontWeight.w700,
                              color: Red),
                        ),
                      ],
                    )), //코인명/잔액/잠금수량/가스(수수료)/전송가능한 수량
                SizedBox(
                  height: 20.0,
                ),
                Text(
                  '보내실 금액',
                  style: TextStyle(
                      fontSize: 16.0,
                      fontWeight: FontWeight.w700,
                      color: Colors.black),
                ),
                SizedBox(
                  height: 10.0,
                ),
                Container(
                  padding:
                  EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(width: 1.0, color: border),
                    borderRadius: BorderRadius.circular(6.0),
                  ),
                  child: Text(
                    sendAmount != '' ? sendAmount : '보내실 금액을 입력해 주세요.',
                    style: TextStyle(
                        fontSize: 14.0,
                        fontWeight: FontWeight.w500,
                        color: Dark_gray),
                  ),
                ), //보내실 금액 입력칸

                SizedBox(
                  height: 20.0,
                ),
                //금액 입력 키패드
                Column(
                  children: [
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            debugPrint('1 button clicked.');
                            compareNum('1');
                          },
                          child: Container(
                            width:
                            (MediaQuery
                                .of(context)
                                .size
                                .width - 40.0) / 3,
                            //  MediaQuery.of(context).size.width
                            height: 78.0,
                            alignment: Alignment.center,
                            color: Colors.white,
                            child: Text(
                              '1',
                              style: TextStyle(
                                  fontSize: 26.0,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black),
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            debugPrint('2 button clicked.');
                            compareNum('2');
                          },
                          child: Container(
                            width:
                            (MediaQuery
                                .of(context)
                                .size
                                .width - 40.0) / 3,
                            //  MediaQuery.of(context).size.width
                            height: 78.0,
                            alignment: Alignment.center,
                            color: Colors.white,
                            child: Text(
                              '2',
                              style: TextStyle(
                                  fontSize: 26.0,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black),
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            debugPrint('3 button clicked.');
                            compareNum('3');
                          },
                          child: Container(
                            width:
                            (MediaQuery
                                .of(context)
                                .size
                                .width - 40.0) / 3,
                            //  MediaQuery.of(context).size.width
                            height: 78.0,
                            alignment: Alignment.center,
                            color: Colors.white,
                            child: Text(
                              '3',
                              style: TextStyle(
                                  fontSize: 26.0,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            debugPrint('4 button clicked.');
                            compareNum('4');
                          },
                          child: Container(
                            width:
                            (MediaQuery
                                .of(context)
                                .size
                                .width - 40.0) / 3,
                            //  MediaQuery.of(context).size.width
                            height: 78.0,
                            alignment: Alignment.center,
                            color: Colors.white,
                            child: Text(
                              '4',
                              style: TextStyle(
                                  fontSize: 26.0,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black),
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            debugPrint('5 button clicked.');
                            compareNum('5');
                          },
                          child: Container(
                            width:
                            (MediaQuery
                                .of(context)
                                .size
                                .width - 40.0) / 3,
                            //  MediaQuery.of(context).size.width
                            height: 78.0,
                            alignment: Alignment.center,
                            color: Colors.white,
                            child: Text(
                              '5',
                              style: TextStyle(
                                  fontSize: 26.0,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black),
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            debugPrint('6 button clicked.');
                            compareNum('6');
                          },
                          child: Container(
                            width:
                            (MediaQuery
                                .of(context)
                                .size
                                .width - 40.0) / 3,
                            //  MediaQuery.of(context).size.width
                            height: 78.0,
                            alignment: Alignment.center,
                            color: Colors.white,
                            child: Text(
                              '6',
                              style: TextStyle(
                                  fontSize: 26.0,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            debugPrint('7 button clicked.');
                            compareNum('7');
                          },
                          child: Container(
                            width:
                            (MediaQuery
                                .of(context)
                                .size
                                .width - 40.0) / 3,
                            //  MediaQuery.of(context).size.width
                            height: 78.0,
                            alignment: Alignment.center,
                            color: Colors.white,
                            child: Text(
                              '7',
                              style: TextStyle(
                                  fontSize: 26.0,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black),
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            debugPrint('8 button clicked.');
                            compareNum('8');
                          },
                          child: Container(
                            width:
                            (MediaQuery
                                .of(context)
                                .size
                                .width - 40.0) / 3,
                            //  MediaQuery.of(context).size.width
                            height: 78.0,
                            alignment: Alignment.center,
                            color: Colors.white,
                            child: Text(
                              '8',
                              style: TextStyle(
                                  fontSize: 26.0,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black),
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            debugPrint('9 button clicked.');
                            compareNum('9');
                          },
                          child: Container(
                            width:
                            (MediaQuery
                                .of(context)
                                .size
                                .width - 40.0) / 3,
                            //  MediaQuery.of(context).size.width
                            height: 78.0,
                            alignment: Alignment.center,
                            color: Colors.white,
                            child: Text(
                              '9',
                              style: TextStyle(
                                  fontSize: 26.0,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            debugPrint('. button clicked.');
                            setState(() {
                              if (sendAmount.isEmpty) {
                                debugPrint('숫자입력이 필요합니다.');
                              } else {
                                sendAmount.contains('.') ? debugPrint(
                                    '이미 소숫점이 있습니다.') : sendAmount += '.';
                              }
                            });
                          },
                          child: Container(
                            width:
                            (MediaQuery
                                .of(context)
                                .size
                                .width - 40.0) / 3,
                            //  MediaQuery.of(context).size.width
                            height: 78.0,
                            alignment: Alignment.center,
                            color: Colors.white,
                            child: Text(
                              '.',
                              style: TextStyle(
                                  fontSize: 26.0,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black),
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            debugPrint('0 button clicked.');
                            compareNum('0');
                          },
                          child: Container(
                            width:
                            (MediaQuery
                                .of(context)
                                .size
                                .width - 40.0) / 3,
                            //  MediaQuery.of(context).size.width
                            height: 78.0,
                            alignment: Alignment.center,
                            color: Colors.white,
                            child: Text(
                              '0',
                              style: TextStyle(
                                  fontSize: 26.0,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black),
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            debugPrint('clear button clicked.');
                            setState(() {
                              if (sendAmount.length <= 0) {
                                sendAmount = '';
                              } else {
                                sendAmount = sendAmount.substring(
                                    0, sendAmount.length - 1);
                              }
                            });
                            debugPrint('보내실 금액은 현재 : ' + sendAmount);
                          },
                          child: Container(
                              width:
                              (MediaQuery
                                  .of(context)
                                  .size
                                  .width - 40.0) /
                                  3,
                              //  MediaQuery.of(context).size.width
                              height: 78.0,
                              alignment: Alignment.center,
                              color: Colors.white,
                              child: SvgPicture.asset(
                                'assets/img/svg/icon_clear.svg',
                              )
                            // Text(
                            //   '6',
                            //   style: TextStyle(
                            //       fontSize: 26.0,
                            //       fontWeight: FontWeight.w700,
                            //       color: Colors.black),
                            // ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                SizedBox(
                  height: 20.0,
                ),
                ElevatedButton(
                  //회원가입 버튼
                  onPressed: () async {
                    debugPrint('Next button clicked.');
                    String refresh = await Navigator.push(context,
                        MaterialPageRoute(
                            builder: (context) => const SendSearchScreen()));
                    if (refresh == 'refresh') {
                      refreshData();
                    }
                    // Navigator.of(context).pushNamed('/send_search_screen');
                  },
                  child: Text(
                    '다음',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16.0,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                      backgroundColor: PRIMARY_COLOR,
                      minimumSize: const Size.fromHeight(50.0),
                      elevation: 0,
                      shadowColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4.0),
                      )),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  //전송가능한 수량 vs 보내실 금액
  void compareNum(num) {
    setState(() {
      if (sendAmount.startsWith('0')) {
        sendAmount.startsWith('0.')
            ? sendAmount += num
            : debugPrint('0으로 시작했으므로 소수점이 먼저 필요합니다.');
        compareAmount();
      } else {
        sendAmount += num;
        compareAmount();
      }
    });
  }

  //전송가능한 수량 및 보내실 금액을 정수 or 실수로 변환하여 비교
  void compareAmount() {
    sendAvailable.contains('.')
        ? amountAvailable = double.parse(sendAvailable)
        : amountAvailable = int.parse(sendAvailable);
    sendAmount.contains('.')
        ? stringToNum = double.parse(sendAmount)
        : stringToNum = int.parse(sendAmount);
    debugPrint('전송가능한 수량은 : ' + amountAvailable.toString() + ' 입력한 수량은 : ' +
        stringToNum.toString());
    if (amountAvailable >= stringToNum) {
      debugPrint('입력한 수량이 전송가능한 수량을 초과하지 않았습니다.');
    } else {
      debugPrint('입력한 수량이 전송가능한 수량을 초과했습니다. 다시 입력하세요.');
      sendAmount = '';
    }
  }
}
