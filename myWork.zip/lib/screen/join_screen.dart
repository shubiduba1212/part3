// import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:wallet_template/const/colors.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:wallet_template/model/text_form.dart';

class JoinScreen extends StatefulWidget {
  const JoinScreen({Key? key}) : super(key: key);

  @override
  State<JoinScreen> createState() => _JoinScreenState();
}

class _JoinScreenState extends State<JoinScreen> {
  var _formKey = GlobalKey<FormState>();

  var userIdController = TextEditingController(); //아이디
  var passwordController = TextEditingController(); // 비밀번호
  var passwordCheckController = TextEditingController(); //비밀번호 재입력
  var emailController = TextEditingController(); //이메일
  var userNameController = TextEditingController(); //회원명
  var recommenderController = TextEditingController(); //전송키
  var cellPhoneController = TextEditingController(); //휴대폰번호
  var sendKeyController = TextEditingController(); //전송키

  String userId = '';
  String userPw = '';
  String userRePw = '';
  String userEmail = '';
  String userName = '';
  String recommender = '';
  String userCellphone = '';
  String sendKey = '';

  bool _isChecked = false;
  bool _userId = false;
  bool _userEmail = false;
  bool _userCellphone = false;

  void _validator() {
    final _isValid = _formKey.currentState!
        .validate(); //form 안 textformfield 입력항목이 모두 유효성검사를 통과했는지 여부
    if (_isValid && _isChecked) {
      // 모든 항목&약관동의 올바르게 입력되었으면
      print('all the information written.');
      _formKey.currentState!.save(); // 각 textformfield의 onSaved argument의 값 호출
      postUserRequest(userId, userPw, userEmail, userName, recommender, userCellphone, sendKey);
      // Navigator.popAndPushNamed(context, '/login_screen');
    } else {
      print('all the information not written.');
      _formKey.currentState!.save();
      print('ID : ' + userId + ' / _userId :' + _userId.toString());
      if (userId.isEmpty || !_userId) {
        print('아이디 미입력');
        showPopup('회원 아이디를');
      } else if (userPw.isEmpty || userPw.length < 4 || userPw.length > 20) {
        print('비밀번호 미입력');
        showPopup('비밀번호를');
      } else if (userRePw.isEmpty || userRePw != userPw) {
        print('비밀번호재입력 미입력');
        showPopup('비밀번호 재입력을');
      } else if (userName.isEmpty) {
        print('회원명 미입력');
        showPopup('회원명을');
      } else if (userCellphone.isEmpty || !_userCellphone) {
        print(_userCellphone);
        print('휴대폰 번호 미입력');
        showPopup('휴대폰 번호를');
      } else if (sendKey.isEmpty || sendKey.length < 6) {
        print('전송키 미입력');
        showPopup('전송키를');
      } else if (_isChecked == false) {
        print('이용약관 미동의');
        showPopup('이용약관 동의를');
      } else if (recommender.isEmpty) {
        print('추천인 미입력');
        showPopup('추천인을');
      } else if (userEmail.isEmpty || !_userEmail) {
        print('이메일 미입력');
        showPopup('이메일을');
      }
    }
  }

  @override
  void initState() {
    // TODO: implement initState

    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    userIdController.dispose(); //아이디
    passwordController.dispose(); // 비밀번호
    passwordCheckController.dispose(); //비밀번호 재입력
    userNameController.dispose(); //회원명
    cellPhoneController.dispose(); //휴대폰번호
    sendKeyController.dispose(); //전송키
    super.dispose();
  }

  Future<String> postUserRequest(String userId, String userPw, String email, String userName, String recommender, String cellPhone, String sendKey) async {
    //, String userPw, String userName
    debugPrint('post 실행');
    var response = await http.post(
        Uri.parse('https://yujc-test.tqcard.net'),
        headers: <String, String>{
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          "account": userId,
          "password": userPw,
          "email": email,
          "name": userName,
          "send_key": sendKey,
          "phone": cellPhone,
          "recommender": recommender,
        }),
    );
    print(response);
    print("response.body = ${response.body}");

    try {
      if (response.statusCode == 200) {
        print('서버에 접속했습니다. 200');
        return response.body;
        // print('post한 id(decode) : ${utf8.decode(response.bodyBytes)}');
      } else if (response.statusCode == 201){
        print('서버에 접속했습니다. 201');
        print('post한 회원가입 내용 : ${response.body}');
        print('response.statusCode : ${response.statusCode}');
        return response.body;
      } else {
        debugPrint('서버 접속에 실패했습니다.');
        debugPrint('decode : '+json.decode(utf8.decode(response.bodyBytes)));
        return response.body;
      }
    } catch (e) {
      print('Error occurred.' + e.toString());
    }
    return response.body;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          '회원가입',
          style: TextStyle(
            color: Colors.black,
            fontSize: 20.0,
            fontWeight: FontWeight.w700,
          ),
        ),
        elevation: 1.0,
        centerTitle: true,
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            onPressed: () {
              Navigator.popAndPushNamed(context, '/login_screen');
            },
            icon: Icon(
              Icons.close,
              size: 24.0,
              color: Colors.black,
            ),
          )
        ],
      ),
      body: SafeArea(
        child: Container(
          decoration: BoxDecoration(
            color: Bg,
          ),
          padding: EdgeInsets.all(20.0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      '*',
                      style: TextStyle(
                        color: Colors.red,
                        fontSize: 14.0,
                      ),
                    ),
                    Text(
                      '항목은 ',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 14.0,
                      ),
                    ),
                    Text(
                      '필수입니다.',
                      style: TextStyle(
                        color: Colors.red,
                        fontSize: 14.0,
                      ),
                    )
                  ],
                ),
                // SizedBox(
                //   height: 20.0,
                // ),
                Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        //회원 아이디
                        CommonTextFormField(
                          title: '회원 아이디',
                          controller: userIdController,
                          hintText: '영문, 숫자를 포함한 4자~16자로 입력하세요.',
                          validator: (String? value) {
                            if (value!.isEmpty ||
                                value.length < 4 ||
                                value.length > 16) {
                              _userId = false;
                              return '아이디는 4자~16자 영문, 숫자 조합으로 가능합니다.';
                            }
                            _userId = true;
                          },
                          onSaved: (String? value) {
                            userId = value!;
                          },
                          inputFormatters: [
                            FilteringTextInputFormatter(
                              RegExp('[a-zA-Z0-9]'),
                              //RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                              allow: true,
                            )
                          ],
                        ), //회원 아이디

                        //비밀번호
                        CommonTextFormField(
                          title: '비밀번호',
                          controller: passwordController,
                          hintText: '영문,숫자,특수문자를 사용하여 4자~20자로 입력하세요.',
                          validator: (String? value) {
                            if (value!.isEmpty ||
                                value.length < 4 ||
                                value.length > 20) {
                              return '비밀번호는 4자이상 20자 이하 영문, 숫자, 특수문자 조합으로 가능합니다.';
                            }
                            return null;
                          },
                          onSaved: (String? value) {
                            userPw = value!;
                          },
                          isPassword: true,
                        ), //비밀번호
                        //비밀번호 재입력
                        CommonTextFormField(
                          title: '비밀번호 재입력',
                          controller: passwordCheckController,
                          hintText: '영문,숫자,특수문자를 사용하여 4자~20자로 입력하세요.',
                          validator: (String? value) {
                            if (value!.isEmpty || (userPw != value)) {
                              return '비밀번호가 다릅니다.';
                            }
                            return null;
                          },
                          onSaved: (value) {
                            userRePw = value!;
                          },
                          isPassword: true,
                        ), //비밀번호 재입력

                        //이메일
                        CommonTextFormField(
                            title: '이메일',
                            controller: emailController,
                            hintText: '회원님의 이메일 주소를 입력하세요',

                            validator: (String? value) {
                              if (value!.isEmpty || !RegExp(
                                  r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(value)) {
                                _userEmail = false;
                                return '이메일 주소 형식이 올바르지 않습니다.';
                              }
                              _userEmail = true;
                            },
                            onSaved:  (value) {
                              userEmail = value!;
                            },
                        ),
                        //이메일

                        //회원명
                        CommonTextFormField(
                            title: '회원명',
                            controller: userNameController,
                            hintText: '회원님의 이름을 입력하세요(닉네임 가능)',
                            validator: (String? value) {
                              if (value!.isEmpty) {
                                return '이름을 입력하세요.';
                              }
                              return null;
                            },
                            onSaved: (value) {
                              userName = value!;
                            }
                        ), //회원명

                        //추천인
                        CommonTextFormField(
                            title: '추천인',
                            controller: recommenderController,
                            hintText: '추천인을 입력하세요.',
                            validator: (String? value) {
                              if (value!.isEmpty) {
                                return '추천인을 입력하세요.';
                              }
                              return null;
                            },
                            onSaved: (value) {
                              recommender = value!;
                            }
                        ), //추천인

                        //휴대폰 번호
                        CommonTextFormField(
                          title: '휴대폰 번호',
                            controller: cellPhoneController,
                            hintText: '회원님의 휴대폰 번호를 입력하세요',
                            validator: (value) {
                              if (value!.isEmpty ||
                                  !RegExp(r'^010[0-9]{4}[0-9]{4}$')
                                      .hasMatch(value)) {
                                _userCellphone = false;
                                return '휴대폰번호를 형식에 맞게 입력해주세요.';
                              }
                              _userCellphone = true;
                            },
                            maxLength: 11,
                            onSaved: (value) {
                              userCellphone = value!;
                            },
                          keyboardType: TextInputType.number,
                          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                        ),//휴대폰 번호

                        //전송키
                        CommonTextFormField(
                          title: '전송키(6자리)',
                            controller: sendKeyController,
                            hintText: '사용하실 전송키 6자리를 입력하세요',
                            validator: (String? value) {
                              if (value!.isEmpty || value.length < 6) {
                                return '전송키는 6자리 숫자만 가능합니다.';
                              }
                              return null;
                            },
                            onSaved: (value) {
                              sendKey = value!;
                            },
                          maxLength: 6,
                          keyboardType: TextInputType.number,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly
                          ],
                        ),
                        //전송키

                        SizedBox(
                          height: 20.0,
                        ),
                        GestureDetector(
                          onTap: () {
                            print('checkbox area clicked.');
                            setState(() {
                              if (!_isChecked) {
                                //체크 값이 false인 경우,
                                print('checkbox area not clicked.');
                                _isChecked = true;
                              } else {
                                print('checkbox area already clicked.');
                                _isChecked = false;
                              }
                            });
                          },
                          child: Row(
                            children: [
                              Checkbox(
                                value: _isChecked,
                                onChanged: (bool? value) {
                                  setState(() {
                                    _isChecked = value!;
                                  });
                                },
                                activeColor: Colors.blueAccent,
                                checkColor: Colors.white,
                                fillColor: const MaterialStatePropertyAll(
                                    Color(0xFFff8300)),
                                side: MaterialStateBorderSide.resolveWith(
                                    (states) =>
                                        BorderSide(width: 1, color: InputLine)),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(4.0),
                                ),
                              ),
                              Text(
                                '이용약관 동의',
                                style: TextStyle(
                                    color: InputLine,
                                    fontSize: 14.0,
                                    fontWeight: FontWeight.w500),
                              )
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Container(
                          height: 200.0,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(6.0),
                          ),
                          child: Scrollbar(
                            // isAlwaysShown: true,
                            thickness: 10,
                            radius: Radius.circular(20.0),
                            // scrollbarOrientation: ScrollbarOrientation.top,
                            child: SingleChildScrollView(
                              padding: EdgeInsets.all(20.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '제1조(목적)',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                  Text(
                                    '이 약관은 회사가 온라인으로 제공하는 제반서비스 의 이용과 관련하여 회사와 이용자와의 권리, 의무 및 책임사항 등을 규정함을 목적으로 합니다.',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                  SizedBox(
                                    height: 20.0,
                                  ),
                                  Text(
                                    '제2조(목적)',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                  Text(
                                    '이 약관은 회사가 온라인으로 제공하는 제반서비스 의 이용과 관련하여 회사와 이용자와의 권리, 의무 및 책임사항 등을 규정함을 목적으로 합니다.',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                  SizedBox(
                                    height: 20.0,
                                  ),
                                  Text(
                                    '제3조(목적)',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                  Text(
                                    '이 약관은 회사가 온라인으로 제공하는 제반서비스 의 이용과 관련하여 회사와 이용자와의 권리, 의무 및 책임사항 등을 규정함을 목적으로 합니다.',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                  SizedBox(
                                    height: 20.0,
                                  ),
                                  Text(
                                    '제4조(목적)',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                  Text(
                                    '이 약관은 회사가 온라인으로 제공하는 제반서비스 의 이용과 관련하여 회사와 이용자와의 권리, 의무 및 책임사항 등을 규정함을 목적으로 합니다.',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                  SizedBox(
                                    height: 20.0,
                                  ),
                                  Text(
                                    '제5조(목적)',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                  Text(
                                    '이 약관은 회사가 온라인으로 제공하는 제반서비스 의 이용과 관련하여 회사와 이용자와의 권리, 의무 및 책임사항 등을 규정함을 목적으로 합니다.',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 20.0,
                        ),
                        ElevatedButton(
                          //회원가입 버튼
                          onPressed: () {
                            _validator();
                          },
                          child: Text(
                            '회원가입',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16.0,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                              backgroundColor: PRIMARY_COLOR,
                              minimumSize: const Size.fromHeight(50.0),
                              elevation: 0,
                              shadowColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(4.0),
                              )),
                        ),
                      ],
                    )),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void showPopup(popText) {
    //미입력 관련 알림창
    showDialog(
        context: context,
        builder: (context) {
          return Dialog(
            child: Container(
              width: MediaQuery.of(context).size.width * 0.7,
              height: 150,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10), color: Colors.white),
              padding: EdgeInsets.all(20.0),
              child: Center(
                child: Column(
                  children: [
                    Expanded(
                      child: Text(
                        '${popText} 확인해주세요.',
                        style: TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w500,
                            color: Colors.black),
                      ),
                    ),
                    SizedBox(
                      height: 20.0,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text(
                        '닫기',
                        style: TextStyle(
                            fontSize: 16.0,
                            fontWeight: FontWeight.w600,
                            color: Colors.white),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: PRIMARY_COLOR,
                        minimumSize: const Size.fromHeight(50.0),
                        elevation: 0,
                        shadowColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          );
        });
  }
}
