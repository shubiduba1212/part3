import 'package:carousel_slider/carousel_controller.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:wallet_template/const/colors.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _current = 0;
  final CarouselController _controller = CarouselController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        toolbarHeight: 50.0,
        backgroundColor: Colors.white,
        leading: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: [
              SvgPicture.asset(
                'assets/tara_logo.svg',
                height: 30.0,
              ),
              SizedBox(
                width: 5.0,
              ),
              Text(
                'TARA',
                style: TextStyle(
                    fontSize: 20.0,
                    fontWeight: FontWeight.w700,
                    color: PRIMARY_COLOR),
              )
            ],
          ),
        ),
        leadingWidth: 120.0,
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: ElevatedButton(
              onPressed: () {
                debugPrint('logout button clicked');
              },
              child: Text(
                '로그아웃',
                style: TextStyle(
                    fontSize: 12.0,
                    fontWeight: FontWeight.w600,
                    color: logOut_txt),
              ),
              style: ElevatedButton.styleFrom(
                  backgroundColor: logOut_bg,
                  padding: EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(4.0),
                  ),
                  elevation: 0.0),
            ),
          )
        ],
        elevation: 1.0,
      ),
      body: SafeArea(
          child: Container(
            decoration: BoxDecoration(
              color: Bg,
            ),
            padding: EdgeInsets.all(20.0),
            child: Column(
              children: [
                //회원명/닉네임/레벨
                Row(
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '김타라',
                          style: TextStyle(
                              color: Main_name,
                              fontSize: 20.0,
                              fontWeight: FontWeight.w700),
                        ),
                        Text(
                          'kimtara',
                          style: TextStyle(
                            color: Main_nick.withOpacity(0.6),
                            fontSize: 14.0,
                            fontWeight: FontWeight.w700,
                          ),
                        )
                      ],
                    ),
                    SizedBox(
                      width: 5.0,
                    ),
                    Container(
                      padding:
                      EdgeInsets.symmetric(horizontal: 12.0, vertical: 4.0),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20.0),
                        color: PRIMARY_COLOR,
                      ),
                      child: Text(
                        '0레벨',
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            fontSize: 14.0),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 20.0,
                ),
                Container(
                  //카드 영역 - 입출금
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(6.0),
                    gradient: LinearGradient(
                      //그라디언트 배경
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [card_blue_start, card_blue_end],
                    ),
                    boxShadow: [
                      BoxShadow(
                          blurRadius: 10,
                          offset: const Offset(0, 2),
                          color: Colors.black.withOpacity(0.28))
                    ],
                  ),
                  child: Column(
                    children: [
                      Container(
                        padding:
                        EdgeInsets.symmetric(horizontal: 20.0, vertical: 30.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              //카드 타이틀
                              '입출금',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.w600),
                            ),
                            GestureDetector(
                              onTap: () {
                                debugPrint('Figures in card clicked.');
                              },
                              child: Row(
                                // 카드 숫자 및 아이콘 영역
                                children: [
                                  Text(
                                    '0.00',
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 20.0,
                                        fontWeight: FontWeight.w700),
                                  ),
                                  SizedBox(
                                    width: 5.0,
                                  ),
                                  Icon(
                                    Icons.arrow_forward_ios,
                                    size: 24.0,
                                    color: Colors.white,
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.all(12.0),
                        decoration: BoxDecoration(
                          color: Colors.transparent.withOpacity(0.1),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            SizedBox(
                              height: 44,
                              // width: 0.2,
                              child: TextButton(
                                onPressed: () {
                                  debugPrint('details button clicked.');
                                },
                                child: Text(
                                  '내역',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14.0,
                                      fontWeight: FontWeight.w500),
                                ),
                                style: TextButton.styleFrom(
                                  // minimumSize: const Size.fromHeight(44.0),
                                ),
                              ),
                            ),
                            Text(
                              '|',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.w500),
                            ),
                            SizedBox(
                              height: 44,
                              // width: 0.2,
                              child: TextButton(
                                onPressed: () {
                                  debugPrint('withdraw button clicked.');
                                },
                                child: Text(
                                  '출금',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 14.0,
                                    fontWeight: FontWeight.w500,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                                style: TextButton.styleFrom(
                                  // minimumSize: const Size.fromHeight(44.0),s
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                )//카드 영역(입출금/내역 등등)
                //메인 페이지 메뉴 버튼 영역

              ],
            ),
          )),
    );
  }
}
