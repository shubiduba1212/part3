import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:wallet_template/const/colors.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:wallet_template/screen/exchange/exchange_amount_screen.dart';

import '../../model/coin_list.dart';

class ExchangeScreen extends StatefulWidget {
  const ExchangeScreen({Key? key}) : super(key: key);

  @override
  State<ExchangeScreen> createState() => _ExchangeScreenState();
}

class _ExchangeScreenState extends State<ExchangeScreen> {
  int selectedIndex = 2; //내비게이션 바 활성화 인덱스

  //다음 페이지에서 뒤로가기시, 코인 리스트 클릭 초기화
  void refreshData(){
    setState(() {
      coinListClicked = false;
    });
  }

  bool coinListClicked = false; //코인 리스트 클릭 여부
  int ?coinListIndex;
  int slideDuration = 250;

  //코인 목록 여부
  bool noCoinList = false; //교환 가능한 코인 리스트 목록 없는 상태

  //코인 이미지 경로
  static List<String> coinImagePath = [
    'assets/img/main/icon_coin_bit.svg',
    'assets/img/main/icon_coin_eth.svg',
    'assets/img/main/icon_coin_trx.svg',
    'assets/img/main/icon_coin_usdt.svg',
    'assets/img/main/icon_coin_xrp.svg',
  ];

  //코인 이름
  static List<String> coinName = [
    'BitCoin',
    'Etherium',
    'Tron',
    'Tether',
    'Ripple',
  ];


  //코인 이미지 경로 + 코인 이름 => 코인 교환 리스트 생성
  final List<CoinListExchange> coinListExchange = List.generate(coinName.length, (index) =>
      CoinListExchange(coinImagePath[index], coinName[index]));


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          title: Text(
            '교환',
            style: TextStyle(
                color: Colors.black,
                fontSize: 18.0,
                fontWeight: FontWeight.w700),
          ),
          centerTitle: true,
          leading: IconButton(
            onPressed: () {
              // Navigator.of(context).pop();
              Navigator.popAndPushNamed(context, '/home_screen');
            },
            icon: Icon(
              Icons.arrow_back_ios_new_outlined,
              color: Colors.black,
            ),
          ),
          // leadingWidth: 10.0,
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: selectedIndex,
          onDestinationSelected: (value) => setState(() {
            selectedIndex = value;
            if (value == 0) {
              Navigator.popAndPushNamed(context, '/home_screen');
            } else if (value == 1) {
              Navigator.popAndPushNamed(context, '/send_screen');
            } else if (value == 2) {
              Navigator.popAndPushNamed(context, '/exchange_screen');
            } else if (value == 3) {
              Navigator.popAndPushNamed(context, '/mypage_screen');
            }
          }),
          destinations: [
            NavigationDestination(
              icon: Icon(Icons.account_balance_wallet_outlined),
              label: '지갑',
            ),
            NavigationDestination(
              icon: Icon(Icons.send_rounded),
              label: '보내기',
            ),
            NavigationDestination(
              icon: Icon(Icons.currency_exchange_outlined),
              label: '교환',
            ),
            NavigationDestination(
              icon: Icon(Icons.person),
              label: '나의정보',
            ),
          ],
          animationDuration: const Duration(milliseconds: 500),
        ),
        body: SafeArea(
            child: SingleChildScrollView(
          child: Container(
            color: Colors.white,
            padding: EdgeInsets.all(20.0),
            child: !noCoinList
                ? Column(               
                    children: [
                      Text('교환할 코인 목록이 존재합니다.'),
                      Container(
                        width: double.infinity,
                        height: 106.0 * coinListExchange.length,
                        child: ListView.builder(
                          primary: false,
                          shrinkWrap: true,
                          itemCount: coinListExchange.length,
                          itemBuilder: (context, index){
                            return Stack(
                              fit: StackFit.loose,
                              children: [
                                Container(
                                  height: 106.0,
                                  padding: EdgeInsets.only(bottom: 14.0),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      SizedBox(
                                        width: 70.0,
                                        height: 60.0,
                                        child: ElevatedButton(
                                          onPressed: () async{
                                            debugPrint('Exchange button clicked.');
                                            // Navigator.of(context).push(MaterialPageRoute(builder: (context) => ExchangeAmountScreen(coinListExchange: coinListExchange[index],)));
                                            String refresh = await Navigator.push(context, MaterialPageRoute(builder: (context) => ExchangeAmountScreen(coinListExchange: coinListExchange[index],)));
                                            if(refresh == 'refresh'){
                                              refreshData();
                                            }
                                            slideDuration = 0;
                                            coinListClicked = false;
                                          },
                                          child: Text(
                                            '교환',
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 14.0,
                                                fontFamily: 'Spoqa_B',
                                                fontWeight: FontWeight.w700),
                                            softWrap: true,
                                            textAlign: TextAlign.center,
                                          ),
                                          style: ElevatedButton.styleFrom(
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                              BorderRadius.circular(4.0),
                                            ),
                                            padding: EdgeInsets.symmetric(
                                                vertical: 8.0, horizontal: 14.0),
                                            backgroundColor: PRIMARY_COLOR,
                                            // minimumSize: Size.fromHeight(60.0),
                                          ),
                                        ),
                                      ),
                                      SizedBox(width: 10.0,),
                                      SizedBox(
                                        width: 70.0,
                                        height: 60.0,
                                        child: ElevatedButton(
                                          onPressed: () {
                                            debugPrint(
                                                'Transaction history button clicked.');
                                          },
                                          child: Text(
                                            '거래내역',
                                            style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 14.0,
                                                fontFamily: 'Spoqa_B',
                                                fontWeight: FontWeight.w700),
                                            softWrap: true,
                                            textAlign: TextAlign.center,
                                          ),
                                          style: ElevatedButton.styleFrom(
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                              BorderRadius.circular(4.0),
                                            ),
                                            padding: EdgeInsets.symmetric(
                                                vertical: 8.0, horizontal: 16.0),
                                            backgroundColor: PRIMARY_COLOR,
                                            // minimumSize: Size.fromHeight(60.0),
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        width: 1.0,
                                      ),
                                    ],
                                  ),
                                ), //거래내역/보내기/주소복사 버튼 영역

                                AnimatedPositioned(
                                  duration: Duration(milliseconds: slideDuration),
                                  left: coinListIndex != index ? 0 : coinListClicked ? -160 : 0,
                                  width: MediaQuery.of(context).size.width - 40,
                                  // height: 108.0,
                                  child: GestureDetector(
                                    onTap: () {
                                      setState(() {
                                        slideDuration = 250;
                                        if(coinListIndex == index){ //해당 리스트를 다시 탭한 상태
                                          !coinListClicked ? coinListClicked = true : coinListClicked = false;
                                        }else{//이전 탭한 리스트와 다른 리스트를 탭한 상태
                                          coinListIndex = index; // 클릭된 해당 리스트 index값으로 변경
                                          coinListClicked = true; // 해당 리스트 활성화
                                        }
                                      });
                                    },
                                    child: Container(
                                      width: MediaQuery.of(context).size.width,
                                      // height: 500.0,
                                      padding: EdgeInsets.symmetric(
                                          vertical: 10.0, horizontal: 16.0),
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(6.0),
                                        border: Border.all(
                                          color: border_sub,
                                          width: 1.0,
                                        ),
                                        boxShadow: [
                                          BoxShadow(
                                              blurRadius: 2,
                                              offset: const Offset(1, 1),
                                              color:
                                              Colors.black12.withOpacity(0.28))
                                        ],
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            children: [
                                              Container(
                                                width:MediaQuery.of(context).size.width / 2 - 43.5,
                                                alignment: Alignment.center,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    SvgPicture.asset(
                                                      ('assets/img/main/icon_coin_tara.svg'),
                                                      width: 44.0,
                                                      height: 44.0,
                                                    ),
                                                    SizedBox(
                                                      width: 10.0,
                                                    ),
                                                    Text(
                                                      'TARA',
                                                      style: GoogleFonts.montserrat(
                                                        fontSize: 16.0,
                                                        fontWeight: FontWeight.w700,
                                                        color: Colors.black,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              SvgPicture.asset('assets/img/svg/icon_arrow_red.svg', width: 13.0,),
                                              Container(
                                                width:MediaQuery.of(context).size.width / 2 - 43.5,
                                                alignment: Alignment.center,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    SvgPicture.asset(
                                                      coinListExchange[index].imgPath,
                                                      width: 44.0,
                                                      height: 44.0,
                                                    ),
                                                    SizedBox(
                                                      width: 10.0,
                                                    ),
                                                    Text(
                                                      coinListExchange[index].name,
                                                      style: GoogleFonts.montserrat(
                                                        fontSize: 16.0,
                                                        fontWeight: FontWeight.w700,
                                                        color: Colors.black,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ) //코인 리스트 항목
                              ],
                            );
                          },
                        ),
                      ),
                    ],
                  )//교환 등록된 코인이 있는 경우
                : Center(
                    child: Text('교환할 코인 리스트가 없습니다.'),
                  ),//교환 등록된 코인이 없는 경우
          ),
        )));
  }

  void showPopup() {
    //지갑주소 복사 알림창
    showDialog(
        context: context,
        builder: (context) {
          return Dialog(
            child: Container(
              width: MediaQuery.of(context).size.width * 0.7,
              height: 150,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10), color: Colors.white),
              padding: EdgeInsets.all(20.0),
              child: Center(
                child: Column(
                  children: [
                    Expanded(
                      child: Text(
                        '지갑 주소가 복사되었습니다.',
                        style: TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w500,
                            color: Colors.black),
                      ),
                    ),
                    SizedBox(
                      height: 20.0,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text(
                        '확인',
                        style: TextStyle(
                            fontSize: 16.0,
                            fontWeight: FontWeight.w600,
                            color: Colors.white),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: PRIMARY_COLOR,
                        minimumSize: const Size.fromHeight(50.0),
                        elevation: 0,
                        shadowColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          );
        });
  }
}
