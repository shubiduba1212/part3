import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:wallet_template/const/colors.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../model/coin_list.dart';

class ExchangeAmountScreen extends StatefulWidget {
  const ExchangeAmountScreen({Key? key, required this.coinListExchange}) : super(key: key);
  final CoinListExchange coinListExchange;//교환 메인 페이지에서 클릭한 코인 리스트 데이터 내용을 담은 리스트

  @override
  State<ExchangeAmountScreen> createState() => _ExchangeAmountScreenState();
}

class _ExchangeAmountScreenState extends State<ExchangeAmountScreen> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          '교환',
          style: TextStyle(
              color: Colors.black, fontSize: 18.0, fontWeight: FontWeight.w700),
        ),
        centerTitle: true,
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context, 'refresh');
          },
          icon: Icon(
            Icons.arrow_back_ios_new_outlined,
            color: Colors.black,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.popAndPushNamed(context, '/home_screen');
            },
            icon: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: Icon(
                Icons.close,
                size: 24.0,
                color: Colors.black,
              ),
            ),
          )
        ],
        elevation: 1.0,
      ),
      body: SafeArea(
          child: SingleChildScrollView(
        child: Container(
          color: Colors.white,
          padding: EdgeInsets.all(20.0),
          child: Column(
            children: [
              Container(
                width: MediaQuery.of(context).size.width,
                // height: 500.0,
                padding: EdgeInsets.symmetric(
                    vertical: 10.0, horizontal: 16.0),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(6.0),
                  border: Border.all(
                    color: border_sub,
                    width: 1.0,
                  ),
                ),
                child: Row(
                  mainAxisAlignment:
                  MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Container(
                          width:MediaQuery.of(context).size.width / 2 - 43.5,
                          alignment: Alignment.center,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              SvgPicture.asset(
                                ('assets/img/main/icon_coin_tara.svg'),

                                width: 44.0,
                                height: 44.0,
                              ),
                              SizedBox(
                                width: 10.0,
                              ),
                              Text(
                                'TARA',
                                style: GoogleFonts.montserrat(
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SvgPicture.asset('assets/img/svg/icon_arrow_red.svg', width: 13.0,),
                        Container(
                          width:MediaQuery.of(context).size.width / 2 - 43.5,
                          alignment: Alignment.center,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              SvgPicture.asset(
                                // 'assets/img/main/icon_coin_eth.svg',
                                widget.coinListExchange.imgPath,
                                width: 44.0,
                                height: 44.0,
                              ),
                              SizedBox(
                                width: 10.0,
                              ),
                              Text(
                                // 'Ethereum',
                                widget.coinListExchange.name,
                                style: GoogleFonts.montserrat(
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.w700,
                                  color: Colors.black,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),//교환 코인 이미지 및 코인 명
            ],
          ),
        ),
      )),
    );
  }
}
