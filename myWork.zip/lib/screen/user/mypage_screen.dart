import 'package:flutter/material.dart';

class MyPageScreen extends StatefulWidget {
  const MyPageScreen({Key? key}) : super(key: key);

  @override
  State<MyPageScreen> createState() => _MyPageScreenState();
}

class _MyPageScreenState extends State<MyPageScreen> {
  int selectedIndex = 3;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          '나의 정보',
          style: TextStyle(
              color: Colors.black, fontSize: 18.0, fontWeight: FontWeight.w700),
        ),
        centerTitle: true,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          icon: Icon(Icons.arrow_back_ios_new_outlined, color: Colors.black,),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: (value) => setState(() {
          selectedIndex = value;
          if(value == 0){
            Navigator.of(context).popAndPushNamed('/home_screen');
          }else if(value == 1){
            Navigator.of(context).popAndPushNamed('/send_screen');
          }else if(value == 2){
            Navigator.of(context).popAndPushNamed('/exchange_screen');
          }else if(value == 3){
            Navigator.of(context).popAndPushNamed('/mypage_screen');
          }
        }),
        destinations: [
          NavigationDestination(
            icon: Icon(Icons.account_balance_wallet_outlined),
            label: '지갑',
          ),
          NavigationDestination(
            icon: Icon(Icons.send_rounded),
            label: '보내기',
          ),
          NavigationDestination(
            icon: Icon(Icons.currency_exchange_outlined),
            label: '교환',
          ),
          NavigationDestination(
            icon: Icon(Icons.person),
            label: '나의정보',
          ),
        ],
        animationDuration: const Duration(milliseconds: 500),
      ),
      body: SafeArea(
        child: Center(
            child:Text('My info Page')
        ),
      ),
    );
  }
}
