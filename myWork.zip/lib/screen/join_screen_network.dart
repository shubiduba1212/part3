import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:wallet_template/const/colors.dart';

class JoinScreen extends StatefulWidget {
  const JoinScreen({Key? key}) : super(key: key);

  @override
  State<JoinScreen> createState() => _JoinScreenState();
}

class _JoinScreenState extends State<JoinScreen> {
  var _formKey = GlobalKey<FormState>();

  var userIdController = TextEditingController(); //아이디
  var passwordController = TextEditingController(); // 비밀번호
  var passwordCheckController = TextEditingController(); //비밀번호 재입력
  var userNameController = TextEditingController(); //회원명
  var emailController = TextEditingController(); //이메일
  var cellPhoneController = TextEditingController(); //휴대폰번호
  var recommenderController = TextEditingController(); //추천인
  var supporterController = TextEditingController(); //후원인

  String userId = '';
  String userPw = '';
  String userRePw = '';
  String userName = '';
  String userEmail = '';
  String userCellphone = '';
  String recommender = '';
  String supporter = '';

  bool _isChecked = false;
  bool _userId = false;
  bool _userPw = false;
  bool _userRePw = false;
  bool _userName = false;
  bool _userEmail = false;
  bool _userCellphone = false;
  bool _recommender = false;
  bool _supporter = false;

  void _validator() {
    final _isValid = _formKey.currentState!.validate(); //form 안 textformfield 입력항목이 모두 유효성검사를 통과했는지 여부
    if (_isValid) { // 모든 항목 올바르게 입력되었으면
      print('all the information written.');
      _formKey.currentState!.save(); // 각 textformfield의 onSaved argument의 값 호출
      Navigator.pushNamed(context, '/login_screen');
    } else {
      print('all the information not written.');
      _formKey.currentState!.save();
      print(userId);
      if (userId!.isEmpty || !_userId) {
        print('아이디 미입력');
        showPopup('회원 아이디를');
      } else if (userPw!.isEmpty) {
        print('비밀번호 미입력');
        showPopup('비밀번호를');
      } else if (userRePw!.isEmpty) {
        print('비밀번호재입력 미입력');
        showPopup('비밀번호 재입력을');
      } else if (userName!.isEmpty) {
        print('회원명 미입력');
        showPopup('회원명을');
      } else if (userEmail!.isEmpty) {
        print('이메일 미입력');
        showPopup('이메일을');
      } else if (userCellphone!.isEmpty || !_userCellphone) {
        print(_userCellphone);
        print('휴대폰 번호 미입력');
        showPopup('휴대폰 번호를');
      } else if (recommender!.isEmpty) {
        print('추천인 미입력');
        showPopup('추천인을');
      } else if (supporter!.isEmpty) {
        print('후원인 미입력');
        showPopup('후원인을');
      } else if (_isChecked == false) {
        print('이용약관 미동의');
        showPopup('이용약관 동의를');
      }
    }
  }

  void showPopup(popText) {
    //미입력 관련 알림창
    showDialog(
        context: context,
        builder: (context) {
          return Dialog(
            child: Container(
              width: MediaQuery.of(context).size.width * 0.7,
              height: 150,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10), color: Colors.white),
              padding: EdgeInsets.all(20.0),
              child: Center(
                child: Column(
                  children: [
                    Expanded(
                      child: Text(
                        '${popText} 확인해주세요.',
                        style: TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w500,
                            color: Colors.black),
                      ),
                    ),
                    SizedBox(
                      height: 20.0,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text(
                        '닫기',
                        style: TextStyle(
                            fontSize: 16.0,
                            fontWeight: FontWeight.w600,
                            color: Colors.white),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: PRIMARY_COLOR,
                        minimumSize: const Size.fromHeight(50.0),
                        elevation: 0,
                        shadowColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          );
        });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          '회원가입',
          style: TextStyle(
            color: Colors.black,
            fontSize: 20.0,
            fontWeight: FontWeight.w700,
          ),
        ),
        elevation: 1.0,
        centerTitle: true,
        actions: [
          IconButton(
            onPressed: () {
              Navigator.pushNamed(context, '/login_screen');
            },
            icon: Icon(
              Icons.close,
              size: 24.0,
              color: Colors.black,
            ),
          )
        ],
      ),
      body: SafeArea(
        child: Container(
          decoration: BoxDecoration(
            color: Bg,
          ),
          padding: EdgeInsets.all(20.0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      '*',
                      style: TextStyle(
                        color: Colors.red,
                        fontSize: 14.0,
                      ),
                    ),
                    Text(
                      '항목은 ',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 14.0,
                      ),
                    ),
                    Text(
                      '필수입니다.',
                      style: TextStyle(
                        color: Colors.red,
                        fontSize: 14.0,
                      ),
                    )
                  ],
                ),
                SizedBox(
                  height: 20.0,
                ),
                Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Text(
                              '회원 아이디',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16.0,
                              ),
                            ),
                            Text(
                              '* ',
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 16.0,
                              ),
                            ),
                          ],
                        ),
                        TextFormField(
                          //회원 아이디
                          controller: userIdController,
                          inputFormatters: [
                            FilteringTextInputFormatter(
                              RegExp('[a-zA-Z0-9]'),
                              //RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                              allow: true,
                            )
                          ],
                          validator: (value) {
                            if (value!.isEmpty ||
                                value.length < 4 ||
                                value.length > 16) {
                              _userId = false;
                              // setState(() {
                              //   _userId = false;
                              // });
                              return '아이디는 4자~16자 영문, 숫자 조합으로 가능합니다.';
                            }
                            _userId = true;
                            // setState(() {
                            //   _userId = true;
                            // });
                            return null;

                            // else{
                            // return '사용 가능한 아이디입니다.';
                            // }
                          },
                          onSaved: (value) {
                            userId = value!;
                          },
                          decoration: InputDecoration(
                            filled: true,
                            //input에 배경색 추가 여부
                            fillColor: Colors.white,
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 1,
                                color: InputLine,
                              ),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(width: 1, color: PRIMARY_COLOR),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 12.0, horizontal: 25.0),
                            hintText: '영문, 숫자를 포함한 4자~16자로 입력해주세요.',
                            hintStyle: TextStyle(
                              color: InputLine,
                              fontSize: 16.0,
                              fontWeight: FontWeight.w400,
                            ),
                            errorBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 1,
                                color: InputLine,
                              ),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 20.0,
                        ),
                        Row(
                          children: [
                            Text(
                              '비밀번호',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16.0,
                              ),
                            ),
                            Text(
                              '* ',
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 16.0,
                              ),
                            ),
                          ],
                        ),
                        TextFormField(
                          //비밀번호
                          controller: passwordController,
                          validator: (value) {
                            if (value!.isEmpty ||
                                value.length < 4 ||
                                value.length > 20) {
                              return '비밀번호는 4자이상 20자 이하 영문, 숫자, 특수문자 조합으로 가능합니다.';
                            }
                            return null;
                          },
                          onSaved: (value) {
                            userPw = value!;
                          },
                          decoration: InputDecoration(
                            filled: true,
                            //input에 배경색 추가 여부
                            fillColor: Colors.white,
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 1,
                                color: InputLine,
                              ),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(width: 1, color: PRIMARY_COLOR),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 12.0, horizontal: 25.0),
                            hintText: '영문,숫자,특수문자를 사용하여 4자~20자로 입력해주세요.',
                            hintStyle: TextStyle(
                              color: InputLine,
                              fontSize: 16.0,
                              fontWeight: FontWeight.w400,
                            ),
                            errorBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 1,
                                color: InputLine,
                              ),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                          ),
                          obscureText: true,
                        ),
                        SizedBox(
                          height: 20.0,
                        ),
                        Row(
                          children: [
                            Text(
                              '비밀번호 재입력',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16.0,
                              ),
                            ),
                            Text(
                              '* ',
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 16.0,
                              ),
                            ),
                          ],
                        ),
                        TextFormField(
                          //비밀번호 재입력
                          controller: passwordCheckController,
                          validator: (value) {
                            if (value!.isEmpty ||
                                (userPw != value)) {
                              return '비밀번호가 다릅니다.';
                            }
                            return null;
                          },
                          onSaved: (value) {
                            userRePw = value!;
                          },
                          decoration: InputDecoration(
                            filled: true,
                            //input에 배경색 추가 여부
                            fillColor: Colors.white,
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 1,
                                color: InputLine,
                              ),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(width: 1, color: PRIMARY_COLOR),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 12.0, horizontal: 25.0),
                            hintText: '영문,숫자,특수문자를 사용하여 4자~20자로 입력해주세요.',
                            hintStyle: TextStyle(
                              color: InputLine,
                              fontSize: 16.0,
                              fontWeight: FontWeight.w400,
                            ),
                            errorBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 1,
                                color: InputLine,
                              ),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                          ),
                          obscureText: true,
                        ),
                        SizedBox(
                          height: 20.0,
                        ),
                        Row(
                          children: [
                            Text(
                              '회원명',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16.0,
                              ),
                            ),
                            Text(
                              '* ',
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 16.0,
                              ),
                            ),
                          ],
                        ),
                        TextFormField(
                          //회원명
                          controller: userNameController,
                          validator: (value) {
                            if (value!.isEmpty) {
                              return '이름을 입력해주세요.';
                            }
                            return null;
                          },
                          onSaved: (value) {
                            userName = value!;
                          },
                          decoration: InputDecoration(
                            filled: true,
                            //input에 배경색 추가 여부
                            fillColor: Colors.white,
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 1,
                                color: InputLine,
                              ),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(width: 1, color: PRIMARY_COLOR),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 12.0, horizontal: 25.0),
                            hintText: '회원님의 이름을 입력하세요(닉네임 가능)',
                            hintStyle: TextStyle(
                              color: InputLine,
                              fontSize: 16.0,
                              fontWeight: FontWeight.w400,
                            ),
                            errorBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 1,
                                color: InputLine,
                              ),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 20.0,
                        ),
                        Row(
                          children: [
                            Text(
                              '이메일',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16.0,
                              ),
                            ),
                            Text(
                              '* ',
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 16.0,
                              ),
                            ),
                          ],
                        ),
                        TextFormField(
                          //이메일
                          controller: emailController,
                          validator: (value) {
                            if (value!.isEmpty ||
                                !EmailValidator.validate(value)) {
                              //정규식
                              // 45.hasMatch(value)
                              return '이메일 형식이 맞지 않습니다.';
                            }
                            return null;
                          },
                          onSaved: (value) {
                            userEmail = value!;
                          },
                          decoration: InputDecoration(
                            filled: true,
                            //input에 배경색 추가 여부
                            fillColor: Colors.white,
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 1,
                                color: InputLine,
                              ),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(width: 1, color: PRIMARY_COLOR),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 12.0, horizontal: 25.0),
                            hintText: '회원님의 이메일을 입력하세요',
                            hintStyle: TextStyle(
                              color: InputLine,
                              fontSize: 16.0,
                              fontWeight: FontWeight.w400,
                            ),
                            errorBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 1,
                                color: InputLine,
                              ),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 20.0,
                        ),
                        Row(
                          children: [
                            Text(
                              '휴대폰 번호',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16.0,
                              ),
                            ),
                            Text(
                              '* ',
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 16.0,
                              ),
                            ),
                          ],
                        ),
                        TextFormField(
                          //휴대폰 번호
                          controller: cellPhoneController,
                          validator: (value) {
                            if (value!.isEmpty ||
                                !RegExp(r'^010[0-9]{4}[0-9]{4}$').hasMatch(value)) {
                              _userCellphone = false;
                              return '휴대폰번호를 형식에 맞게 입력해주세요.';
                            }
                            _userCellphone = true;
                            return null;
                          },
                          maxLength: 11,
                          onSaved: (value) {
                            userCellphone = value!;
                          },
                          decoration: InputDecoration(
                            filled: true,
                            //input에 배경색 추가 여부
                            fillColor: Colors.white,
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 1,
                                color: InputLine,
                              ),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(width: 1, color: PRIMARY_COLOR),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 12.0, horizontal: 25.0),
                            hintText: '회원님의 휴대폰 번호를 입력하세요',
                            hintStyle: TextStyle(
                              color: InputLine,
                              fontSize: 16.0,
                              fontWeight: FontWeight.w400,
                            ),
                            errorBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 1,
                                color: InputLine,
                              ),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            counterText: '', //텍스트 제한 글자수 비활성화
                          ),
                        ),
                        SizedBox(
                          height: 20.0,
                        ),
                        Row(
                          children: [
                            Text(
                              '추천인',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16.0,
                              ),
                            ),
                            Text(
                              '* ',
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 16.0,
                              ),
                            ),
                          ],
                        ),
                        TextFormField(
                          //추천인
                          controller: recommenderController,
                          validator: (value) {
                            if (value!.isEmpty) {
                              return '잘못된 아이디형식입니다.';
                            }
                            return null;
                          },
                          onSaved: (value) {
                            recommender = value!;
                          },
                          decoration: InputDecoration(
                            filled: true,
                            //input에 배경색 추가 여부
                            fillColor: Colors.white,
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 1,
                                color: InputLine,
                              ),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(width: 1, color: PRIMARY_COLOR),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 12.0, horizontal: 25.0),
                            hintText: '회원님의 추천인을 입력하세요',
                            hintStyle: TextStyle(
                              color: InputLine,
                              fontSize: 16.0,
                              fontWeight: FontWeight.w400,
                            ),
                            errorBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 1,
                                color: InputLine,
                              ),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 20.0,
                        ),
                        Row(
                          children: [
                            Text(
                              '후원인',
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 16.0,
                              ),
                            ),
                            Text(
                              '* ',
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 16.0,
                              ),
                            ),
                          ],
                        ),
                        TextFormField(
                          //후원인
                          controller: supporterController,
                          validator: (value) {
                            if (value!.isEmpty) {
                              return '잘못된 아이디형식입니다.';
                            }
                            return null;
                          },
                          onSaved: (value) {
                            supporter = value!;
                          },
                          decoration: InputDecoration(
                            filled: true,
                            //input에 배경색 추가 여부
                            fillColor: Colors.white,
                            enabledBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 1,
                                color: InputLine,
                              ),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(width: 1, color: PRIMARY_COLOR),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                            contentPadding: EdgeInsets.symmetric(
                                vertical: 12.0, horizontal: 25.0),
                            hintText: '회원님의 후원인을 입력하세요',
                            hintStyle: TextStyle(
                              color: InputLine,
                              fontSize: 16.0,
                              fontWeight: FontWeight.w400,
                            ),
                            errorBorder: OutlineInputBorder(
                              borderSide: BorderSide(
                                width: 1,
                                color: InputLine,
                              ),
                              borderRadius: BorderRadius.circular(6.0),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 20.0,
                        ),
                        GestureDetector(
                          onTap: () {
                            print('checkbox area clicked.');
                            setState(() {
                              if (!_isChecked) {
                                //체크 값이 false인 경우,
                                print('checkbox area not clicked.');
                                _isChecked = true;
                              } else {
                                print('checkbox area already clicked.');
                                _isChecked = false;
                              }
                            });
                          },
                          child: Row(
                            children: [
                              Checkbox(
                                value: _isChecked,
                                onChanged: (bool? value) {
                                  setState(() {
                                    _isChecked = value!;
                                  });
                                },
                                activeColor: Colors.blueAccent,
                                checkColor: Colors.white,
                                fillColor: const MaterialStatePropertyAll(
                                    Color(0xFFff8300)),
                                side: MaterialStateBorderSide.resolveWith(
                                        (states) =>
                                        BorderSide(width: 1, color: InputLine)),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(4.0),
                                ),
                              ),
                              Text(
                                '이용약관 동의',
                                style: TextStyle(
                                    color: InputLine,
                                    fontSize: 14.0,
                                    fontWeight: FontWeight.w500),
                              )
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10.0,
                        ),
                        Container(
                          height: 200.0,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(6.0),
                          ),
                          child: Scrollbar(
                            // isAlwaysShown: true,
                            thickness: 10,
                            radius: Radius.circular(20.0),
                            // scrollbarOrientation: ScrollbarOrientation.top,
                            child: SingleChildScrollView(
                              padding: EdgeInsets.all(20.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '제1조(목적)',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                  Text(
                                    '이 약관은 회사가 온라인으로 제공하는 제반서비스 의 이용과 관련하여 회사와 이용자와의 권리, 의무 및 책임사항 등을 규정함을 목적으로 합니다.',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                  SizedBox(
                                    height: 20.0,
                                  ),
                                  Text(
                                    '제2조(목적)',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                  Text(
                                    '이 약관은 회사가 온라인으로 제공하는 제반서비스 의 이용과 관련하여 회사와 이용자와의 권리, 의무 및 책임사항 등을 규정함을 목적으로 합니다.',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                  SizedBox(
                                    height: 20.0,
                                  ),
                                  Text(
                                    '제3조(목적)',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                  Text(
                                    '이 약관은 회사가 온라인으로 제공하는 제반서비스 의 이용과 관련하여 회사와 이용자와의 권리, 의무 및 책임사항 등을 규정함을 목적으로 합니다.',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                  SizedBox(
                                    height: 20.0,
                                  ),
                                  Text(
                                    '제4조(목적)',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                  Text(
                                    '이 약관은 회사가 온라인으로 제공하는 제반서비스 의 이용과 관련하여 회사와 이용자와의 권리, 의무 및 책임사항 등을 규정함을 목적으로 합니다.',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                  SizedBox(
                                    height: 20.0,
                                  ),
                                  Text(
                                    '제5조(목적)',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                  Text(
                                    '이 약관은 회사가 온라인으로 제공하는 제반서비스 의 이용과 관련하여 회사와 이용자와의 권리, 의무 및 책임사항 등을 규정함을 목적으로 합니다.',
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 12.0),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 20.0,
                        ),
                        ElevatedButton(
                          //회원가입 버튼
                          onPressed: () {
                            _validator();
                          },
                          child: Text(
                            '회원가입',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16.0,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          style: ElevatedButton.styleFrom(
                              backgroundColor: PRIMARY_COLOR,
                              minimumSize: const Size.fromHeight(50.0),
                              elevation: 0,
                              shadowColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(4.0),
                              )),
                        ),
                      ],
                    )),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
