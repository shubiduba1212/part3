import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:wallet_template/const/colors.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final formKey = GlobalKey<FormState>();

  var userIdController = TextEditingController(); //아이디
  var passwordController = TextEditingController(); // 비밀번호

  String userId = '';
  String userPw = '';

  void _validator() {
    final _isValid = formKey.currentState!
        .validate(); //form 안 textformfield 입력항목이 모두 유효성검사를 통과했는지 여부
    if (_isValid) {
      // 모든 항목 올바르게 입력되었으면
      print('all the information written.');
      formKey.currentState!.save(); // 각 textformfield의 onSaved argument의 값 호출
      Navigator.pushNamed(context, '/home_screen');
    } else {
      debugPrint('all the information not written or written wrong.');
      formKey.currentState!.save();
      debugPrint(userId);
      if (userId.isEmpty || userId.length < 4 || userId.length > 16) {
        debugPrint('아이디 미입력 또는 잘못입력');
        showPopup('회원 아이디를');
      } else if (userPw.isEmpty || userPw.length < 4 || userPw.length > 20) {
        debugPrint('비밀번호 미입력 또는 잘못입력');
        showPopup('비밀번호를');
      }
    }
  }

  postUserRequest(String userId, String userPw) async {
    debugPrint('post 실행');
    var response = await http.post(Uri.parse('https://test.tqpay.biz/ajax/user_login_ajax.php'),
        body:{
          "user_id": userId,
          "user_pw": userPw,
        }
    );

    print(response);
    print("response.body = ${response.body}");
    print(response.body.runtimeType);
    // var responseArr = Array.from(response.body);

    try {
      if (response.statusCode == 200) {
        print('서버에 접속했습니다.');
        print('post한 로그인 내용 : ${response.body}');
        // if(response.body[0]){
        //
        // }
        // print('post한 id(decode) : ${utf8.decode(response.bodyBytes)}');
      } else {
        print('response.statusCode : ${response.statusCode}');
        print('서버 접속에 실패했습니다.');
      }
    } catch (e) {
      print('Error occurred.' + e.toString());
      // Fluttertoast.showToast(msg: e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
          child: Container(
        height: double.infinity,
        decoration: BoxDecoration(
          color: Colors.white,
        ),
        padding: EdgeInsets.all(20.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.only(top: 70.0, bottom: 40.0),
                child: Center(
                  child: SvgPicture.asset(
                    'assets/tara_logo.svg',
                    width: 100,
                    height: 100,
                  ),
                ),
              ),
              const SizedBox(
                height: 20.0,
              ),
              const Text(
                'Wallet Template',
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 34.0,
                    fontWeight: FontWeight.w700),
              ),
              const SizedBox(
                height: 20.0,
              ),
              Form(
                key: this.formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '아이디',
                      style: TextStyle(
                        fontSize: 14.0,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    SizedBox(
                      height: 10.0,
                    ),
                    TextFormField(
                      // key: valueKey,
                      controller: userIdController,
                      validator: (value) {
                        if (value!.isEmpty || value.length < 4) {
                          return '아이디를 올바르게 입력하세요.';
                        }
                        return null;
                      },
                      onSaved: (value) {
                        userId = value!;
                      },
                      decoration: InputDecoration(
                        labelText: '회원 아이디를 입력하세요.',
                        labelStyle: const TextStyle(
                            fontSize: 14.0, fontWeight: FontWeight.w400),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 1,
                            color: Line,
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(6.0)),
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                            vertical: 8.0, horizontal: 16.0),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        focusedBorder: const OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 1.0,
                            color: PRIMARY_COLOR,
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(6.0)),
                        ),
                        errorBorder: const OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 1.0,
                            color: PRIMARY_COLOR,
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(6.0)),
                        ),
                        focusedErrorBorder: const OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 1.0,
                            color: PRIMARY_COLOR,
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(6.0)),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20.0,
                    ),
                    Text(
                      '비밀번호',
                      style: TextStyle(
                        fontSize: 14.0,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    SizedBox(
                      height: 10.0,
                    ),
                    TextFormField(
                      // key: valueKey,
                      controller: passwordController,
                      validator: (value) {
                        if (value!.isEmpty ||
                            value.length < 4 ||
                            value.length > 20) {
                          return '비밀번호를 올바르게 입력하세요.';
                        }
                        return null;
                      },
                      onSaved: (value) {
                        userPw = value!;
                      },
                      decoration: InputDecoration(
                        labelText: '회원 비밀번호를 입력하세요.',
                        labelStyle: const TextStyle(
                            fontSize: 14.0, fontWeight: FontWeight.w400),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 1,
                            color: Line,
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(6.0)),
                        ),
                        contentPadding: const EdgeInsets.symmetric(
                            vertical: 8.0, horizontal: 16.0),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        focusedBorder: const OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 1.0,
                            color: PRIMARY_COLOR,
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(6.0)),
                        ),
                        errorBorder: const OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 1.0,
                            color: PRIMARY_COLOR,
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(6.0)),
                        ),
                        focusedErrorBorder: const OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 1.0,
                            color: PRIMARY_COLOR,
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(6.0)),
                        ),
                      ),
                      obscureText: true,
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 50.0,
              ),
              ElevatedButton(
                onPressed: () {
                  _validator();
                },
                child: Text(
                  '로그인',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16.0,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                    backgroundColor: PRIMARY_COLOR,
                    minimumSize: const Size.fromHeight(50.0),
                    elevation: 0,
                    shadowColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(4.0),
                    )),
              ), //로그인 버튼
              SizedBox(
                height: 40.0,
              ),
              Text(
                '아직 계정이 없으신가요?',
                style: TextStyle(fontSize: 14.0, fontWeight: FontWeight.w500),
              ),
              SizedBox(
                height: 40.0,
              ),
              ElevatedButton(
                onPressed: (){
                  Navigator.pushNamed(context, '/join_screen');
                },
                child: Text(
                  '회원가입',
                  style: TextStyle(
                    color: PRIMARY_COLOR,
                    fontSize: 16.0,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  minimumSize: const Size.fromHeight(50.0),
                  elevation: 0,
                  shadowColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(4.0),
                  ),
                  side: const BorderSide(width: 1, color: PRIMARY_COLOR),
                ),
              ),
            ],
          ),
        ),
      )),
    );
  }

  //팝업창
  void showPopup(popText) {
    //미입력 관련 알림창
    showDialog(
        context: context,
        builder: (context) {
          return Dialog(
            child: Container(
              width: MediaQuery.of(context).size.width * 0.7,
              height: 150,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10), color: Colors.white),
              padding: EdgeInsets.all(20.0),
              child: Center(
                child: Column(
                  children: [
                    Expanded(
                      child: Text(
                        '${popText} 확인해주세요.',
                        style: TextStyle(
                            fontSize: 14.0,
                            fontWeight: FontWeight.w500,
                            color: Colors.black),
                      ),
                    ),
                    SizedBox(
                      height: 20.0,
                    ),
                    ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text(
                        '닫기',
                        style: TextStyle(
                            fontSize: 16.0,
                            fontWeight: FontWeight.w600,
                            color: Colors.white),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: PRIMARY_COLOR,
                        minimumSize: const Size.fromHeight(50.0),
                        elevation: 0,
                        shadowColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12.0),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          );
        });
  }
}
