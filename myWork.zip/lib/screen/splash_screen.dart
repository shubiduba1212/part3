import 'dart:async';
import 'package:wallet_template/const/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState(){
    super.initState();
    Timer(const Duration(seconds:3), () {
      Navigator.pushReplacementNamed(context, '/login_screen');
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          color: Colors.white,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SvgPicture.asset(
                  'assets/tara_logo.svg',
                  width: 100.0,
                ),
                SizedBox(height: 50.0,),
                CircularProgressIndicator(
                  color: PRIMARY_COLOR,
                  backgroundColor: Colors.white,
                  strokeWidth: 2,
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
