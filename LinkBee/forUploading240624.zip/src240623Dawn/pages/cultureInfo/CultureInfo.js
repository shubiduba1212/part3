//import styles from "./CultureInfo.module.css";

export default function CultureInfo () {

  return(
    <>
    <h1>전시/공연 정보 페이지</h1>
    </>
    );
}
