

{/* <li>
  <a href="#">
    <div className={styles.culture_img}>
      <img src={`${process.env.PUBLIC_URL}/images/cultureInfo/KakaoTalk_20240524_000933916_04.png`} alt="culture poster" />
      <span className={styles.culture_mark}>마감임박</span>
    </div>
    <div className={styles.culture_item_txt}>
      <p className={styles.culture_tit}>서양 미술 800년展</p>
      <p className={styles.culture_date}>2024.08.05 ~ 2024.10.31</p>
      <p className={styles.early_end}></p>
      <p className={styles.culture_price}><span className={styles.sale_rate}>30%</span> 84,700원</p>
    </div>
  </a>
</li> */}