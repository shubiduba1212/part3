import Completed from "../../components/login/SignUpCompleted";

function CompletedPage() {

    return (
            <>
            <div id="content">
                {<Completed/>}
            </div>
            </>
    );
}

export default CompletedPage;