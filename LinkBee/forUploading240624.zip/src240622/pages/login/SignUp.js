import SignUp from "../../components/login/SignUp"


function SignUpPage() {

    return (
            <>
            <div id="content">
                {<SignUp/>}
            </div>
            </>
    );
}

export default SignUpPage;