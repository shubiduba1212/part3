import Login from "../../components/login/Login"


function LoginPage() {

    return (
            <>
            <div id="content">
                {<Login/>}
            </div>
            </>
    );
}

export default LoginPage;